This sample uses the Flickr public REST api for one of the demonstrations.

In order to use this API, you must have a Flickr API key.  These can be obtained
by looking at http://www.flickr.com/services/api/ for information about the API 
and how to obtain a key.