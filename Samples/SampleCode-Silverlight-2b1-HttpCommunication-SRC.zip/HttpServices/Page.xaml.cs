﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Net;
using System.Xml.Linq;
using System.IO;
using System.Windows.Media.Imaging;

namespace HttpServices
{
    public partial class Page : UserControl
    {
        #region const urls
        const string IMAGE_STREAM = "http://sandbox.timheuer.com/zane.jpg";
        const string MSN_VIDEO = "http://catalog.video.msn.com/randomvideo.aspx?mk=us&vs=0&ff=99&c=10";
        // NOTE YOU WILL NEED TO APPEND YOUR FLICKR API KEY TO SEE THIS SAMPLE WORK
        const string FLICKR_SEARCH = "http://api.flickr.com/services/rest/?method=flickr.photos.search&tags=weimaraner&api_key=";
        private XNamespace _NS { get { return "urn:schemas-microsoft-com:msnvideo:catalog"; } }
        private XNamespace NS1 = "http://schemas.datacontract.org/2004/07/";
        #endregion

        public Page()
        {
            InitializeComponent();
        }

        private void gobutton_Click(object sender, RoutedEventArgs e)
        {
            // this first proxy uses a string 
            // request to retrieve the information
            // additionally we've added the progress handler
            WebClient proxy = new WebClient();
            proxy.DownloadStringCompleted += new DownloadStringCompletedEventHandler(proxy_DownloadStringCompleted);
            proxy.DownloadProgressChanged += new DownloadProgressChangedEventHandler(proxy_DownloadProgressChanged);
            proxy.DownloadStringAsync(new Uri(MSN_VIDEO));

            // to retrieve a stream use the 
            // OpenRead functions instead and you will receive
            // a stream object
            WebClient proxy2 = new WebClient();
            proxy2.OpenReadCompleted += new OpenReadCompletedEventHandler(proxy2_OpenReadCompleted);
            proxy2.OpenReadAsync(new Uri(IMAGE_STREAM));
        }

        void proxy2_OpenReadCompleted(object sender, OpenReadCompletedEventArgs e)
        {
            Stream img = e.Result;

            BitmapImage bmp = new BitmapImage();
            bmp.SetSource(img);

            RetrievedImage.Source = bmp;
        }

        void proxy_DownloadProgressChanged(object sender, DownloadProgressChangedEventArgs e)
        {
            if (e.ProgressPercentage < 100)
            {
                ProgressText.Text = "Loading: " + e.ProgressPercentage + "%";
            }
            else
            {
                ProgressText.Text = string.Empty;
            }
            
        }

        void proxy_DownloadStringCompleted(object sender, DownloadStringCompletedEventArgs e)
        {
            string res = e.Result;
            XDocument doc = XDocument.Parse(res);

            var vids = from results in doc.Descendants(_NS + "video")
                       select results;

            NameList.ItemsSource = vids;
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            HttpWebRequest req = WebRequest.Create(new Uri(FLICKR_SEARCH)) as HttpWebRequest;
            req.Method = "GET"; // we could also use POST if we needed
            // we can set custom headers on our request as well
            // req.Headers.Headers.Add("x-made-by-silverlight");
            req.BeginGetResponse(new AsyncCallback(FlickrCallback), req);
        }

        private void FlickrCallback(IAsyncResult result)
        {
            HttpWebRequest req = result.AsyncState as HttpWebRequest;
            HttpWebResponse resp = req.EndGetResponse(result) as HttpWebResponse;

            Stream strm = resp.GetResponseStream();
        }
    }
}
