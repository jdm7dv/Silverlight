﻿namespace SilvesterWeb.BusinessObjects
{
    using System;

    [Serializable]
    public class Status
    {
        public string CreatedAt
        {
            get;
            set;
        }

        //public int Id
        //{
        //    get;
        //    set;
        //}

        public string Text
        {
            get;
            set;
        }

        //public string Source
        //{
        //    get;
        //    set;
        //}

        //public bool Truncated
        //{
        //    get;
        //    set;
        //}

        //public int InReplyToStatusId
        //{
        //    get;
        //    set;
        //}

        //public int InReplyToUserId
        //{
        //    get;
        //    set;
        //}

        //public bool Favourited
        //{
        //    get;
        //    set;
        //}

        public User User
        {
            get;
            set;
        }

        public string TimeGone
        {
            get
            {
                string[] values = this.CreatedAt.Split( ' ' );
                string timeValue = string.Format( "{0} {1}, {2} {3}", values[ 1 ], values[ 2 ], values[ 5 ], values[ 3 ] );
                DateTime parsedDate = DateTime.Parse( timeValue );

                DateTime relativeTo = DateTime.Now;

                // time difference in seconds
                double delta = relativeTo.Subtract( parsedDate ).TotalSeconds + DateTime.UtcNow.Subtract( relativeTo ).TotalSeconds;

                if ( delta < 60 )
                {
                    return "less than a minute ago";
                }
                else if ( delta < 120 )
                {
                    return "about a minute ago";
                }
                else if ( delta < ( 60 * 60 ) )
                {
                    return ( int )( delta / 60 ) + " minutes ago";
                }
                else if ( delta < ( 120 * 60 ) )
                {
                    return "about an hour ago";
                }
                else if ( delta < ( 24 * 60 * 60 ) )
                {
                    return string.Format( "about {0} hours ago", ( int )( delta / 3600 ) );
                }
                else if ( delta < ( 48 * 60 * 60 ) )
                {
                    return "1 day ago";
                }
                else
                {
                    return ( int )( delta / 86400 ) + " days ago";
                }
            }

            set
            {

            }
        }
    }
}
