﻿namespace Silvester
{
    using System;
    using System.Windows;
    using System.Windows.Controls;
    using System.Net;
    using Silvester.TwitterService;
    using System.Threading;
    using System.Windows.Threading;

    public partial class TwitterClient : UserControl
    {
        private string twitterUser;
        private DispatcherTimer timelineTimer;

        public TwitterClient()
        {
            InitializeComponent();
        }

        public string TwitterUser
        {
            get
            {
                return this.twitterUser;
            }

            set
            {
                if ( string.IsNullOrEmpty( value ) )
                {
                    StatusList.ItemsSource = null;
                    this.twitterUser = value;
                }
                else if ( string.IsNullOrEmpty( this.twitterUser ) || !this.twitterUser.Equals( value, StringComparison.OrdinalIgnoreCase ) )
                {
                    this.twitterUser = value;
                    this.RefreshTimeline();
                    this.FollowMe.NavigateUri = new Uri( "http://twitter.com/" + this.TwitterUser );
                }
            }
        }

        private void RefreshTimeline_Click( object sender, RoutedEventArgs e )
        {
            this.RefreshTimeline();
        }

        private void RefreshTimeline()
        {
            this.ShowLoadingBar();
            if ( this.timelineTimer == null )
            {
                this.timelineTimer = new DispatcherTimer();
                this.timelineTimer.Tick += new EventHandler( this.RefreshTimeline );
                this.timelineTimer.Interval = new TimeSpan( 0, 3, 0 );
            }
            else
            {
                this.timelineTimer.Stop();
            }

            this.RefreshTimeline( this, EventArgs.Empty );
        }

        private void RefreshTimeline( object sender, EventArgs e )
        {
            if ( string.IsNullOrEmpty( this.TwitterUser ) )
            {
                return;
            }

            TwitterWebServiceSoapClient twitterClient = new TwitterWebServiceSoapClient();
            twitterClient.GetUserTimelineCompleted += new EventHandler<GetUserTimelineCompletedEventArgs>( this.GetUserTimelineCompleted );
            twitterClient.GetUserTimelineAsync( this.TwitterUser, null, null );
        }

        private void GetUserTimelineCompleted( object sender, GetUserTimelineCompletedEventArgs e )
        {
            if ( e.Cancelled || e.Error != null )
            {
                this.timelineTimer.Stop();
                LastUpdatedLabel.Text = string.Empty;
                StatusMessage.Text = "Error";
                StatusMessage.SetValue(
                    ToolTipService.ToolTipProperty,
                    new TextBlock()
                    {
                        Text = e.Error.Message,
                        TextWrapping = TextWrapping.Wrap,
                        MaxWidth = 200
                    } );
                this.HideLoadingBar();
                return;
            }

            StatusMessage.Text = string.Empty;
            StatusList.ItemsSource = e.Result;
            LastUpdatedValue.Text = DateTime.Now.ToLongTimeString();

            if ( !this.timelineTimer.IsEnabled )
            {
                this.timelineTimer.Start();
            }

            this.HideLoadingBar();
        }

        private void ShowLoadingBar()
        {
            Loader.Visibility = Visibility.Visible;
            HighlightLoadingPoints.Begin();
        }

        private void HideLoadingBar()
        {
            Loader.Visibility = Visibility.Collapsed;
            HighlightLoadingPoints.Stop();
        }
    }
}
