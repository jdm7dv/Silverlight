﻿namespace Silvester
{
    using System;
    using System.Windows.Data;

    public class UserLinkConverter : IValueConverter
    {
        public object Convert( object value, Type targetType, object parameter, System.Globalization.CultureInfo culture )
        {
            string username = ( string )value;

            return new Uri( "http://twitter.com/" + username );
        }

        public object ConvertBack( object value, Type targetType, object parameter, System.Globalization.CultureInfo culture )
        {
            throw new NotImplementedException();
        }
    }
}
