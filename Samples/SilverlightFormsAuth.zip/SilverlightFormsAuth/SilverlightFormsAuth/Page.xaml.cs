﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace SilverlightFormsAuth
{
    public partial class Page : UserControl
    {
        public Page(string pageName)
        {
            InitializeComponent();
            PageName = pageName;
            LoadPage();
        }
        public Page(string pageName,string loginName)
        {
            InitializeComponent();
            LoginName = loginName;
            LoadPage();
        }
        public string PageName
        {
            get;
            set;
        }
        public string LoginName
        {
            get;
            set;
        }
        public void LoadPage()
        {
            if (PageName == "login")
            {
                this.Content = new login();
            }
            else
            {
                this.Content = new userdetails(LoginName);
            }
        }
    }
}
