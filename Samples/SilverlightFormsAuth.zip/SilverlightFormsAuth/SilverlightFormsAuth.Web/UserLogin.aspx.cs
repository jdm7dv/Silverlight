﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Script.Services;
using System.Web.Services;
using System.Web.Configuration;
using System.Web.Security;

namespace SilverlightFormsAuth.Web
{
    public partial class _Default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        public string ReturnURL
        {
            get
            {
                if (Request.QueryString["ReturnUrl"] != null)
                {
                    return Request.QueryString["ReturnUrl"];
                }
                else
                {
                    return "";
                }
            }
        }

        [WebMethod, ScriptMethod]
        public static bool userlogin(string userName, string password)
        {
            if (FormsAuthentication.Authenticate(userName,password))
            {
                FormsAuthentication.SetAuthCookie(userName, false);
                return true;
            }
            return false;
        }
    }
}
