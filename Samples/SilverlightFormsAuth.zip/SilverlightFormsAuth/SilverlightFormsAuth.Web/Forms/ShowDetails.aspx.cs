﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SilverlightFormsAuth.Web.Forms
{
    public partial class ShowDetails : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            string loginName = HttpContext.Current.User.Identity.Name;
            Xaml1.InitParameters = "PageName=userdetails,loginName=" + loginName;
        }
    }
}
