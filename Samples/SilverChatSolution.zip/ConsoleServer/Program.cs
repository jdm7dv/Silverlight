﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Chat;

namespace ConsoleServer
{
    class Program
    {
        private static Server _server;
        private static PolicyServer _policyServer;

        static void Main(string[] args)
        {
            Console.CancelKeyPress += new ConsoleCancelEventHandler(Console_CancelKeyPress);

            _policyServer = new PolicyServer();
            _policyServer.ServerEvent += new EventHandler<ServerEventArgs>(server_ServerEvent);
            
            _server = new Server(4520);
            _server.MessageReceived += new EventHandler<MessageEventArgs>(server_MessageReceived);
            _server.ServerEvent += new EventHandler<ServerEventArgs>(server_ServerEvent);

            _policyServer.Start();
            _server.Start();

            while (true)
            {
                System.Threading.Thread.Sleep(5);
            }
        }

        static void Console_CancelKeyPress(object sender, ConsoleCancelEventArgs e)
        {
            _server.Stop();
            _policyServer.Stop();
        }

        static void server_ServerEvent(object sender, ServerEventArgs e)
        {
            Console.WriteLine(e.Time.ToString("hh:mm:ss") + "-> " + e.Text);
        }

        static void server_MessageReceived(object sender, MessageEventArgs e)
        {
            Console.WriteLine("Received Message: " + e.Message.Data[0]);
        }
    }
}
