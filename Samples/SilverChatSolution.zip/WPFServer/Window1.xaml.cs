﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WPFServer
{
    /// <summary>
    /// Interaction logic for Window1.xaml
    /// </summary>
    public partial class Window1 : Window
    {
        protected Chat.Server _server;
        protected Chat.PolicyServer _policyServer;

        public Window1()
        {
            InitializeComponent();
        }

        private void startButton_Click(object sender, RoutedEventArgs e)
        {
            int serverPort = 4520;

            int.TryParse(port.Text, out serverPort);

            _policyServer = new Chat.PolicyServer();
            _policyServer.ServerEvent += new EventHandler<Chat.ServerEventArgs>(_policyServer_ServerEvent);

            _server = new Chat.Server(serverPort);
            _server.ServerEvent += new EventHandler<Chat.ServerEventArgs>(_server_ServerEvent);

            _policyServer.Start();
            _server.Start();

            startButton.IsEnabled = false;
            stopButton.IsEnabled = true;
        }

        void addText(string text)
        {
            this.Dispatcher.BeginInvoke((Action)delegate
            {
                output.Text += DateTime.Now.ToString("h:mm:ss") + " -> " + text + Environment.NewLine;

                autoScroll();
            });
        }

        //TODO: Make this smarter and only auto scroll if they're already at the bottom
        private void autoScroll()
        {
            this.UpdateLayout();
            outputScroller.ScrollToVerticalOffset(outputScroller.ScrollableHeight);
        }

        void _server_ServerEvent(object sender, Chat.ServerEventArgs e)
        {
            addText(e.Text);
        }

        void _policyServer_ServerEvent(object sender, Chat.ServerEventArgs e)
        {
            addText(e.Text);
        }

        private void stopButton_Click(object sender, RoutedEventArgs e)
        {
            _policyServer.Stop();
            _server.Stop();

            startButton.IsEnabled = true;
            stopButton.IsEnabled = false;
        }
    }
}
