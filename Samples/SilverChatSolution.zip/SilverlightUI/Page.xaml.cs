﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Chat;
using System.Collections.ObjectModel;

namespace SilverlightUI
{
    public partial class Page : UserControl
    {
        protected Client _client = null;

        public Page()
        {
            InitializeComponent();
            server.Text = System.Windows.Application.Current.Host.Source.DnsSafeHost;
        }

        private void initAndSignInToChat()
        {
            int serverPort = 4520;
            int.TryParse(port.Text, out serverPort);

            _client = new Client(server.Text, serverPort, username.Text);

            _client.SignedIn += new EventHandler<EventArgs>(_client_SignedIn);
            _client.SignedOut += new EventHandler<EventArgs>(_client_SignedOut);
            _client.SignInFailed += new EventHandler<ClientEventArgs>(_client_SignInFailed);
            _client.ChatReceived += new EventHandler<MessageEventArgs>(_client_ChatReceived);
            _client.UserJoined += new EventHandler<MessageEventArgs>(_client_UserJoined);
            _client.UserLeft += new EventHandler<MessageEventArgs>(_client_UserLeft);
            _client.UserList += new EventHandler<MessageEventArgs>(_client_UserList);
            _client.SystemEvent += new EventHandler<ClientEventArgs>(_client_SystemEvent);
            _client.SignIn();
        }

        void _client_SignInFailed(object sender, ClientEventArgs e)
        {
            this.Dispatcher.BeginInvoke(() =>
            {
                MessageBox.Show("Sign-in failed: " + e.Text);
                signInButton.IsEnabled = true;
            });
        }

        void _client_UserList(object sender, MessageEventArgs e)
        {
            this.Dispatcher.BeginInvoke(() =>
            {
                ObservableCollection<string> users = new ObservableCollection<string>();
                foreach (string user in e.Message.Data)
                    users.Add(user);

                chatUsers.ItemsSource = users;
            });
        }

        void addText(DateTime time, string text)
        {
            this.Dispatcher.BeginInvoke(() =>
            {
                output.Text += time.ToString("h:mm:ss") + "\t" + text + Environment.NewLine;

                autoScroll();
            });
        }

        //TODO: Make this smarter and only auto scroll if they're already at the bottom
        private void autoScroll()
        {
            this.UpdateLayout();
            outputScroller.ScrollToVerticalOffset(outputScroller.ScrollableHeight);
        }

        void addText(string text)
        {
            addText(DateTime.Now, text);
        }

        void _client_SystemEvent(object sender, ClientEventArgs e)
        {
            addText(e.Time, "System Event: " + e.Text);
        }

        void _client_UserJoined(object sender, MessageEventArgs e)
        {
            string newUser = e.Message.Data[0];

            addText(e.Message.Time, "User '" + newUser + "' joined the chat.");

            this.Dispatcher.BeginInvoke(() =>
            {
                ObservableCollection<string> userNames = chatUsers.ItemsSource as ObservableCollection<string>;
                if (userNames != null)
                {
                    if (!userNames.Contains(newUser))
                        userNames.Add(newUser);
                }
            });
        }

        void _client_UserLeft(object sender, MessageEventArgs e)
        {
            string newUser = e.Message.Data[0];

            addText(e.Message.Time, "User '" + newUser + "' left the chat.");

            this.Dispatcher.BeginInvoke(() =>
            {
                ObservableCollection<string> userNames = chatUsers.ItemsSource as ObservableCollection<string>;
                if (userNames != null)
                {
                    if (userNames.Contains(newUser))
                        userNames.Remove(newUser);
                }
            });
        }

        void _client_ChatReceived(object sender, MessageEventArgs e)
        {
            addText(e.Message.Time, e.Message.Data[0] + ": " + e.Message.Data[1]);
        }

        void _client_SignedIn(object sender, EventArgs e)
        {
            this.Dispatcher.BeginInvoke(() =>
            {
                output.Text = String.Empty;
                input.Text = string.Empty;
                sendButton.IsEnabled = false;

                gridSignedIn.Visibility = Visibility.Visible;
                gridSignIn.Visibility = Visibility.Collapsed;
            });
        }

        void _client_SignedOut(object sender, EventArgs e)
        {
            this.Dispatcher.BeginInvoke(() =>
            {
                gridSignedIn.Visibility = Visibility.Collapsed;
                gridSignIn.Visibility = Visibility.Visible;

                signInButton.IsEnabled = true;
            });
        }

        void _client_ClientEvent(object sender, ClientEventArgs e)
        {
            addText(e.Time, e.Text);
        }

        private void sendButton_Click(object sender, RoutedEventArgs e)
        {
            sendChat();
        }
        
        private void signOutButton_Click(object sender, RoutedEventArgs e)
        {
            _client.SignOut();
        }

        private void signInButton_Click(object sender, RoutedEventArgs e)
        {
            bool valid = true;
            string errorMessage = string.Empty;

            if (username.Text.Trim() == String.Empty)
            {
                valid = false;
                errorMessage += "Username Required." + Environment.NewLine;
            }

            if (server.Text.Trim() == String.Empty)
            {
                valid = false;
                errorMessage += "Server Required." + Environment.NewLine;
            }

            if (port.Text.Trim() == String.Empty)
            {
                valid = false;
                errorMessage += "Port Required." + Environment.NewLine;
            }

            if (valid)
            {
                signInButton.IsEnabled = false;
                initAndSignInToChat();
            }
            else
            {
                System.Windows.MessageBox.Show(errorMessage);
            }
        }

        private void input_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter && input.Text.Trim() != String.Empty)
                sendChat();
        }

        private void input_KeyUp(object sender, KeyEventArgs e)
        {
            if (input.Text.Trim() == String.Empty)
            {
                sendButton.IsEnabled = false;
            }
            else
            {
                sendButton.IsEnabled = true;
            }
        }

        private void sendChat()
        {
            _client.SendChat(input.Text);
            input.Text = String.Empty;
        }
    }
}
