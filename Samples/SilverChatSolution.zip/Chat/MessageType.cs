﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Chat
{
    public enum MessageType : byte
    {
        UserJoined = 1,
        UserLeft = 2,
        Text = 3,
        SetNameRequest = 4,
        SetNameDenied = 5,
        NameSet = 6,
        UserListRequest = 7,
        UserList = 8,
        Disconnect = 9,
        KeepAlive = 10
    }
}
