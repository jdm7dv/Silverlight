﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Chat
{
    public class MessageEventArgs : EventArgs 
    {
        public Message Message { get; private set; }

        public MessageEventArgs(Message message)
        {
            this.Message = message;
        }
    }
}
