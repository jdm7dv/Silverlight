﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Chat
{
    public class ServerEventArgs : EventArgs
    {
        public DateTime Time { get; private set; }
        public string Text { get; private set; }

        public ServerEventArgs(DateTime time, string text)
        {
            this.Time = time;
            this.Text = text;
        }
    }
}
