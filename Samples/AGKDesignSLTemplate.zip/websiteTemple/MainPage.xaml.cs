﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Windows.Browser;

namespace websiteTemple
{
	public partial class MainPage : UserControl
	{
		public MainPage()
		{
			// Required to initialize variables
			InitializeComponent();
		}

		private void LayoutRoot_Loaded(object sender, System.Windows.RoutedEventArgs e)
		{
			{
            Onload.Begin();
            Onload.Completed += new EventHandler(Onload_Completed);
        	}
		}
        private void Onload_Completed(object sender, EventArgs e)
        {
          VisualStateManager.GoToState(this, "View1", true);
		mainAnimation.Begin();
        }
		


	}
}