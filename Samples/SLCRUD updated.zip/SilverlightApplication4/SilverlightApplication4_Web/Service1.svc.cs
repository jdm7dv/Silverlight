﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using System.Data.Linq;
using System.Data.Linq.Mapping;
using System.Reflection;
using System.Transactions;
using LinqToSqlServerHelper;

namespace SilverlightApplication4_Web
{
     public class Service1 : IService1
    {


         public string SaveCustomersAndOrders(List<Customer> cOriginals, List<Customer> cModifieds, List<Order> oOriginals, List<Order> oModifieds)
         {

             using (TransactionScope tran = new TransactionScope())
             {
                 DataClasses1DataContext db = new DataClasses1DataContext();

                 try
                 {
                     LinqHelper.SaveTable<Customer>(db.Customers, cOriginals, cModifieds);
                     LinqHelper.SaveTable<Order>(db.Orders, oOriginals, oModifieds);

                     tran.Complete();

                     return "Successfull";
                 }
                 catch (Exception e)
                 {

                     return e.Message;
                 }


             }
         }

        public List<Customer> GetCustomersByCity(string city)
        {
            DataClasses1DataContext db = new DataClasses1DataContext();
            var query = from c in db.Customers
                        where c.City.StartsWith(city)
                        select c;

            return query.ToList();
        }







        

        public string SaveCustomers(List<Customer> originals, List<Customer> modifieds)
        {
            try
            {
                DataClasses1DataContext db = new DataClasses1DataContext();
                LinqHelper.SaveTable<Customer>(db.Customers, originals, modifieds);
                return "Successfull";
            }
            catch (Exception e)
            {
                return e.Message;
            }
        }



        #region IService1 Members


        public List<Order> GetOrderByCustomerID(string CustomerID)
        {
            DataClasses1DataContext db = new DataClasses1DataContext();

            var query = from o in db.Orders
                        where o.CustomerID == CustomerID
                        select o;

            return query.ToList();
        }

        #endregion
    }
}


