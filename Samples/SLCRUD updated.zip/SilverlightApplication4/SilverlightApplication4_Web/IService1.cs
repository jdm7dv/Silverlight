﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace SilverlightApplication4_Web
{
    // NOTE: If you change the interface name "IService1" here, you must also update the reference to "IService1" in Web.config.
    [ServiceContract]
    public interface IService1
    {
        [OperationContract]
        List<Customer> GetCustomersByCity(string city);

        [OperationContract]
        List<Order> GetOrderByCustomerID(string CustomerID);

        [OperationContract]
        string SaveCustomers(List<Customer> originals, List<Customer> modifieds);

        [OperationContract]
        string SaveCustomersAndOrders(List<Customer> cOriginals, List<Customer> cModifieds, List<Order> oOriginals, List<Order> oModifieds);
     
       
    }
}
