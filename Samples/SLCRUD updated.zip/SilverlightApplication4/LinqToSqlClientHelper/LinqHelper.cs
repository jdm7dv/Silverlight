﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Collections.Generic;
using System.Reflection;

namespace LinqToSqlClientHelper
{
    public class LinqHelper
    {
        public static List<T> GetShallowCopy<T>(List<T> originalTypeList)
        {
            List<T> cloneList = new List<T>();
            foreach (T item in originalTypeList)
            {
                object cloneItem = Activator.CreateInstance(typeof(T));

                foreach (PropertyInfo property in item.GetType().GetProperties())
                {
                    property.SetValue(cloneItem, property.GetValue(item, null), null);
                }

                cloneList.Add((T)cloneItem);
            }

            return cloneList;
        }

        //gets only the inserted, modified and deleted rows to send back to the server
        public static void GetModifiedsObjectsOnly<T>(List<T> modifieds, List<T> originals, string primaryKey)
        {


            List<T> originalToRemove = new List<T>();
            List<T> modifiedToRemove = new List<T>();


            foreach (T m in modifieds)
            {
                foreach (T o in originals)
                {
                    if (o.GetType().GetProperty(primaryKey).GetValue(o, null).Equals(m.GetType().GetProperty(primaryKey).GetValue(m, null)))
                    {
                        checkIfModified<T>(m, o, modifiedToRemove, originalToRemove);
                        break;
                    }
                }
            }

            if (modifiedToRemove.Count > 0)
            {
                foreach (T m in modifiedToRemove)
                    modifieds.Remove(m);
            }

            if (originalToRemove.Count > 0)
            {
                foreach (T o in originalToRemove)
                    originals.Remove(o);
            }
        }

        private static void checkIfModified<T>(T m, T o, List<T> modifiedToRemove, List<T> originalToRemove)
        {
            bool isModified = false;
            foreach (PropertyInfo property in m.GetType().GetProperties())
            {

                object propertyValueM = property.GetValue(m,null);
                object propertyValueO = o.GetType().GetProperty(property.Name).GetValue(o, null);

                if (propertyValueM != null)
                {
                    if (!propertyValueM.Equals(propertyValueO))
                    {
                        isModified = true;
                        break;
                    }
                }
                else
                {
                    if (propertyValueO != null)
                    {
                        isModified = true;
                        break;
                    }
                }
            }

            if (!isModified)
            {
                originalToRemove.Add(o);
                modifiedToRemove.Add(m);

            }
        }
    }
}
