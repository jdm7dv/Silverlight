﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Linq;
using System.Reflection;
using System.Data.Linq.Mapping;

namespace LinqToSqlServerHelper
{
    public class LinqHelper
    {

        public static void SaveTable<T>(ITable table, List<T> originals, List<T> modifieds)
        {
            int inserted = 0;

            PropertyInfo primaryKey = null;

            //find the property marked as primary key
            foreach (PropertyInfo column in table.ElementType.GetProperties())
            {
                ColumnAttribute[] ca = (ColumnAttribute[])column.GetCustomAttributes(typeof(ColumnAttribute), false);
                if (ca[0].IsPrimaryKey == true)
                {
                    primaryKey = column;
                    break;
                }

            }


            foreach (T modified in modifieds)
            {
                bool match = false;
                if (originals != null)
                {
                    foreach (T original in originals)
                    {
                        //if the record exis in both collections then is an update
                        if (primaryKey.GetValue(original, null).Equals(primaryKey.GetValue(modified, null)))
                        {
                            //LINQ to SQL will take care for the optimistic locking check
                            table.Attach(modified, original);
                            match = true;
                            break;
                        }
                    }
                }

                //if a record exist only in the modifieds collection it means is an insert
                if (!match)
                {
                    inserted++;
                    table.InsertOnSubmit(modified);
                }


            }

            
            //check if there are deleted records
            if (originals != null && originals.Count > modifieds.Count - inserted)
            {

                foreach (T original in originals)
                {
                    bool match = false;
                    foreach (T modified in modifieds)
                    {
                        //check if the record exist only in the originals collection
                        if (primaryKey.GetValue(original, null).Equals(primaryKey.GetValue(modified, null)))
                        {
                            match = true;
                            break;
                        }

                    }
                    //if dosent have a modified counterpart it means that is a delete
                    if (!match)
                    {
                        table.Attach(original);
                        table.DeleteOnSubmit(original);
                    }


                }
            }

            //save the changes on the the DB
            table.Context.SubmitChanges();



        }

    }
}
