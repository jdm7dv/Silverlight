﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using SilverlightApplication4.ServiceReference1;
using System.Windows.Browser;
using System.Reflection;
using LinqToSqlClientHelper;

namespace SilverlightApplication4
{
    public partial class Page : UserControl
    {

        List<Customer> customersOriginals;

        List<Customer> customersModifieds;

        public Page()
        {
            InitializeComponent();
        }

      

        private void queryButton_Click(object sender, RoutedEventArgs e)
        {
            ServiceReference1.Service1Client client = new SilverlightApplication4.ServiceReference1.Service1Client();

            //binding settings to allow reciving messages > than 64Kb.
            System.ServiceModel.BasicHttpBinding binding = new System.ServiceModel.BasicHttpBinding();
            binding.MaxBufferSize = 2147483647;
            binding.MaxReceivedMessageSize = 2147483647;
            client.Endpoint.Binding = binding;

            client.GetCustomersByCityCompleted += new EventHandler<SilverlightApplication4.ServiceReference1.GetCustomersByCityCompletedEventArgs>(client_GetCustomersByCityCompleted);
            client.GetCustomersByCityAsync(textBox.Text);
        }

        private void saveCustomersButton_Click(object sender, RoutedEventArgs e)
        {

            //Customer newC = new Customer();

            //newC.CustomerID = "RON99";
            //newC.CompanyName = "Ronnie";
            //newC.City = "London";

            //customersModifieds.Add(newC);

            //Customer c = customersModifieds.First(cu => cu.CustomerID.Equals("RON99"));

            //customersModifieds.Remove(c);
            
            
            LinqHelper.GetModifiedsObjectsOnly<Customer>(customersModifieds, customersOriginals, "CustomerID");

            ServiceReference1.Service1Client client = new SilverlightApplication4.ServiceReference1.Service1Client();
            client.SaveCustomersCompleted += new EventHandler<SaveCustomersCompletedEventArgs>(client_SaveCustomersCompleted);
            client.SaveCustomersAsync(customersOriginals.ToArray(), customersModifieds.ToArray());
       
        }

        void client_SaveCustomersCompleted(object sender, SaveCustomersCompletedEventArgs e)
        {
            HtmlPage.Window.Alert(e.Result);
        }

        private void newCustomerAndOrderBuitton_Click(object sender, RoutedEventArgs e)
        {
            List<Order> ordersModifieds = new List<Order>();

            Customer newC = new Customer();

            newC.CustomerID = "RON34";
            newC.CompanyName = "Ronnie";
            newC.City = "London";

            customersModifieds.Add(newC);

            Order newO = new Order();
            newO.CustomerID = newC.CustomerID;
            newO.ShipCity = "London";

            ordersModifieds.Add(newO);

            LinqHelper.GetModifiedsObjectsOnly<Customer>(customersModifieds, customersOriginals, "CustomerID");

            ServiceReference1.Service1Client client = new Service1Client();
            client.SaveCustomersAndOrdersCompleted += new EventHandler<SaveCustomersAndOrdersCompletedEventArgs>(client_SaveCustomersAndOrdersCompleted);
            client.SaveCustomersAndOrdersAsync(null, customersModifieds.ToArray(), null, ordersModifieds.ToArray());



        }

        void client_SaveCustomersAndOrdersCompleted(object sender, SaveCustomersAndOrdersCompletedEventArgs e)
        {
            HtmlPage.Window.Alert(e.Result);
        }

       

        void client_GetCustomersByCityCompleted(object sender, SilverlightApplication4.ServiceReference1.GetCustomersByCityCompletedEventArgs e)
        {
            customersOriginals = e.Result.ToList();

            customersModifieds = LinqHelper.GetShallowCopy<Customer>(customersOriginals);


            dataGrid.ItemsSource = customersModifieds;
        }

        private void dataGrid_SelectionChanged(object sender, EventArgs e)
        {
            if(dataGrid.SelectedItem is Customer)
            {
                string id = ((Customer)dataGrid.SelectedItem).CustomerID;
                ServiceReference1.Service1Client client = new Service1Client();
                client.GetOrderByCustomerIDCompleted += new EventHandler<GetOrderByCustomerIDCompletedEventArgs>(client_GetOrderByCustomerIDCompleted);

                client.GetOrderByCustomerIDAsync(id);
            }
        }

        void client_GetOrderByCustomerIDCompleted(object sender, GetOrderByCustomerIDCompletedEventArgs e)
        {
            dataGrid1.ItemsSource = e.Result;
               
        }

       

    
      
    }
}
