﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Windows.Controls.Primitives;

namespace HeaderControl
{

    [TemplatePart(Name = ExpandoHeaderControl.RootElement, Type = typeof(FrameworkElement))]
    [TemplatePart(Name = ExpandoHeaderControl.HeaderElement, Type = typeof(ContentControl))]
    [TemplatePart(Name = ExpandoHeaderControl.ContentElement, Type = typeof(ContentControl))]
    [TemplatePart(Name = ExpandoHeaderControl.ButtonElement, Type = typeof(ToggleButton))]
    [TemplatePart(Name = ExpandoHeaderControl.OpenAnimation, Type = typeof(Storyboard))]
    [TemplatePart(Name = ExpandoHeaderControl.CloseAnimation, Type = typeof(Storyboard))]
    public class ExpandoHeaderControl : ContentControl
    {
        private const string RootElement = "RootElement";
        private const string HeaderElement = "HeaderElement";
        private const string ContentElement = "ContentElement";
        private const string ButtonElement = "ButtonElement";
        private const string OpenAnimation = "OpenAnimation";
        private const string CloseAnimation = "CloseAnimation";

        private FrameworkElement _rootElement;
        private ToggleButton _buttonElement;
        private Storyboard _openAnimation, _closeAnimation;
        private bool _templateLoaded;


        public ExpandoHeaderControl()
        {
            // Default to true.
            IsOpened = true;
        }


        // Content property for the header
        //
        public static readonly DependencyProperty HeaderContentProperty =
            DependencyProperty.Register("HeaderContent", typeof(object), typeof(ExpandoHeaderControl), null);

        public object HeaderContent
        {
            get { return (object)GetValue(HeaderContentProperty); }
            set { SetValue(HeaderContentProperty, value); }
        }


        // Property that determines if the expando is opened.
        //
        public static readonly DependencyProperty IsOpenedProperty =
            DependencyProperty.Register("IsOpened", typeof(bool), typeof(ExpandoHeaderControl), new PropertyChangedCallback(NotifyIsOpenedChanged));

        private static void NotifyIsOpenedChanged(DependencyObject dpObj, DependencyPropertyChangedEventArgs change)
        {
            bool isOpened = (bool)change.NewValue;

            ((ExpandoHeaderControl)dpObj).IsOpened = isOpened;
        }

        public bool IsOpened
        {
            get
            {
                if (_buttonElement != null)
                {
                    return _buttonElement.IsChecked ?? false;
                }
                else
                {
                    return (bool)GetValue(IsOpenedProperty);
                }
            }
            set
            {
                if (_buttonElement != null)
                {
                    _buttonElement.IsChecked = value;
                }
                else
                {
                    SetValue(IsOpenedProperty, value);
                }
                ChangeVisualState();
            }
        }


        protected override void OnApplyTemplate()
        {
            base.OnApplyTemplate();

            // Fish out all of the template children and wire them up.
            //
            _rootElement = GetTemplateChild(ExpandoHeaderControl.RootElement) as FrameworkElement;

            if (_rootElement != null)
            {
                bool opened = IsOpened;

                _buttonElement = GetTemplateChild(ExpandoHeaderControl.ButtonElement) as ToggleButton;

                if (_buttonElement != null)
                {
                    // setup the buttons initial state.
                    //
                    _buttonElement.IsChecked = opened;
                    _buttonElement.Click += new RoutedEventHandler(ToggleButtonElement_Click);

                }

                _openAnimation = _rootElement.Resources[ExpandoHeaderControl.OpenAnimation] as Storyboard;
                _closeAnimation = _rootElement.Resources[ExpandoHeaderControl.CloseAnimation] as Storyboard;
            }

            ChangeVisualState();
            _templateLoaded = true;
        }

        void ToggleButtonElement_Click(object sender, RoutedEventArgs e)
        {
            // just update our state.
            //
            ChangeVisualState();
        }

        private void ChangeVisualState()
        {
            // manage the animations base on the current state.
            //                        
            Storyboard toState = IsOpened ? _openAnimation : _closeAnimation;
            Storyboard fromState = !IsOpened ? _openAnimation : _closeAnimation;

            if (toState != null)
            {

                if (!_templateLoaded)
                {
                    toState.SkipToFill();
                }
                else
                {
                    toState.Begin();
                }
            }

            if (fromState != null)
            {
                fromState.Stop();
            }
        }
    }
}
