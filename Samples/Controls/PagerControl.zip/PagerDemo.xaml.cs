﻿using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;

namespace BlogEngine.UI
{
    public partial class PagerDemo : UserControl
    {
        #region Variables
        private List<SampleObject> _items = new List<SampleObject>();
        private int _pageSize = 5;
        private int _skip = 0;
        #endregion

        public PagerDemo()
        {
            InitializeComponent();
            this.Loaded += new RoutedEventHandler(PagerDemo_Loaded);
        }

        protected void PagerDemo_Loaded(object sender, RoutedEventArgs e)
        {
            _items = BuildData();

            Pager pager = new Pager(_items.Count / _pageSize, 2);
            pager.Click += new Pager.PagerButtonClick(PagerControl_Click);

            if (_skip == 0)
                pager.PageIndex = 1;
            else
                pager.PageIndex = (_skip / _pageSize) + 1;

            dgItems.ItemsSource = _items.Skip(_skip).Take(_pageSize);
            
            spPager.Children.Clear();
            spPager.Children.Add(pager);
        }

        #region Internal
        private List<SampleObject> BuildData()
        {
            List<SampleObject> items = new List<SampleObject>();
            
            for (int i = 1; i < 101; i++)
            {
                items.Add(new SampleObject { FirstName = "Steve" + i.ToString(), LastName = "Dunlap", PhoneNumber = "123.456.7890" });
                items.Add(new SampleObject { FirstName = "Tara" + i.ToString(), LastName = "Dunlap", PhoneNumber = "123.456.7890" });
                items.Add(new SampleObject { FirstName = "Kevin" + i.ToString(), LastName = "Jones", PhoneNumber = "123.456.7890" });
                items.Add(new SampleObject { FirstName = "Jane" + i.ToString(), LastName = "Smith", PhoneNumber = "123.456.7890" });
                items.Add(new SampleObject { FirstName = "John" + i.ToString(), LastName = "Smith", PhoneNumber = "123.456.7890" });
            }

            return items;
        }
        #endregion

        #region Event Handler
        protected void PagerControl_Click(object sender, RoutedEventArgs e)
        {
            Button b = e.OriginalSource as Button;

            if (b.Content.ToString() == "Previous")
                _skip -= _pageSize;
            else if (b.Content.ToString() == "Next")
                _skip += _pageSize;
            else
            {
                int.TryParse(b.Content.ToString(), out _skip);
                _skip = (_skip * _pageSize) - _pageSize;
            }

            if (_skip < 0)
                _skip = 0;

            dgItems.ItemsSource = _items.Skip(_skip).Take(_pageSize);
        }
        #endregion
    }
    public class SampleObject
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string PhoneNumber { get; set; }
    }
}
