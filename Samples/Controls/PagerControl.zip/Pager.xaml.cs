﻿using System.Globalization;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace BlogEngine.UI
{
    /// <summary>
    /// Renders a Pager control to be used in any fashion
    /// Useful for any control(s) that require paging functionality
    /// </summary>
    public partial class Pager : UserControl
    {
        #region Properties
        /// <summary>
        /// Total Number of Pages for this Pager Control
        /// </summary>
        public int PageCount { get; set; }
        /// <summary>
        /// Current Page Index
        /// </summary>
        public int PageIndex { get; set; }
        /// <summary>
        /// Number of buttons to render before/after current selection
        /// For example, if = 2, buttons appear for a control with 100 pages
        /// /// Button 5 selected:
        ///     Previous 1 2 3 4 (5) 6 7 ... 99 100 Next
        /// Button 6 selected:
        ///     Previous 1 2 ... 4 5 (6) 7 8 ... 99 100 Next
        /// Button 95 selected
        ///     Previous 1 2 ... 93 94 (95) 96 97 ... 99 100 Next
        /// Button 96 selected
        ///     Previous 1 2 ... 94 95 (96) 97 98 99 100 Next
        /// </summary>
        public int PageButtonCount { get; set; }
        /// <summary>
        /// EVent delegate for a specific Pager Button
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        public delegate void PagerButtonClick(object sender, RoutedEventArgs e);
        /// <summary>
        /// Event handler for a specific Pager Button
        /// </summary>
        public event PagerButtonClick Click;
        #endregion

        public Pager()
        {
            InitializeComponent();

            // Default Settings
            PageCount = 15;
            PageIndex = 1;
            PageButtonCount = 3;

            this.Loaded += new RoutedEventHandler(Pager_Loaded);
        }
        public Pager(int pageCount, int pageButtonCount)
        {
            InitializeComponent();

            PageCount = pageCount;
            PageIndex = 1;
            PageButtonCount = pageButtonCount;

            this.Loaded += new RoutedEventHandler(Pager_Loaded);
        }

        protected void Pager_Loaded(object sender, RoutedEventArgs e)
        {
            BuildPager();
        }

        #region Internal
        /// <summary>
        /// Renders a Button control for the Pager
        /// </summary>
        /// <param name="text">Text to display</param>
        /// <param name="inner">Flag to denote if this refers to the inner buttons or the Previous/Next buttons</param>
        /// <param name="enabled">Flag to denote if this button is enabled</param>
        /// <returns>Button</returns>
        private Button BuildButton(string text, bool inner, bool enabled)
        {
            Button b = new Button()
            {
                Content = text,
                Tag = text,
                Style = inner ? this.Resources["PagerButtonInnerStyle"] as Style : this.Resources["PagerButtonOuterStyle"] as Style,
                Width = 45
            };

            if (inner == false)
                b.Width = 75;

            b.IsEnabled = enabled;

            b.Click += new RoutedEventHandler(PagerButton_Click);

            return b;
        }
        /// <summary>
        /// Renders a selected Button or the Hellip (...) TextBlock
        /// </summary>
        /// <param name="text">Text to display</param>
        /// <param name="border">Flag to denote if this button is to have a border</param>
        /// <returns>UIElement (either a TextBlock or a Border with a TextBlock within)</returns>
        private UIElement BuildSpan(string text, bool border)
        {
            if (border)
            {
                TextBlock t = new TextBlock()
                {
                    Text = text,
                    TextAlignment = TextAlignment.Center,
                    VerticalAlignment = VerticalAlignment.Center,
                    Width = 30
                };
                Border b = new Border()
                {
                    Margin = new Thickness(3, 3, 3, 3),
                    BorderThickness = new Thickness(0.5, 0.5, 0.5, 0.5),
                    BorderBrush = new SolidColorBrush(Color.FromArgb(255, 0, 0, 255)),
                    Width = 30,
                    Height = 22,
                    HorizontalAlignment = HorizontalAlignment.Center,
                    VerticalAlignment = VerticalAlignment.Center
                };
                b.Child = t;
                return b;
            }
            else
            {
                return new TextBlock()
                {
                    Text = text,
                    Width = 30,
                    Height = 22,
                    TextAlignment = TextAlignment.Center,
                    VerticalAlignment = VerticalAlignment.Bottom
                };
            }
        }
        
        /// <summary>
        /// Build the Pager Control
        /// </summary>
        private void BuildPager()
        {
            this.spPager.Children.Clear();

            if (PageCount > 1)
            {
                int min = PageIndex - PageButtonCount;
                int max = PageIndex + PageButtonCount;

                if (max > PageCount)
                    min -= max - PageCount;
                else if (min < 1)
                    max += 1 - min;

                // Previous Button
                if (PageIndex > 1)
                    this.spPager.Children.Add(BuildButton("Previous", false, true));
                else // Disabled State
                    this.spPager.Children.Add(BuildButton("Previous", false, false));

                // Middle Buttons
                bool needDiv = false;
                for (int i = 1; i <= PageCount; i++)
                {
                    if (i <= 2 || i > PageCount - 2 || (min <= i && i <= max))
                    {
                        string text = i.ToString(NumberFormatInfo.InvariantInfo);

                        if (i == PageIndex) // Currently Selected Index
                            this.spPager.Children.Add(BuildSpan(text, false));
                        else
                            this.spPager.Children.Add(BuildButton(text, true, true));

                        needDiv = true;
                    }
                    else if (needDiv)
                    {
                        // This will add the hellip (...) TextBlock
                        this.spPager.Children.Add(BuildSpan("...", false));
                        needDiv = false;
                    }
                }

                // Next Button
                if (PageIndex < PageCount)
                    this.spPager.Children.Add(BuildButton("Next", false, true));
                else // Disabled State
                    this.spPager.Children.Add(BuildButton("Next", false, false));
            }
        }
        #endregion

        #region Event Handlers
        /// <summary>
        /// Handles Pager Button click
        /// Sets proper PageIndex for rendering
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void PagerButton_Click(object sender, RoutedEventArgs e)
        {
            Button b = e.OriginalSource as Button;

            if (b.Tag.ToString() == "Previous")
            {
                PageIndex--;
            }
            else if (b.Tag.ToString() == "Next")
            {
                PageIndex++;
            }
            else
            {
                int p = PageIndex;
                int.TryParse(b.Tag.ToString(), out p);
                PageIndex = p;
            }
            
            BuildPager();
            Click(sender, e);
        }
        #endregion
    }
}
