﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Resources;
using System;
using System.Windows.Markup;

// The following GUID is for the ID of the typelib if this project is exposed to COM
[assembly: Guid("e26dd271-436d-483d-91e2-de61b3ffe0af")]
[assembly: AssemblyTitle("System.Windows.Controls")]
[assembly: AssemblyDescription("FloatableWindow Silverlight Control")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Tim Heuer")]
[assembly: AssemblyProduct("FloatableWindow")]
[assembly: AssemblyCopyright("Licensed under Ms-PL")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: NeutralResourcesLanguage("en-US")]
[assembly: ComVisible(false)]
[assembly: AssemblyVersion("2.0.5.0")]
[assembly: AssemblyFileVersion("3.0.40624.4")]
[assembly: CLSCompliant(true)]
[assembly: XmlnsPrefix("clr-namespace:System.Windows.Controls;assembly=FloatableWindow", "windows")]
[assembly: XmlnsDefinitionAttribute("clr-namespace:System.Windows.Controls;assembly=FloatableWindow", "System.Windows.Controls")]