﻿This is an adaptation of the ChildWindow control for Silverlight in the 
Microsoft Silverlight SDK.  The ChildWindow control is licensed under the 
Ms-PL license, and as-such, FloatableWindow is also licensed under Ms-PL.

This was build as a proof of concept and no warranties are provided, 
implied or otherwise.  The author who adapted this control is 
Tim Heuer, who may be contacted at http://timheuer.com/blog/.