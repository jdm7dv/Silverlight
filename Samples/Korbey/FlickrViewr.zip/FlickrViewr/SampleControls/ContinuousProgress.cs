﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace SampleControls
{

    public class ContinuousProgress : Control
    {

        public ContinuousProgress()
        {
            this.IsActive = false;
            DefaultStyleKey = typeof(ContinuousProgress);
        }
        
        public override void OnApplyTemplate()
        {
            base.OnApplyTemplate();
            GoToState(false);
        }




        public static readonly DependencyProperty IsActiveProperty = DependencyProperty.Register("IsActive", typeof(Boolean), typeof(ContinuousProgress), null);

        public Boolean IsActive
        {
            get
            {
                return (Boolean) GetValue(IsActiveProperty);
            }

            set
            {
                SetValue(IsActiveProperty, value);
                GoToState(true);
            }
        }

        private void GoToState(bool useTransitions)
        {
            if (IsActive)
            {
                VisualStateManager.GoToState(this, "Active", useTransitions);
            }
            else
            {
                VisualStateManager.GoToState(this, "Inactive", useTransitions);
            }

        }
    }
}
