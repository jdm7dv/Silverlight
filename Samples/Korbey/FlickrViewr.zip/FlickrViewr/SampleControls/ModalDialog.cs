﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Windows.Controls.Primitives;

namespace SampleControls
{
    public class ModalDialog
    {
        /// <summary>
        ///     Shows a Model Dialog.  Contents of modal dialog is centered (even with app resize).
        /// </summary>
        /// <param name="shadowBrush">Color of non-hit testable background region</param>
        /// <param name="shadowOpacity">Opactiy of non-hit testable background region</param>
        /// <param name="content">Contents of model dialog.  Must have a valid height/width set on it.</param>
        public static void Show(Brush shadowBrush, double shadowOpacity, FrameworkElement content)
        {
            appRootVisual = (FrameworkElement)Application.Current.RootVisual;
            double appWidth = appRootVisual.ActualWidth;
            double appHeight = appRootVisual.ActualHeight;

            // detect app size changes in order to keep contents centered
            appRootVisual.SizeChanged += new SizeChangedEventHandler(AppSizeChanged);

            // create background non-hit testable region (first popup)
            Rectangle rect = new Rectangle();
            rect.Fill = shadowBrush;
            rect.Opacity = shadowOpacity;
            rect.Width = appWidth;
            rect.Height = appHeight;

            backgroundPopup = new Popup();
            backgroundPopup.IsHitTestVisible = false;
            backgroundPopup.Child = rect;
            backgroundPopup.IsOpen = true;
            

            // create contents popup that IS hit testable (second popup)
            contentPopup = new Popup();
            contentPopup.HorizontalOffset = (appWidth - content.Width) / 2 > 50 ? (appWidth - content.Width) / 2 : 50;
            contentPopup.VerticalOffset = (appHeight - content.Height) / 2 > 50 ? (appHeight - content.Height) / 2 : 50;
            contentPopup.Height = appWidth;
            contentPopup.Width = appHeight;

            contentPopup.Child = content;
            contentPopup.IsOpen = true;
            
        }


        static void AppSizeChanged(object sender, SizeChangedEventArgs e)
        {
            Rectangle backgroundRect = (Rectangle) backgroundPopup.Child;
            backgroundRect.Width = e.NewSize.Width;
            backgroundRect.Height = e.NewSize.Height;

            FrameworkElement content =  (FrameworkElement) contentPopup.Child;

            contentPopup.HorizontalOffset = (e.NewSize.Width - content.Width) / 2 > 50 ? (e.NewSize.Width - content.Width) / 2 : 50;
            contentPopup.VerticalOffset = (e.NewSize.Height - content.Height) / 2 > 50 ? (e.NewSize.Height - content.Height) / 2 : 50;
        }

        
        /// <summary>
        ///   Closes modal dialog
        /// </summary>
        public static void Close()
        {
            Close(DialogResult.None, null);
        }


        public static void Close(DialogResult result, object data)
        {
            backgroundPopup.IsOpen = false;
            contentPopup.IsOpen = false;

            backgroundPopup = null;
            contentPopup = null;

            appRootVisual.SizeChanged -= new SizeChangedEventHandler(AppSizeChanged);
            appRootVisual = null;

            ModalDialogClosedEventArgs e = new ModalDialogClosedEventArgs(result, data);
            if (Closed != null)
            {
                Closed(null, e);
            }
        }

        public static event EventHandler<ModalDialogClosedEventArgs> Closed;

        private static Popup backgroundPopup, contentPopup;
        private static FrameworkElement appRootVisual;
    }

    public class ModalDialogClosedEventArgs : EventArgs
    {
        internal ModalDialogClosedEventArgs(DialogResult result, object data)
        {
            this.data = data;
            this.result = result;

        }

        public DialogResult Result
        {
            get
            {
                return result;
            }

        }


        public object Data
        {
            get
            {
                return data;
            }

        }

        private DialogResult result;
        private object data;
    }
}
