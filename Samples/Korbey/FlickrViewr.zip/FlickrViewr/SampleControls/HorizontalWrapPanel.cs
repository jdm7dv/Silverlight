﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace SamplePanels
{
    public class HorizontalWrapPanel : Panel
    {
        public HorizontalWrapPanel()
            : base()
        {

        }


        #region Layout Methods

        protected override Size MeasureOverride(Size availableSize)
        {
            double currentRowWidth = 0, currentRowMaxHeight = 0;
            double currentRowY = 0;
            double desiredHeight = 0, desiredWidth = 0;

            foreach (UIElement child in Children)
            {
                if (child != null)
                {
                    child.Measure(availableSize);

                    double childDesiredWidth = child.DesiredSize.Width;
                    double childDesiredHeight = child.DesiredSize.Height;

                    if ((currentRowWidth + childDesiredWidth) > availableSize.Width)
                    {
                        //wraps onto next row
                        currentRowWidth = 0;
                        currentRowY = desiredHeight;
                        currentRowMaxHeight = 0;
                    }

                    //add to the row
                    currentRowWidth += childDesiredWidth;
                    desiredWidth = Math.Max(desiredWidth, currentRowWidth);

                    currentRowMaxHeight = Math.Max(currentRowMaxHeight, childDesiredHeight);
                    desiredHeight = Math.Max(desiredHeight, currentRowY + currentRowMaxHeight);
                }
            }

            return new Size(desiredWidth, desiredHeight);
        }


        protected override Size ArrangeOverride(Size finalSize)
        {
            double currentRowWidth = 0;
            double currentRowMaxHeight = 0;
            double currentRowY = 0;
            int currentRowNum = 0;
            int numCols = 0;
            int start = 0, end = 0;

            foreach (UIElement child in Children)
            {
                double childWidth = child.DesiredSize.Width;
                double childHeight = child.DesiredSize.Height;

                if ((currentRowWidth + childWidth) > finalSize.Width)
                {

                    if ((currentRowMaxHeight + currentRowY) <= finalSize.Height)
                    {
                        // arrange this line
                        arrangeLine(start, end - 1, 0, currentRowY, currentRowNum);

                        // update for placement on following row
                        currentRowWidth = 0;
                        currentRowY += currentRowMaxHeight;
                        currentRowNum++;

                        start = end;
                    }
                    else
                    {
                        break;

                    }
                }
                end++;

                // update data for current row
                currentRowWidth += childWidth;
                currentRowMaxHeight = Math.Max(currentRowMaxHeight, childHeight);
                numCols++;
            }

            if ((start < Children.Count) && (currentRowMaxHeight + currentRowY) <= finalSize.Height)
            {
                arrangeLine(start, end - 1, 0, currentRowY, currentRowNum);
            }

            return finalSize;
        }


        private void arrangeLine(int startChild, int endChild, double x, double y, int currentRowNum)
        {
            double currentRowWidth = 0;
            int colNum = 0;

            for (int i = startChild; i <= endChild; i++)
            {
                UIElement child = Children[i];
                if (child != null)
                {
                    double childWidth = child.DesiredSize.Width;
                    double childHeight = child.DesiredSize.Height;

                    child.Arrange(new Rect(x + currentRowWidth, y, childWidth, childHeight));
                    SetRowProperty(child, currentRowNum);
                    SetColumnProperty(child, colNum++);
                    currentRowWidth += childWidth;
                }
            }
        }


        public readonly static DependencyProperty RowProperty = DependencyProperty.RegisterAttached("Row", typeof(int), typeof(HorizontalWrapPanel), null);

        public int GetRowProperty(DependencyObject target)
        {
            return (int) target.GetValue(RowProperty);
        }

        private void SetRowProperty(DependencyObject target, int value)
        {
            target.SetValue(RowProperty, value);
        }



        public readonly static DependencyProperty ColumnProperty = DependencyProperty.RegisterAttached("Column", typeof(int), typeof(HorizontalWrapPanel), null);

        public int GetColumnProperty(DependencyObject target)
        {
            return (int)target.GetValue(ColumnProperty);
        }

        private void SetColumnProperty(DependencyObject target, int value)
        {
            target.SetValue(ColumnProperty, value);
        }

        #endregion

    }
}
