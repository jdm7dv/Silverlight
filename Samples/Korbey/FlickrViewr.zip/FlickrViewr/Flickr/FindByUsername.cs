﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace Flickr
{
    public class FindByUsername : Request
    {


        public FindByUsername()
        {
            this.Username = "";
        }

        protected override string Method { get { return "flickr.people.findByUsername"; } }

        [SerializationName("username")]
        public String Username { get; set; }
    }


}
