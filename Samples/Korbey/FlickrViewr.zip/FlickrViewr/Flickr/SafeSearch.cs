﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace Flickr
{
    public class SafeSearch
    {
        private static SafeSearch safe = new SafeSearch("1");
        private static SafeSearch moderate = new SafeSearch("2");
        private static SafeSearch restricted = new SafeSearch("3");


        public static SafeSearch Safe { get { return SafeSearch.safe; } }
        public static SafeSearch Moderate { get { return SafeSearch.moderate; } }
        public static SafeSearch Restricted { get { return SafeSearch.restricted; } }
        

		private string title;
        private SafeSearch(string title)
        {
			this.title = title;
		}

		public override string ToString() {
			return this.title;
		}
	}}
