﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Collections.Generic;
using System.Xml.Serialization;

namespace Flickr
{

    public class PhotoCollection
    {

        public PhotoCollection()
        {
            this.Photos = new List<Photo>();
        }

        [XmlAttribute("page")]
        public long Page { get; set; }

        [XmlAttribute("pages")]
        public long Pages { get; set; }

        [XmlAttribute("perpage")]
        public int PerPage { get; set; }

        [XmlAttribute("total")]
        public long Total { get; set; }

        [XmlElement("photo")]
        public List<Photo> Photos { get; set; }
    }
}
