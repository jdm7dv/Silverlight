﻿using System;
namespace Flickr {
	public class ResponseCompletedEventArgs : EventArgs{

		public ResponseCompletedEventArgs(Response response) {
			this.Response = response;
		}

		public Response Response { get; private set; }

	}
}
