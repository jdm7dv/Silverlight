﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace Flickr
{
    public class TagMode
    {

        private static TagMode any = new TagMode("any");
        private static TagMode all = new TagMode("all");


        public static TagMode Any { get { return TagMode.any; } }
        public static TagMode All { get { return TagMode.all; }}

		private string title;
        private TagMode(string title)
        {
			this.title = title;
		}

		public override string ToString() {
			return this.title;
		}
	}
}
