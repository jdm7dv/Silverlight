﻿using System.Collections.Generic;

namespace Flickr {
	public class Extra {

		private static Extra license = new Extra("license");
		private static Extra dateUpload = new Extra("date_upload");
		private static Extra dateTaken = new Extra("date_taken");
		private static Extra ownerName = new Extra("owner_name");
		private static Extra iconServer = new Extra("icon_server");
		private static Extra originalFormat = new Extra("original_format");
		private static Extra lastUpdate = new Extra("last_update");
		private static Extra geo = new Extra("geo");
		private static Extra tags = new Extra("tags");
		private static Extra machineTags = new Extra("machine_tags");
		private static Extra oDims = new Extra("o_dims");


		public static Extra License { get { return Extra.license; } }
		public static Extra DateUpload { get { return Extra.dateUpload; } }
		public static Extra DateTaken { get { return Extra.dateTaken; } }
		public static Extra OwnerName { get { return Extra.ownerName; } }
		public static Extra IconServer { get { return Extra.iconServer; } }
		public static Extra OriginalFormat { get { return Extra.originalFormat; } }
		public static Extra LastUpdate { get { return Extra.lastUpdate; } }
		public static Extra Geo { get { return Extra.geo; } }
		public static Extra Tags { get { return Extra.tags; } }
		public static Extra MachineTags { get { return Extra.machineTags; } }
		public static Extra ODims { get { return Extra.oDims; } }

		private Extra(string title) {
			this.Title = title;
		}

		private string Title { get; set; }

		public override string ToString() {
			return this.Title;
		}
	}

	public class Extras : List<Extra> {

		public override string ToString() {
			if (this.Count == 0)
				return string.Empty;

			string valueString = "";
			for (int i = 0; i < this.Count; ++i) {
				if (i != 0)
					valueString += ",";
				valueString += this[i].ToString();
			}

			return valueString;
		}
	}
}