﻿
using System.Runtime.Serialization;
using System.Xml.Serialization;
using System.Collections.Generic;
using System.Collections;
using System;


namespace Flickr
{
    [XmlRoot("rsp")]
    public class Response
    {

        [XmlAttribute("stat")]
        public string Status { get; set; }

        [XmlElement("photos")]
        public PhotoCollection Photos { get; set; }

        [XmlElement("err")]
        public Error Error { get; set; }

        [XmlElement("user")]
        public User User { get; set; }
    }

}


