﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Xml.Serialization;

namespace Flickr
{
	[XmlRootAttribute("photo")]
	public class Photo {
		[XmlAttribute("id")]
		public long ID { get; set; }
		[XmlAttribute("owner")]
		public string Owner { get; set; }
		[XmlAttribute("secret")]
		public string Secret { get; set; }
		[XmlAttribute("server")]
		public int Server { get; set; }
		[XmlAttribute("farm")]
		public int Farm { get; set; }
		[XmlAttribute("title")]
		public string Title { get; set; }
		[XmlAttribute("ispublic")]
		public bool IsPublic { get; set; }
		[XmlAttribute("isfriend")]
		public bool IsFriend { get; set; }
		[XmlAttribute("isfamily")]
		public bool IsFamily { get; set; }
		[XmlAttribute("longitude")]
		public double Longitude { get; set; }
		[XmlAttribute("latitude")]
		public double Latitude { get; set; }

		public LongLat LongLat { get { return new LongLat(this.Longitude, this.Latitude); } }

		public Uri GetUri(PhotoSize size) {
			
                return new Uri("http://farm" + this.Farm + ".static.flickr.com/" + this.Server + "/" + this.ID + "_" + this.Secret + GetSizeString(size) + ".jpg", UriKind.Absolute);
            
		}


        //s	small square 75x75
        //t	thumbnail, 100 on longest side
        //m	small, 240 on longest side
        //-	medium, 500 on longest side
        //b	large, 1024 on longest side (only exists for very large original images)
        //o	original image, either a jpg, gif or png, depending on source format
        //public enum PhotoSize { SmallSquare, Thumbnail, Small, Medium, Large, Original };
        private string GetSizeString(PhotoSize size)
        {
            switch (size)
            {
                case PhotoSize.SmallSquare:
                    {
                        return "_s";
                    }

                case PhotoSize.Thumbnail:
                    {
                        return "_t";
                    }
                case PhotoSize.Small:
                    {
                        return "_m";
                    }
                case PhotoSize.Medium:
                    {
                        return "";
                    }
                case PhotoSize.Large:
                    {
                        return "_b";
                    }


            }
            return "";
        }

	}
}

