﻿
using System.Reflection;
using System.Collections.Generic;
using System.Net;
using System;
using System.IO;
using System.Runtime.Serialization;
using System.Xml.Serialization;
using System.Threading;

namespace Flickr {
	public abstract class Request {

		private const string FlickrRestAddress = @"http://api.flickr.com/services/rest/?method=";
		private WebRequest request;

        

		[SerializationName("api_key")]
		public string ApiKey { get; set; }

		public event EventHandler<ResponseCompletedEventArgs> Completed;

        SynchronizationContext syncContext;


		public void Send() {
			this.Cancel();

            syncContext = SynchronizationContext.Current;

			string uri = Request.FlickrRestAddress;
			uri += this.Method;

			uri += this.BuildArguments();

			this.request = WebRequest.Create(new Uri(uri));
			this.request.BeginGetResponse(this.HandleResponse, null);
		}

		public void Cancel() {
			if (this.request != null) {
				this.request.Abort();
				this.request = null;
			}
		}

		private void HandleResponse(IAsyncResult result) {
			if (this.request != null) {
				WebResponse webResponse = this.request.EndGetResponse(result);
				this.request = null;

				Stream responseStream = webResponse.GetResponseStream();

                syncContext.Post(DeserializeResponse, responseStream);

			}
		}


        private void DeserializeResponse(object responseStream)
        {
            XmlSerializer serializer = new XmlSerializer(typeof(Response));
            Response response = (Response)serializer.Deserialize((Stream) responseStream);

            if (this.Completed != null)
                this.Completed(this, new ResponseCompletedEventArgs(response));
        }

		protected abstract string Method { get; }

		protected virtual string BuildArguments() {
			Dictionary<string, string> arguments = new Dictionary<string, string>();

			string argumentsString = "";

			foreach (PropertyInfo property in this.GetType().GetProperties()) {
				SerializationNameAttribute nameAttribute = SerializationNameAttribute.GetAttribute(property);

				if (nameAttribute != null) {
					object value = property.GetValue(this, null);
					if (value != null) {
						string valueString = value.ToString();
						if (!string.IsNullOrEmpty(valueString)) {
							argumentsString += "&" + nameAttribute.Name + "=" + valueString;
						}
					}
				}
			}
			return argumentsString;
		}


	}
}
