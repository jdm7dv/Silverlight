﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Collections.Generic;
using System.Collections.ObjectModel;

namespace Flickr
{
    public class Tags : List<string>
    {
        public Tags(string[] tags)
            : base(tags)
        { }

        public override string ToString()
        {
            if (this.Count == 0)
                return string.Empty;

            string valueString = "";
            for (int i = 0; i < this.Count; ++i)
            {
                if (i != 0)
                    valueString += ",";
                valueString += this[i].ToString();
            }

            return valueString;
        }

        public static Tags ParseTags(string text)
        {
            char[] deliminators = { ' ', ',', ';', '\t', ':' };

            

            Tags tags = new Tags(text.Split(deliminators));

            return tags;
        }


    }
}