﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace Flickr
{
    //s	small square 75x75
    //t	thumbnail, 100 on longest side
    //m	small, 240 on longest side
    //-	medium, 500 on longest side
    //b	large, 1024 on longest side (only exists for very large original images)
    //o	original image, either a jpg, gif or png, depending on source format
    public enum PhotoSize { SmallSquare, Thumbnail, Small, Medium, Large, Original };


    //date-posted-asc, date-posted-desc, date-taken-asc, date-taken-desc, interestingness-desc, interestingness-asc, and relevance.
    public enum SortOrder { DatePostedAscending, DatePostingDecending, DateTakenAscending, DateTakenDescending,  InterentingnessDescending, InterestingnessAscending, Relevance};




}
