﻿namespace Flickr {
	public struct LongLat {
		private double longitude;
		private double latitude;

		public LongLat(double longitude, double latitude) {
			this.longitude = longitude;
			this.latitude = latitude;
		}

		public double Long {
			get { return this.longitude; }
			set { this.longitude = value; }
		}

		public double Lat {
			get { return this.latitude; }
			set { this.latitude = value; }
		}

		// Because I can :)
		public double λ {
			get { return this.longitude; }
			set { this.longitude = value; }
		}

		// Because I can :)
		public double Φ {
			get { return this.latitude; }
			set { this.latitude = value; }
		}

		public override string ToString() {
			return this.longitude + "," + this.latitude;
		}
	}

	public struct LongLatBox {
		private LongLat topLeft;
		private LongLat bottomRight;

		public LongLatBox(LongLat topLeft, LongLat bottomRight) {
			this.topLeft = topLeft;
			this.bottomRight = bottomRight;
		}

		public LongLat TopLeft {
			get { return this.topLeft; }
			set { this.topLeft = value; }
		}

		public LongLat BottomRight {
			get { return this.bottomRight; }
			set { this.bottomRight = value; }
		}

		public double Left {
			get { return this.topLeft.Long; }
		}

		public double Right {
			get { return this.bottomRight.Long; }
		}

		public double Top {
			get { return this.topLeft.Lat; }
		}

		public double Bottom {
			get { return this.bottomRight.Lat; }
		}

		public override string ToString() {

            if ((this.Left == 0) &&
                (this.Right == 0) &&
                (this.Bottom == 0) &&
                (this.Top == 0))
            {
                return string.Empty;
            }
			return this.Left + "," + this.Bottom + "," + this.Right + "," + this.Top;
		}

		public bool Contains(LongLat longLat) {
			return longLat.Long > this.topLeft.Long && longLat.Long < this.bottomRight.Long &&
				longLat.Lat > this.bottomRight.Lat && longLat.Lat < this.topLeft.Lat;
		}
	}
}
