﻿
using System;
using System.Collections.Generic;

namespace Flickr {
	public class PhotoSearch: Request {

		public PhotoSearch() {
			this.PerPage = 100;

			this.Extras = new Extras();
		}

		protected override string Method { get { return "flickr.photos.search"; } }

		[SerializationName("min_upload_date")]
		public DateTime MinUploadDate { get; set; }

		[SerializationName("sort")]
		public Sort Sort { get; set; }

		[SerializationName("per_page")]
		public int PerPage { get; set; }

		[SerializationName("extras")]
		public Extras Extras { get; set; }

		[SerializationName("bbox")]
		public LongLatBox BoundingBox { get; set; }

        [SerializationName("tags")]
        public Tags Tags { get; set; }

        [SerializationName("user_id")]
        public string UserId { get; set; }

        [SerializationName("tag_mode")]
        public TagMode TagMode { get; set; }

        [SerializationName("safe_search")]
        public SafeSearch SafeSearch { get; set; }

	}

}
