﻿using System;
using System.Reflection;

namespace Flickr {

	public class SerializationNameAttribute : Attribute {

		public SerializationNameAttribute(string name) {
			this.Name = name;
		}

		public string Name { get; set; }

		public static SerializationNameAttribute GetAttribute(PropertyInfo property) {
			object[] attributes = property.GetCustomAttributes(true);
			foreach (object attribute in attributes) {
				SerializationNameAttribute nameAttribute = attribute as SerializationNameAttribute;
				if (nameAttribute != null)
					return nameAttribute;
			}

			return null;
		}
	}
}
