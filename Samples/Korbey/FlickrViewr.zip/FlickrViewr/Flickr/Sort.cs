﻿namespace Flickr {
	public class Sort {

		private static Sort datePostedAsc = new Sort("date-posted-asc");
		private static Sort datePostedDesc = new Sort("date-posted-desc");
		private static Sort dateTakenAsc = new Sort("date-taken-asc");
		private static Sort dateTakenDesc = new Sort("date-taken-desc");
		private static Sort interestingnessAsc = new Sort("interestingness-asc");
		private static Sort interestingnessDesc = new Sort("interestingness-desc");
		private static Sort relevance = new Sort("relevance");

		public static Sort DatePostedAsc { get { return Sort.datePostedAsc; } }
		public static Sort DatePostedDesc { get { return Sort.datePostedDesc; } }
		public static Sort DateTakenAsc { get { return Sort.dateTakenAsc; } }
		public static Sort DateTakenDesc { get { return Sort.dateTakenDesc; } }
		public static Sort InterestingnessAsc { get { return Sort.interestingnessAsc; } }
		public static Sort InterestingnessDesc { get { return Sort.interestingnessDesc; } }
		public static Sort Relevance { get { return Sort.relevance; } }

		private string title;
		private Sort(string title) {
			this.title = title;
		}

		public override string ToString() {
			return this.title;
		}
	}
}
