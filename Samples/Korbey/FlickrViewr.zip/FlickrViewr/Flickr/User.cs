﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Xml.Serialization;

namespace Flickr
{
    public class User
    {
        [XmlAttribute("nsid")]
        public string Nsid { get; set; }

        [XmlElement("username")]
        public string Username { get; set; }
    }
}
