﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Collections.ObjectModel;
using Flickr;
using System.Net;
using System.Windows.Media.Imaging;
using SampleControls;

namespace FlickrViewr
{
    public partial class ImageDetails : UserControl
    {

        public ImageDetails()
        {
            InitializeComponent();
        }

        public ImageDetails(PhotoCollection photos, int index)
        {

            InitializeComponent();

            if (((App)Application.Current).IsSmallResolution)
            {
                Height = 500;
                Width = 400;
                ImageGrid.Height = 300;
                ImageGrid.Height = 300;
            }
            else
            {
                Height = 700;
                Width = 600;
                ImageGrid.Height = 500;
                ImageGrid.Height = 500;
            }
            
            FadeOut.Completed += new EventHandler(FadeOut_Completed);
            this.photoCollection = photos;
            this.index = index;
            DownloadPhoto();
        }

        #region keyboard navigation
        void OnLoaded(object sender, EventArgs e)
        {
            // grab focus in order to be able to respond to key down events
            Focus();
        }

        void OnKeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Left)
            {
                NavigateToPhoto(false);
            }
          
            if (e.Key == Key.Right)
            {
                NavigateToPhoto(true);

            }
        }
        #endregion


        #region Mouse Event Handlers
        private void RightArrow_Click(object sender, RoutedEventArgs e)
        {
            NavigateToPhoto(true);
        }


        private void TextBlock_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            ModalDialog.Close();
        }

        private void LeftArrow_Click(object sender, RoutedEventArgs e)
        {
            NavigateToPhoto(false);
        }
        #endregion


        #region Downloading Photos
        private void UpdatePhoto()
        {
            // start fading out photo
            FadeOut.Begin();

            // end the current "fade in" storyboard
            FadeIn.Stop();
        }

        void FadeOut_Completed(object sender, EventArgs e)
        {
            // once fade out has completed, download new photo
            DownloadPhoto();
        }

        private void DownloadPhoto()
        {
            Uri uri;
            if (((App)Application.Current).IsSmallResolution)
            {
                uri = photoCollection.Photos[index].GetUri(PhotoSize.Small);
            }
            else
            {
                uri = photoCollection.Photos[index].GetUri(PhotoSize.Medium);
            }

            // start download of current photo
            BitmapImage bi = new BitmapImage();
            bi.UriSource = uri;
            bi.DownloadProgress +=new EventHandler<DownloadProgressEventArgs>(bi_DownloadProgress);
            ImageHolder.Source = bi;
            Progress.IsActive = true;

            // update text to show title of current photo
            Title.Text = photoCollection.Photos[index].Title;

            // enable appropriate arrows
            if (index == 0)
            {
                LeftArrow.IsEnabled = false;
            }
            else if (index == photoCollection.Photos.Count - 1)
            {
                RightArrow.IsEnabled = false;
            }
            else
            {
                LeftArrow.IsEnabled = true;
                RightArrow.IsEnabled = true;
            }
        }

        void bi_DownloadProgress(object sender, DownloadProgressEventArgs e)
        {

            if (e.Progress == 100)
            {
                // If download has completed, stop progress control and start fading in photo
                Progress.IsActive = false;
                FadeIn.Begin();
                FadeOut.Stop();
            }
        }

        private void NavigateToPhoto(bool goForward)
        {
            // if at end/beginning, don't do navigate
            if ((goForward && (index == photoCollection.Photos.Count - 1))
                ||
                (!goForward && (index == 0)))
                return;

            int delta = 1;
            if (!goForward)
            {
                delta = -1;
            }

            index += delta;    
            UpdatePhoto();

            for (int i = 0; i <= 2; i++)
            {
                int cacheIndex = index + (i * delta);
                PrefetchPhoto(cacheIndex);
            }

        }

        // Initiates a "prefetch" download for next photo in list.
        // Do not need to hold on to it in memory, as it lands in browser cache.
        void PrefetchPhoto(int i)
        {
            if (i < 0 || i >= photoCollection.Photos.Count)
                return;
            WebClient webClient = new WebClient();

            if (((App)Application.Current).IsSmallResolution)
            {
                webClient.OpenReadAsync(photoCollection.Photos[i].GetUri(PhotoSize.Small));
            }
            else
            {
                webClient.OpenReadAsync(photoCollection.Photos[i].GetUri(PhotoSize.Medium));
            }

        }
        #endregion


        #region private fields
        private PhotoCollection photoCollection;
        
        private int index;
        #endregion

    }

}

