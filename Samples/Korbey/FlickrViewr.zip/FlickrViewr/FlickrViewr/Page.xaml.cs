﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Flickr;
using System.Collections.ObjectModel;
using System.Net;
using System.Windows.Media.Imaging;
using SamplePanels;

namespace FlickrViewr
{
    public partial class Page : UserControl
    {
        // obtain your flickr key here: http://flickr.com/services/api/keys/apply/
        private const string apiKey = @"";
        private const int nThumbnails = 48;

        public Page()
        {
            // Required to initialize variables
            InitializeComponent();
        }

        
        private void OnLoaded(object sender, EventArgs e)
        {

        }

        private void TextBox_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                SearchFlickr();
            }
        }


        private void Button_Click(object sender, RoutedEventArgs e)
        {
            SearchFlickr();
        }

        private void SearchFlickr()
        {
            //clear old search results
            PhotoTray.Children.Clear();
            Message.Text = String.Empty;
            UpdateLayout();
            Progress.IsActive = true;

            if (UsernameTextBox.Text != String.Empty)
            {
                FindUser();
            }
            else
            {
                SearchPhotos(null);
            }
        }

        private void FindUser()
        {
            FindByUsername findByUsername = new FindByUsername();
            findByUsername.ApiKey = apiKey;
            findByUsername.Username = UsernameTextBox.Text;
            findByUsername.Completed += new EventHandler<ResponseCompletedEventArgs>(findByUsername_Completed);
            findByUsername.Send();
        }

        void findByUsername_Completed(object sender, ResponseCompletedEventArgs e)
        {
            if (e.Response.User == null)
            {
                Message.Text = "that user does not exist.";
                Progress.IsActive = false;
            }
            else
            {
                SearchPhotos(e.Response.User);            
            }
            
        }

        private void SearchPhotos(User user)
        {
            //New Search
            PhotoSearch search = new PhotoSearch();
            search.ApiKey = apiKey;
            search.Sort = Sort.InterestingnessDesc;
            search.PerPage = nThumbnails;
            search.Tags = Tags.ParseTags(TagsTextBox.Text);
            search.TagMode = TagMode.All;
            search.SafeSearch = SafeSearch.Safe;
            search.UserId = (user != null) ? user.Nsid : String.Empty;
            search.Completed += new EventHandler<ResponseCompletedEventArgs>(search_Completed);
            search.Send();
        }

        void search_Completed(object sender, ResponseCompletedEventArgs e)
        {
            photoCollection = e.Response.Photos;

            if (photoCollection.Photos.Count == 0)
            {
                Message.Text = "no photos were found.";
                Progress.IsActive = false;
                return;
            }

            for (int i = 0; i < photoCollection.Photos.Count; i++)
            {
                WebClient webClient = new WebClient();
                webClient.OpenReadCompleted += new OpenReadCompletedEventHandler(DownloadThumbnailCompleted);
                Uri uri = photoCollection.Photos[i].GetUri(PhotoSize.SmallSquare);
                webClient.OpenReadAsync(uri, i);
            }
        }


        void DownloadThumbnailCompleted(object sender, OpenReadCompletedEventArgs e)
        {
            if (e.Error == null && e.Cancelled == false)
            {
                BitmapImage bitmapImage = new BitmapImage();
                bitmapImage.SetSource(e.Result);

                ImageControl thumbnailImage = new ImageControl(bitmapImage, photoCollection, (int)e.UserState);
                thumbnailImage.Width = 75;
                thumbnailImage.Height = 75;

                if (Progress.IsActive == true)
                {
                    Progress.IsActive = false;
                }

                PhotoTray.Children.Add(thumbnailImage);
            }
            WebClient webClient = (WebClient)sender;
            webClient.OpenReadCompleted -= new OpenReadCompletedEventHandler(DownloadThumbnailCompleted);
        }

        private PhotoCollection photoCollection;
        
    }
}
