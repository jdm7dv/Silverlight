﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Windows.Media.Imaging;
using Flickr;
using System.Windows.Controls.Primitives;
using System.Collections.ObjectModel;
using SampleControls;
using System.Collections;
using System.Collections.Generic;

namespace FlickrViewr
{

    [TemplateVisualState(Name = "Normal", GroupName="CommonStates")]
    [TemplateVisualState(Name = "MouseOver", GroupName = "CommonStates")]

    [TemplateVisualState(Name = "Unfocused", GroupName = "FocusStates")]
    [TemplateVisualState(Name = "Focused", GroupName = "FocusStates")]
    public partial class ImageControl : Control
    {

        #region ctor & template hookup
        public ImageControl(ImageSource source, PhotoCollection photos, int index)
        {
            this.photos = photos;
            Source = source;
            Index = index;
            Margin = new Thickness(10);

            IsTabStop = true;

            DefaultStyleKey = typeof(ImageControl);

            MouseLeftButtonDown += new MouseButtonEventHandler(ImageControl_MouseLeftButtonDown);
            MouseEnter += new MouseEventHandler(ImageControl_MouseEnter);
            MouseLeave += new MouseEventHandler(ImageControl_MouseLeave);
            GotFocus += new RoutedEventHandler(ImageControl_GotFocus);
            LostFocus += new RoutedEventHandler(ImageControl_LostFocus);
            KeyDown += new KeyEventHandler(ImageControl_KeyDown);
        }


        public override void OnApplyTemplate()
        {
            base.OnApplyTemplate();

            GoToState(false);
        }

        #endregion ctor

        #region keyboard directional navigation

        void ImageControl_KeyDown(object sender, KeyEventArgs e)
        {
            switch (e.Key)
            {
                case Key.Up:
                case Key.Down:
                case Key.Left:
                case Key.Right:

                    // detect up, down, left, right keydowns & do directional navigation
                    e.Handled = true;
                    DoDirectionalNavigation(e.Key);
                    break;

                case Key.Enter:

                    // show details on enter
                    e.Handled = true;
                    ShowDetails();
                    break;

            }
        }

        private void DoDirectionalNavigation(Key key)
        {
            // determine my upperleft point relative to app
            Point myUpperLeft = GetPointRelativeToApp();

            // create appropriate hit test rect
            Rect hitTestRect = CreateHitTestRect(key, myUpperLeft);

            // iterate through items in hit test rect.
            // give focus to first ImageControl in hit test rect.

            IEnumerable<UIElement> elements = ((UIElement)Parent).HitTest(hitTestRect);

            foreach (UIElement element in elements)
            {
                ImageControl thumbnail = element as ImageControl;
                if (thumbnail != null)
                {
                    thumbnail.Focus();
                }
            }
        }



        private Point GetPointRelativeToApp()
        {
            GeneralTransform transform = TransformToVisual((UIElement)Application.Current.RootVisual);

            MatrixTransform matrixTransform = (MatrixTransform)transform;
            return new Point(matrixTransform.Matrix.OffsetX, matrixTransform.Matrix.OffsetY);
        }


        private Rect CreateHitTestRect(Key key, Point upperLeft)
        {

            Rect hitTestRect;
            if (key == Key.Up)
            {
                hitTestRect = new Rect(upperLeft.X, upperLeft.Y - Margin.Top - ActualHeight, ActualWidth, ActualHeight);
            }
            else if (key == Key.Down)
            {
                hitTestRect = new Rect(upperLeft.X, upperLeft.Y + Margin.Bottom + ActualHeight, ActualWidth, ActualHeight);
            }
            else if (key == Key.Left)
            {
                hitTestRect = new Rect(upperLeft.X - Margin.Left - ActualWidth, upperLeft.Y, ActualWidth, ActualHeight);
            }
            else
            {
                hitTestRect = new Rect(upperLeft.X + Margin.Right + ActualWidth, upperLeft.Y, ActualWidth, ActualHeight);
            }
            return hitTestRect;
        }

        #endregion

        #region Focus
        void ImageControl_LostFocus(object sender, RoutedEventArgs e)
        {
            hasFocus = false;
            GoToState(true);
        }

        void ImageControl_GotFocus(object sender, RoutedEventArgs e)
        {
            hasFocus = true;
            GoToState(true);
        }

        #endregion Focus


        #region helper functions

        private void ShowDetails()
        {
            ModalDialog.Closed += new EventHandler<ModalDialogClosedEventArgs>(ModalDialog_Closed);
            ModalDialog.Show(new SolidColorBrush(Colors.Black), .8, new ImageDetails(photos, index));
        }

        void ModalDialog_Closed(object sender, ModalDialogClosedEventArgs e)
        {
            Focus();
        }


        void GoToState(bool useTransitions)
        {
            if (isMouseOver)
            {
                VisualStateManager.GoToState(this, "MouseOver", useTransitions);
            }
            else
            {
                VisualStateManager.GoToState(this, "Normal", useTransitions);
            }


            if (hasFocus)
            {
                VisualStateManager.GoToState(this, "Focused", useTransitions);
            }
            else
            {
                VisualStateManager.GoToState(this, "Unfocused", useTransitions);
            }

        }
        #endregion

        #region eventhandlers

        void ImageControl_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            ShowDetails();
        }


        void ImageControl_MouseLeave(object sender, MouseEventArgs e)
        {
            isMouseOver = false;
            GoToState(true);
        }


        void ImageControl_MouseEnter(object sender, MouseEventArgs e)
        {
            isMouseOver = true;
            GoToState(true);
        }
        #endregion

        #region public properties

        public static readonly DependencyProperty SourceProperty = DependencyProperty.Register("Source", typeof(ImageSource), typeof(ImageControl), null);

        public ImageSource Source
        {
            get
            {
                return (ImageSource)GetValue(SourceProperty);
            }

            set
            {
                SetValue(SourceProperty, value);
            }
        }

        public PhotoCollection Photos
        {
            get
            {
                return photos;
            }

        }

        public int Index
        {
            get
            {
                return index;
            }

            set
            {
                index = value;
            }
        }

        #endregion

        #region private fields
        private PhotoCollection photos;
        private int index = -1;
        private bool isMouseOver = false;
        private bool hasFocus = false;
        #endregion
    }
}

