﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace HelloControl
{
    public class HelloControl : Control
    {
        protected TextBlock helloTextBlock;

        public HelloControl()
        {
            //default template stored in generic.xaml
            this.DefaultStyleKey = this.GetType(); 
        }

        public string HelloTarget
        {
            get { return (string)GetValue(HelloTargetProperty); }
            set { SetValue(HelloTargetProperty, value); }
        }

        // Using a DependencyProperty as the backing store for HelloTarget.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty HelloTargetProperty =
            DependencyProperty.Register("HelloTarget", typeof(string), typeof(HelloControl), new PropertyMetadata(OnHelloTargetChanged));

        protected static void OnHelloTargetChanged(DependencyObject o, DependencyPropertyChangedEventArgs args)
        {
            HelloControl hc = o as HelloControl;
            if (hc != null)
            {
                if (hc.helloTextBlock != null)
                    hc.helloTextBlock.Text = customLogic(args.NewValue.ToString());
            }
        }

        //store references to template parts here
        //initialize value
        public override void OnApplyTemplate()
        {
            base.OnApplyTemplate();
            helloTextBlock = GetTemplateChild("HelloTextBlock") as TextBlock;
            helloTextBlock.Text = customLogic((string)GetValue(HelloTargetProperty));
        }

        //custom logic used when setting value
        //used during initialization and when value changes
        private static string customLogic(string targetValue)
        {
            return string.Format("Hello {0}", targetValue);
        }
    }
}
