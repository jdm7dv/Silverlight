﻿using Microsoft.Practices.Composite.Modularity;
using Microsoft.Practices.Composite.Regions;
using Microsoft.Practices.Unity;
using VisualStock.Infrastructure.Interfaces;
using VisualStock.Modules.StockSymbols.ComparingSymbols;
using VisualStock.Modules.StockSymbols.Services;
using VisualStock.Modules.StockSymbols.AdditionalSymbolInformation;

namespace VisualStock.Modules.StockSymbols
{
    public class StockSymbolsModule : IModule
    {
        private readonly IUnityContainer _container;
        private readonly IRegionManager _regionManager;

        public StockSymbolsModule(IUnityContainer container, IRegionManager regionManager)
        {
            _container = container;
            _regionManager = regionManager;
        }

        #region IModule Members

        public void Initialize()
        {
            _container.RegisterType<IComparingSymbolListView, ComparingSymbolListView>();
            _container.RegisterType<ITechnicalIndicatorView, TechnicalIndicatorView>();
            _container.RegisterType<IComparingSymbolService, ComparingSymbolService>(new ContainerControlledLifetimeManager());

            _regionManager.RegisterViewWithRegion("CompareRegion", () => _container.Resolve<ComparingSymbolListViewModel>().View);
            _regionManager.RegisterViewWithRegion("AdditionalRegion", () => _container.Resolve<TechnicalIndicatorViewModel>().View);
        }

        #endregion
    }
}
