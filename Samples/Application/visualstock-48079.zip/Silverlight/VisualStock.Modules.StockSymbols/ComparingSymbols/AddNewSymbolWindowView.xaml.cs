﻿using System.Windows;
using System.Windows.Controls;

namespace VisualStock.Modules.StockSymbols.ComparingSymbols
{
    public partial class AddNewSymbolWindowView : ChildWindow
    {
        public AddNewSymbolWindowView()
        {
            InitializeComponent();
        }

        public AddNewSymbolWindowViewModel Model
        {
            get { return this.DataContext as AddNewSymbolWindowViewModel; }
            set { this.DataContext = value; }
        }

        private void OKButton_Click(object sender, RoutedEventArgs e)
        {
            this.DialogResult = true;
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            this.DialogResult = false;
        }
    }
}

