﻿using System.Windows.Controls;

namespace VisualStock.Modules.StockSymbols.ComparingSymbols
{
    public partial class ComparingSymbolListView : UserControl, IComparingSymbolListView
    {
        public ComparingSymbolListView()
        {
            InitializeComponent();
        }

        #region IComparingSymbolListView Members

        public IComparingSymbolListViewModel Model
        {
            get { return this.DataContext as IComparingSymbolListViewModel; }
            set { this.DataContext = value;}
        }

        #endregion

        #region Event Handler

        // The SelectedItems property is not a dependency property, hence it has to be set in the code
        private void ListBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            this.Model.SelectedSymbolList.Clear();
            foreach (object item in (sender as ListBox).SelectedItems)
            {
                this.Model.SelectedSymbolList.Add((string)item);
            }
        }

        #endregion
    }
}
