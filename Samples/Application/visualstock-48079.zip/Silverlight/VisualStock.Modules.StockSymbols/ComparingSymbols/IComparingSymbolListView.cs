﻿namespace VisualStock.Modules.StockSymbols.ComparingSymbols
{
    public interface IComparingSymbolListView
    {
        IComparingSymbolListViewModel Model { get; set; }
    }
}
