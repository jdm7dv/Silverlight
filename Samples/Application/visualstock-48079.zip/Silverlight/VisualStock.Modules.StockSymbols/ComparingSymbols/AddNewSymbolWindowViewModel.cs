﻿using System;
using System.Windows.Controls;
using Microsoft.Practices.Composite.Presentation.Commands;
using VisualStock.Infrastructure;
using VisualStock.Infrastructure.Interfaces;

namespace VisualStock.Modules.StockSymbols.ComparingSymbols
{
    public class AddNewSymbolWindowViewModel
    {
        private readonly IHistoricalDataService _historicalDataService;

        private DelegateCommand<object> _okCommand;

        public AddNewSymbolWindowView View { get; set; }

        public string Symbol { get; private set; }

        public Uri DownloadUrl
        {
            get { return new Uri(String.Format(DataDownloadUrlFormats.YahooDailyHistoricalData, Symbol)); }
        }

        public DelegateCommand<object> OkCommand
        {
            get
            {
                if (_okCommand == null)
                {
                    _okCommand = new DelegateCommand<object>(OnOkButtonExcuted);
                }
                return _okCommand;
            }
        }

        public AddNewSymbolWindowViewModel(string symbol, AddNewSymbolWindowView view, IHistoricalDataService historicalDataService)
        {
            this.Symbol = symbol;
            this.View = view;
            this.View.DataContext = this;
            _historicalDataService = historicalDataService;
        }

        private void OnOkButtonExcuted(object parameter)
        {
            _historicalDataService.ImportStockHistoricalData(Symbol);
        }
    }
}
