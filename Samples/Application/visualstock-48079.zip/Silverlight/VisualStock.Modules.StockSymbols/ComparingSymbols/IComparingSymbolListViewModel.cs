﻿using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Collections.Specialized;
using Microsoft.Practices.Composite.Presentation.Commands;

namespace VisualStock.Modules.StockSymbols.ComparingSymbols
{
    public interface IComparingSymbolListViewModel
    {
        IComparingSymbolListView View { get; }

        ObservableCollection<string> ComparingSymbolList { get; }

        ObservableCollection<string> SelectedSymbolList { get; }
        
        DelegateCommand<object> CompareCommand { get; }

        DelegateCommand<object> RemoveCommand { get; }

        DelegateCommand<string> AddCommand { get; }
    }
}
