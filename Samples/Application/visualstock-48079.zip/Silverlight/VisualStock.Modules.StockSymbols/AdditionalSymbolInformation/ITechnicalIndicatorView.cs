﻿namespace VisualStock.Modules.StockSymbols.AdditionalSymbolInformation
{
    public interface ITechnicalIndicatorView
    {
        ITechnicalIndicatorViewModel Model { get; set; }
    }
}