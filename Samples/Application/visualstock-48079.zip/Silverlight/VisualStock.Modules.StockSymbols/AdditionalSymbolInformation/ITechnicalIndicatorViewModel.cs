﻿using System.Collections.Generic;
using System.Collections.ObjectModel;
using Microsoft.Practices.Composite.Presentation.Commands;

namespace VisualStock.Modules.StockSymbols.AdditionalSymbolInformation
{
    public interface ITechnicalIndicatorViewModel
    {
        ITechnicalIndicatorView View { get; }

        ObservableCollection<string> TechnicalIndicatorList { get; }

        List<string> SelectedIndicatorList { get; }

        DelegateCommand<object> DrawCommand { get; }

        DelegateCommand<object> GetCommand { get; }

        string CurrentSymbol { get; }
    }
}
