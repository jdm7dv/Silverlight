﻿using System.Windows.Controls;
using System;

namespace VisualStock.Modules.StockSymbols.AdditionalSymbolInformation
{
    public partial class TechnicalIndicatorView : UserControl, ITechnicalIndicatorView
    {
        public TechnicalIndicatorView()
        {
            InitializeComponent();
        }

        public ITechnicalIndicatorViewModel Model
        {
            get { return this.DataContext as ITechnicalIndicatorViewModel; }
            set { this.DataContext = value; }
        }

        private void ListBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            this.Model.SelectedIndicatorList.Clear();
            foreach (object item in (sender as ListBox).SelectedItems)
            {
                this.Model.SelectedIndicatorList.Add((string)item);
            }
        }
    }
}
