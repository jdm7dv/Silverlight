﻿using System.Collections.Generic;
using System.Collections.ObjectModel;
using VisualStock.Infrastructure.Models;
using VisualStock.Modules.StockMarket.HistoricalData.Interfaces;
using VisualStock.Modules.StockMarket.Models;

namespace VisualStock.Modules.StockMarket.HistoricalData
{
    public interface IHistoricalDataChartViewModel
    {
        IHistoricalDataChartView View { get; }

        List<StockHistoricalDataCollection> CurrentDataCollections { get; }

        ObservableCollection<string> CurrentSymbolList { get; }

        ISettingController Settings { get; }
    }
}
