﻿using System.ComponentModel;
using VisualStock.Modules.StockMarket.HistoricalData.Interfaces;
using VisualStock.Modules.StockMarket.Models;

namespace VisualStock.Modules.StockMarket.HistoricalData
{
    public interface IHistoricalDataMenuViewModel
    {
        IHistoricalDataMenuView View { get; }

        ISettingController CurrentChartSettings { get; }

        TechnicalIndicatorSetting CurrentTechSetting { get; }

        event PropertyChangedEventHandler TechSettingChanged;
    }
}
