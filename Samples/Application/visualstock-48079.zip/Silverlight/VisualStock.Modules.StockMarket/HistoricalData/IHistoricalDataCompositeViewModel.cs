﻿using VisualStock.Modules.StockMarket.HistoricalData.Interfaces;

namespace VisualStock.Modules.StockMarket.HistoricalData
{
    public interface IHistoricalDataCompositeViewModel
    {
        IHistoricalDataCompositeView View { get; }
    }
}
