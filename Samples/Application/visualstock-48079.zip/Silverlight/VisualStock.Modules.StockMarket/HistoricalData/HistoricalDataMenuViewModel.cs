﻿using System.Collections.Generic;
using System.ComponentModel;
using Microsoft.Practices.Composite.Events;
using VisualStock.Infrastructure;
using VisualStock.Infrastructure.Interfaces;
using VisualStock.Modules.StockMarket.HistoricalData.Interfaces;
using VisualStock.Modules.StockMarket.Models;
using Microsoft.Practices.Composite.Presentation.Events;
using VisualStock.Infrastructure.Models;

namespace VisualStock.Modules.StockMarket.HistoricalData
{
    public class HistoricalDataMenuViewModel : IHistoricalDataMenuViewModel, INotifyPropertyChanged
    {
        private readonly IEventAggregator _eventAggregator;

        private TechnicalIndicatorSetting _currentTechSetting = new TechnicalIndicatorSetting();

        private readonly IDataAnalysisService _dataAnalysisService;

        public List<string> CurrentSymbolList { get; set; }

        public HistoricalDataMenuViewModel(IHistoricalDataMenuView view, IDataAnalysisService dataAnalysisService, ISettingController observableSettings, IEventAggregator eventAggregator)
        {
            InitializeTechnicalIndicatorSetting();

            _dataAnalysisService = dataAnalysisService;
            _eventAggregator = eventAggregator;
            this.CurrentChartSettings = observableSettings;
            this.View = view;
            this.View.Model = this;

            _eventAggregator.GetEvent<NewComparisonRequestedEvent>().Subscribe(UpdateCurrentSymbolList, ThreadOption.UIThread);
        }

        public void UpdateCurrentSymbolList(List<string> newSymbolList)
        {
            CurrentSymbolList = newSymbolList;
            this.InvokePropertyChanged("CurrentSymbolList");
        }

        private void InitializeTechnicalIndicatorSetting()
        {
            _currentTechSetting.AvailableSMATypes = new List<int> { 5, 10, 15, 20, 25, 30, 50, 100, 200 };
            _currentTechSetting.SimpleMA = 0;
            _currentTechSetting.PropertyChanged += new PropertyChangedEventHandler(OnTechSettingChanged);
        }

        private void OnTechSettingChanged(object sender, PropertyChangedEventArgs e)
        {
            if (this.CurrentSymbolList != null && this.CurrentSymbolList.Count > 0)
            {
                if (!CurrentSymbolList[0].Contains("SMA"))
                    _dataAnalysisService.AnalysisSelector(TechnicalIndicatorType.DefaultSMA, CurrentSymbolList[0], (sender as TechnicalIndicatorSetting).SimpleMA);
            }
        }

        #region IHistoricalDataMenuViewModel Members

        public IHistoricalDataMenuView View { get; set; }

        public ISettingController CurrentChartSettings { get; private set; }

        public TechnicalIndicatorSetting CurrentTechSetting { get { return _currentTechSetting; } }

        public event PropertyChangedEventHandler TechSettingChanged = delegate { };

        #endregion

        public event PropertyChangedEventHandler PropertyChanged;

        private void InvokePropertyChanged(string propertyName)
        {
            PropertyChangedEventHandler Handler = PropertyChanged;
            if (Handler != null) Handler(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}
