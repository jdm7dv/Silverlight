﻿using System.Windows.Controls;
using VisualStock.Modules.StockMarket.HistoricalData.Interfaces;

namespace VisualStock.Modules.StockMarket.HistoricalData
{
    public partial class HistoricalDataMenuView : UserControl, IHistoricalDataMenuView
    {
        public HistoricalDataMenuView()
        {
            InitializeComponent();
        }

        #region IHistoricalDataMenuView Members

        public IHistoricalDataMenuViewModel Model
        {
            get { return this.DataContext as IHistoricalDataMenuViewModel; }
            set { this.DataContext = value; }
        }

        #endregion
    }
}