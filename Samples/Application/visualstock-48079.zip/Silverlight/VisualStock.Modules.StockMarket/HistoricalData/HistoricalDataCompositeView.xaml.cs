﻿using System.Windows.Controls;
using VisualStock.Modules.StockMarket.HistoricalData.Interfaces;

namespace VisualStock.Modules.StockMarket.HistoricalData
{
    public partial class HistoricalDataCompositeView : UserControl, IHistoricalDataCompositeView
    {
        public HistoricalDataCompositeView()
        {
            InitializeComponent();
        }

        public void SetModel(IHistoricalDataCompositeViewModel model)
        {
            this.DataContext = model;
        }
    }
}
