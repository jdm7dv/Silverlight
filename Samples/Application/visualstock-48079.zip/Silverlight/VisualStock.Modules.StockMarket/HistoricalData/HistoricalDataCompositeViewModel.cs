﻿using VisualStock.Modules.StockMarket.HistoricalData.Interfaces;

namespace VisualStock.Modules.StockMarket.HistoricalData
{
    public class HistoricalDataCompositeViewModel : IHistoricalDataCompositeViewModel
    {
        private readonly IHistoricalDataCompositeView _view;

        public object HistoricalDataChartView { get; private set; }

        public object HistoricalDataMenuView { get; private set; }

        public HistoricalDataCompositeViewModel(IHistoricalDataCompositeView historicalDataCompositeView, IHistoricalDataChartViewModel historicalDataChartViewModel, IHistoricalDataMenuViewModel historicalDataMenuViewModel)
        {
            this.HistoricalDataChartView = historicalDataChartViewModel.View;
            this.HistoricalDataMenuView = historicalDataMenuViewModel.View;

            _view = historicalDataCompositeView;
            _view.SetModel(this);
        }

        #region IHistoricalDataCompositeViewModel Members

        public IHistoricalDataCompositeView View
        {
            get { return _view; }
        }

        #endregion
    }
}
