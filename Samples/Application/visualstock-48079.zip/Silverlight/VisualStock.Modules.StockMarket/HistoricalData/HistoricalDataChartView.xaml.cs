﻿using System.Windows;
using System.Windows.Controls;
using VisualStock.Modules.StockMarket.HistoricalData.Interfaces;

namespace VisualStock.Modules.StockMarket.HistoricalData
{
    public partial class HistoricalDataChartView : UserControl, IHistoricalDataChartView
    {
        public HistoricalDataChartView()
        {
            InitializeComponent();

            (Application.Current.RootVisual as UserControl).SizeChanged += new SizeChangedEventHandler(RootVisual_SizeChanged);
        }

        public void RootVisual_SizeChanged(object sender, SizeChangedEventArgs e)
        {
            ChartsGrid.Height = e.NewSize.Height > 460 ? e.NewSize.Height - 110 : 350;
        }

        #region IHistoricalDataChartView Members

        public IHistoricalDataChartViewModel Model
        {
            get { return this.DataContext as IHistoricalDataChartViewModel; }
            set { this.DataContext = value; }
        }

        #endregion
    }
}
