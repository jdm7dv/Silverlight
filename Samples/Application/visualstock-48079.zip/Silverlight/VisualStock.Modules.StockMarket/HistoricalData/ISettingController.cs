﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Windows;
using VisualStock.Modules.StockMarket.Models;

namespace VisualStock.Modules.StockMarket
{
    public interface ISettingController
    {
        DateTime CurrentStartDate { get; }

        DateTime CurrentEndDate { get; }

        DateTime DataStartDate { get; }

        DateTime DataEndDate { get; }

        ChartTypes PrimaryChartType { get; }

        ChartTypes SecondaryChartType { get; }

        Visibility IsSecondaryChartVisible { get; }

        IList<ChartTypes> AvailablePrimaryChartTypes { get; }

        IList<ChartTypes> AvailableSecondaryChartTypes { get; }

        event PropertyChangedEventHandler PropertyChanged;
    }
}
