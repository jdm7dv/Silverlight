﻿using System.Collections.Generic;
using System.ComponentModel;

namespace VisualStock.Modules.StockMarket.Models
{
    public class TechnicalIndicatorSetting : INotifyPropertyChanged
    {
        private int _simpleMA;

        // First simple moving average
        public int SimpleMA
        {
            get { return _simpleMA; }
            set
            {
                _simpleMA = value;
                this.InvokePropertyChanged("SimpleMA");
            }
        }

        // The unit of movingaverage is day.
        public IList<int> AvailableSMATypes { get; set; }

        public event PropertyChangedEventHandler PropertyChanged;

        private void InvokePropertyChanged(string propertyName)
        {
            PropertyChangedEventHandler Handler = PropertyChanged;
            if (Handler != null) Handler(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}
