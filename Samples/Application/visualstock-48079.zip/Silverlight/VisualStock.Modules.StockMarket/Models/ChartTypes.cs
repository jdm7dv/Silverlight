﻿namespace VisualStock.Modules.StockMarket.Models
{
    public enum ChartTypes
    {
        None,
        Line,
        Column,
        Stock,
        CandleStick,
        Area,
        StepLine
    }
}