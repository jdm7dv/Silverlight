﻿namespace VisualStock.Modules.StockMarket.HistoricalData.Interfaces
{
    public interface IHistoricalDataCompositeView
    {
        void SetModel(IHistoricalDataCompositeViewModel model);
    }
}
