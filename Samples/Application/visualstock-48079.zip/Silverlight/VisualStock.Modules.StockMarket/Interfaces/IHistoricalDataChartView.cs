﻿namespace VisualStock.Modules.StockMarket.HistoricalData.Interfaces
{
    public interface IHistoricalDataChartView
    {
        IHistoricalDataChartViewModel Model { get; set; }
    }
}
