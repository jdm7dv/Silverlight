﻿namespace VisualStock.Modules.StockMarket.HistoricalData.Interfaces
{
    public interface IHistoricalDataMenuView
    {
        IHistoricalDataMenuViewModel Model { get; set; }
    }
}
