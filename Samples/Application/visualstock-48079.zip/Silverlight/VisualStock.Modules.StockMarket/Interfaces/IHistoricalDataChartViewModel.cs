﻿using VisualStock.Infrastructure.Models;
using System.Collections.Generic;
using Visifire.Charts;
using System.Collections.ObjectModel;

namespace VisualStock.Modules.StockMarket.Interfaces
{
    public interface IHistoricalDataChartViewModel
    {
        IHistoricalDataChartView View { get; }

        List<StockHistoricalDataCollection> CurrentDataCollection { get; }

        ObservableCollection<string> CurrentSymbolList { get; }
    }
}
