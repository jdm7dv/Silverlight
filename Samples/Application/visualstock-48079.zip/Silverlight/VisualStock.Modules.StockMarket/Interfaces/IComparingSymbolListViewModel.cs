﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using VisualStock.Modules.StockMarket.Interfaces;
using System.Collections.ObjectModel;
using System.Windows.Input;
using Microsoft.Practices.Composite.Presentation.Commands;
using VisualStock.Infrastructure;
using VisualStock.Infrastructure.Models;

namespace VisualStock.Modules.StockMarket.Interfaces
{
    public interface IComparingSymbolListViewModel
    {
        IComparingSymbolListView View { get; }

        ComparingSymbolCollection ComparingSymbolList { get; }

        List<ComparingSymbolItem> SelectedSymbolList { get; }
        
        DelegateCommand<object> CompareCommand { get; }

        DelegateCommand<string> AddCommand { get; }
    }
}
