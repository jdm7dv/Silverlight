﻿using Microsoft.Practices.Composite.Modularity;
using Microsoft.Practices.Composite.Regions;
using Microsoft.Practices.Unity;
using VisualStock.Infrastructure.Interfaces;
using VisualStock.Modules.StockMarket.HistoricalData;
using VisualStock.Modules.StockMarket.HistoricalData.Interfaces;
using VisualStock.Modules.StockMarket.Services;

namespace VisualStock.Modules.StockMarket
{
    public class StockMarketModule : IModule
    {
        private readonly IUnityContainer _container;
        private readonly IRegionManager _regionManager;

        public StockMarketModule(IUnityContainer container, IRegionManager regionManager)
        {
            _container = container;
            _regionManager = regionManager;
        }

        #region IModule Members

        public void Initialize()
        {
            _container.RegisterType<IHistoricalDataService, HistoricalDataService>(new ContainerControlledLifetimeManager());
            _container.RegisterType<IDataAnalysisService, DataAnalysisService>(new ContainerControlledLifetimeManager());
            _container.RegisterType<ISettingController, SettingController>(new ContainerControlledLifetimeManager());
            _container.RegisterType<IHistoricalDataChartView, HistoricalDataChartView>();
            _container.RegisterType<IHistoricalDataChartViewModel, HistoricalDataChartViewModel>();
            _container.RegisterType<IHistoricalDataMenuView, HistoricalDataMenuView>();
            _container.RegisterType<IHistoricalDataMenuViewModel, HistoricalDataMenuViewModel>();
            _container.RegisterType<IHistoricalDataCompositeViewModel, HistoricalDataCompositeViewModel>();
            _container.RegisterType<IHistoricalDataCompositeView, HistoricalDataCompositeView>();

            _regionManager.RegisterViewWithRegion("DataRegion", () => _container.Resolve<HistoricalDataCompositeViewModel>().View);
        }

        #endregion
    }
}
