﻿using System.Windows;
using Microsoft.Practices.Composite.Modularity;
using Microsoft.Practices.Composite.UnityExtensions;
using VisualStock.Modules.StockMarket;
using VisualStock.Modules.StockSymbols;

namespace VisualStock
{
    public class VisualStockBootstrapper : UnityBootstrapper
    {
        protected override DependencyObject CreateShell()
        {
            Shell shell = Container.Resolve<Shell>();
            Application.Current.RootVisual = shell;
            return shell;
        }

        protected override IModuleCatalog GetModuleCatalog()
        {
            ModuleCatalog catalog = new ModuleCatalog();
            catalog.AddModule(typeof(StockMarketModule));
            catalog.AddModule(typeof(StockSymbolsModule));
            return catalog;
        }
    }
}
