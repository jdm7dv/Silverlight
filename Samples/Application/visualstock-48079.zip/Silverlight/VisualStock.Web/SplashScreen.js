﻿function onSourceDownloadProgressChanged(sender, eventArgs) {
    sender.findName("DownloadStatus").Text = Math.round((eventArgs.progress * 100)) + "%";
}