﻿using VisualStock.Infrastructure.Models;

namespace VisualStock.Infrastructure.Interfaces
{
    public interface IDataAnalysisService
    {
        void AnalysisSelector(TechnicalIndicatorType type, string targetSymbol, int value);
    }
}