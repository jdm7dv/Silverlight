﻿using System;
using System.Collections.Generic;
using VisualStock.Infrastructure.Models;

namespace VisualStock.Infrastructure.Interfaces
{
    public interface IComparingSymbolService
    {
        event EventHandler<AvailableSymbolChangedEventArgs> AvailableSymbolChanged;

        ObservableSymbolCollection GetAvailableSymbols();

        void RemoveSymbols(List<string> targetSymbols);
    }
}
