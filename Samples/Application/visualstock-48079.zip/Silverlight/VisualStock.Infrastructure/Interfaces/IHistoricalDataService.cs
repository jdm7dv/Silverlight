﻿using System;
using VisualStock.Infrastructure.Models;
using System.IO;

namespace VisualStock.Infrastructure.Interfaces
{
    public interface IHistoricalDataService
    {
        bool HasHistoricalData(string targetSymbol);
        
        bool TryGetHistoricalData(string targetSymbol, out StockHistoricalDataCollection items);

        StockDataInfomation GetHistoricalDataInfo(string targetSymbol);

        StockHistoricalDataCollection GetHisroricalData(string targetSymbol, DateTime startDate, DateTime endDate);

        void DownloadStocktHistoricalData(string targetSymbol);

        void ImportStockHistoricalData(string targetSymbol);
    }
}