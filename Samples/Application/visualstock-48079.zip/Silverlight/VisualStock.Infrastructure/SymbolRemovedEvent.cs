﻿using System.Collections.Generic;
using Microsoft.Practices.Composite.Presentation.Events;

namespace VisualStock.Infrastructure
{
    public class SymbolRemovedEvent: CompositePresentationEvent<List<string>> { }
}
