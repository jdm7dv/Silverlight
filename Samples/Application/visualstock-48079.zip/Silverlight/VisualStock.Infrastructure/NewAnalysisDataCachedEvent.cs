﻿using Microsoft.Practices.Composite.Presentation.Events;

namespace VisualStock.Infrastructure
{
    public class NewAnalysisDataCachedEvent : CompositePresentationEvent<string> { }
}
