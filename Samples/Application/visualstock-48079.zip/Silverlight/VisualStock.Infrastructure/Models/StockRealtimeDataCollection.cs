﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;

namespace VisualStock.Infrastructure.Models
{
    public class StockRealtimeDataCollection : ObservableCollection<StockRealtimelDataItem>
    {        
        public StockRealtimeDataCollection() { }

        public StockRealtimeDataCollection(IEnumerable<StockRealtimelDataItem> list)
        {
            foreach (StockRealtimelDataItem stockRealtimeDataItem in list)
            {
                this.Add(stockRealtimeDataItem);
            }
        }
    }

    public class StockRealtimelDataItem
    {
        /// <summary>
        /// Time of quote
        /// </summary>
        public DateTime QuotedTime { get; set;}

        /// <summary>
        /// Value of quote
        /// </summary>
        public double QuotedValue { get; set; }
    }
}
