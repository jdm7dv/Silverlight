﻿using System;
using System.Collections.Generic;

namespace VisualStock.Infrastructure.Models
{
    public class StockDataInfomation
    {
        public DateTime StartDate { get; set; }

        public DateTime EndDate { get; set; }

        public List<string> TechnicalIndicatorNames { get; set; }
    }
}
