﻿namespace VisualStock.Infrastructure.Models
{
    public enum TechnicalIndicatorType
    {
        DefaultSMA,
        QuickSMA
    }
}