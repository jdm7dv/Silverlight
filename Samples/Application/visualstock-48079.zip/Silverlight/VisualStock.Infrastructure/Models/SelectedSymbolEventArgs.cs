﻿using System;
using System.Collections.Generic;

namespace VisualStock.Infrastructure.Models
{
    public class AvailableSymbolChangedEventArgs : EventArgs
    {
        public List<string> NewItems { get; set; }

        public List<string> OldItems { get; set; }
    }
}
