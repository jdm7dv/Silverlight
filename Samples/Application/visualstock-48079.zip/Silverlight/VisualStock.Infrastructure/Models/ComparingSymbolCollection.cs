﻿using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;

namespace VisualStock.Infrastructure.Models
{
    public class ObservableSymbolCollection : ObservableCollection<ObservableSymbolItem>
    {
        public ObservableSymbolCollection() { }

        public ObservableSymbolCollection(IEnumerable<ObservableSymbolItem> list)
        {
            foreach (ObservableSymbolItem item in list)
            {
                this.Add(item);
            }
        }
    }

    public class ObservableSymbolItem : INotifyPropertyChanged
    {
        private string _symbol;

        public string Symbol
        {
            get
            {
                return _symbol;
            }
            set
            {
                if (!value.Equals(_symbol))
                {
                    _symbol = value;
                    PropertyChanged(this, new PropertyChangedEventArgs("Symbol"));
                }
            }
        }

        private SymbolDataStatus _dataStatus;

        public SymbolDataStatus DataStatus
        {
            get
            {
                return _dataStatus;
            }
            set
            {
                if (!value.Equals(_dataStatus))
                {
                    _dataStatus = value;
                    PropertyChanged(this, new PropertyChangedEventArgs("DataStatus"));
                }
            }
        }

        #region INotifyPropertyChanged Members

        public event PropertyChangedEventHandler PropertyChanged = delegate { };

        #endregion
    }
}
