﻿namespace VisualStock.Infrastructure.Models
{
    public enum SymbolDataStatus
    {
        NotFound,
        Cached,
        Preparing,
        downloading
    }
}