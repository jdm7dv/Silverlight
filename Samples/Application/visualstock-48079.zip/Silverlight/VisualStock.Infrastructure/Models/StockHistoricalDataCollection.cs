﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Collections.Specialized;

namespace VisualStock.Infrastructure.Models
{
    public class StockHistoricalDataCollection : ObservableCollection<StockHistoricalDataItem>
    {
        public DateTime StartDate { get; private set; }

        public DateTime EndDate { get; private set; }

        public StockHistoricalDataCollection() { }

        public StockHistoricalDataCollection(IEnumerable<StockHistoricalDataItem> list)
        {
            foreach (StockHistoricalDataItem stockHistoricalDataItem in list)
            {
                this.Add(stockHistoricalDataItem);
            }
        }

        protected override void OnCollectionChanged(NotifyCollectionChangedEventArgs e)
        {
            base.OnCollectionChanged(e);

            DateTime date = (e.NewItems[0] as StockHistoricalDataItem).QuoteDate;

            if (this.Count == 1) StartDate = date;
            else if (date.CompareTo(StartDate) < 0) StartDate = date;

            if (this.Count == 1) EndDate = date;
            else if (date.CompareTo(EndDate) > 0) EndDate = date;
        }
    }

    public class StockHistoricalDataItem : IComparable<StockHistoricalDataItem>
    {
        #region Basic Public Property

        /// <summary>
        /// Date of quote, in order to avoid the gap caused by the missing points, please use the RalativeXValue instead of QuoteDate
        /// </summary>
        public DateTime QuoteDate { get; set; }

        /// <summary>
        /// Value of the opening price
        /// </summary>
        public double OpeningPrice { get; set; }

        /// <summary>
        /// Value of the closing price
        /// </summary>
        public double ClosingPrice { get; set; }

        /// <summary>
        /// Value of the highest price
        /// </summary>
        public double HighestPrice { get; set; }

        /// <summary>
        /// Value of the lowest price
        /// </summary>
        public double LowestPrice { get; set; }

        /// <summary>
        /// Value Of the volume
        /// </summary>
        public double Volume { get; set; }

        #endregion

        #region Additional Public Property

        /// <summary>
        /// Return the string format of QuoteDate
        /// </summary>
        public string QuoteDateString { get { return QuoteDate.ToShortDateString(); } }

        /// <summary>
        /// The ralative xvalue for data displaying
        /// </summary>
        public double RelativeXValue { get; set; }

        #endregion

        #region IComparable Members

        public int CompareTo(StockHistoricalDataItem other)
        {
            return this.QuoteDate.CompareTo(other.QuoteDate);
        }

        #endregion
    }
}
