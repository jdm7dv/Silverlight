﻿using System.Collections.Generic;
using Microsoft.Practices.Composite.Presentation.Events;
using VisualStock.Infrastructure.Models;

namespace VisualStock.Infrastructure
{
    public class CacheAnalysisDataEvent : CompositePresentationEvent<KeyValuePair<string, StockHistoricalDataCollection>> { }
}
