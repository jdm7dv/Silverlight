﻿using Microsoft.Practices.Composite.Presentation.Events;

namespace VisualStock.Infrastructure
{
    public class NewHistoricalDataObtainedEvent : CompositePresentationEvent<string> { }
}
