﻿namespace VisualStock.Infrastructure
{
    public static class DataDownloadUrlFormats
    {
        public const string YahooDailyHistoricalData = "http://ichart.finance.yahoo.com/table.csv?s={0}&ignore=.csv";
    }
}
