using System;
using System.Net;

namespace MM.OpenId.Controls
{
    public class DefaultDownloader : IDownloader
    {
        #region IDownloader Members

        public void Download(string url, Action<string> callBackOnComplete)
        {
            var wc = new WebClient();
            wc.DownloadStringCompleted += (sender, e) =>
                                              {
                                                  if (e.Error != null)
                                                      callBackOnComplete(string.Empty);
                                                  else
                                                      callBackOnComplete(e.Result);
                                              };
            wc.DownloadStringAsync(new Uri(url));
        }

        #endregion
    }
}