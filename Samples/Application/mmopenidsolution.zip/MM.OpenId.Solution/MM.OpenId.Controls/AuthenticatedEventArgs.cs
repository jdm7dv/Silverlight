using System;

namespace MM.OpenId.Controls
{
    public class AuthenticatedEventArgs : EventArgs
    {
        internal AuthenticatedEventArgs(OpenIdUser user)
        {
            User = user;
        }

        public OpenIdUser User { get; private set; }
    }
}