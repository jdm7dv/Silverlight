using System;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Browser;

namespace MM.OpenId.Controls
{
public class OpenIdService
{
    private static readonly Regex RegexHref = new Regex("href\\s*=\\s*(?:\"(?<1>[^\"]*)\"|(?<1>\\S+))",
                                                        RegexOptions.IgnoreCase);

    private static readonly Regex RegexLink = new Regex(@"<link[^>]*/?>", RegexOptions.IgnoreCase);

    public OpenIdService()
    {
        Downloader = new DefaultDownloader();
        RequiredParameters = new List<string>();
        OptionalParameters = new List<string>();
    }

    public IDownloader Downloader { get; set; }
    public List<string> RequiredParameters { get; set; }
    public List<string> OptionalParameters { get; set; }

    public void DefineLoginUrl(string identity, Action<string> loginUrlDefinedCallBack)
    {
        DefineServer(identity,
                     server =>
                         {
                             if (server == null)
                                 throw new OpenIdException("Determining OpenId server failed.");
                             loginUrlDefinedCallBack(
                                 string.Concat(server.ServerUrl,
                                               CreateRedirectUrl(server.DelegateUrl, identity)));
                         });
    }

    private void DefineServer(string identity, Action<Server> defineServerCallBack)
    {
        Downloader.Download(identity,
                            res =>
                                {
                                    if (string.IsNullOrEmpty(res))
                                        throw new OpenIdException("Couldn't find profile at identity.");
                                    defineServerCallBack(ProcessIdentityResponse(identity, res));
                                });
    }

    private Server ProcessIdentityResponse(string identity, string identityResponse)
    {
        var server = new Server();
        foreach (Match linkMatches in RegexLink.Matches(identityResponse))
        {
            string serverName = "openid.server";
            string delegateName = "openid.delegate";

            if (linkMatches.Value.IndexOf(serverName) > 0)
            {
                Match hrefMatch = RegexHref.Match(linkMatches.Value);
                if (hrefMatch.Success)
                {
                    server.ServerUrl = hrefMatch.Groups[1].Value;
                }
            }

            if (linkMatches.Value.IndexOf(delegateName) > 0)
            {
                Match hrefMatch = RegexHref.Match(linkMatches.Value);
                if (hrefMatch.Success)
                {
                    server.DelegateUrl = hrefMatch.Groups[1].Value;
                }
            }
        }
        if (string.IsNullOrEmpty(server.DelegateUrl))
            server.DelegateUrl = identity;
        if (!string.IsNullOrEmpty(server.ServerUrl) && !string.IsNullOrEmpty(server.DelegateUrl))
            return server;
        return null;
    }

    /// <summary>
    /// Creates the URL to the OpenID provider with all parameters.
    /// </summary>
    private string CreateRedirectUrl(string delegateUrl,
                                     string identity)
    {
        string requiredParameters = string.Join(",", RequiredParameters.ToArray());
        string optionalParameters = string.Join(",", OptionalParameters.ToArray());

        var urlBuilder = new StringBuilder();
        urlBuilder.AppendFormat("?openid.ns={0}", HttpUtility.UrlEncode("http://specs.openid.net/auth/2.0"));
        urlBuilder.Append("&openid.mode=checkid_setup");
        urlBuilder.AppendFormat("&openid.identity={0}", HttpUtility.UrlEncode(delegateUrl));
        urlBuilder.AppendFormat("&openid.claimed_id={0}", HttpUtility.UrlEncode(identity));
        Uri documentUri = HtmlPage.Document.DocumentUri;
        string url = documentUri.ToString();
        if (!string.IsNullOrEmpty(documentUri.Query))
            url = url.Replace(documentUri.Query, string.Empty);
        urlBuilder.AppendFormat("&openid.return_to={0}", HttpUtility.UrlEncode(url));

        if (!string.IsNullOrEmpty(requiredParameters) || !string.IsNullOrEmpty(optionalParameters))
        {
            urlBuilder.AppendFormat("&openid.ns.sreg={0}",
                                    HttpUtility.UrlEncode("http://openid.net/extensions/sreg/1.1"));

            if (!string.IsNullOrEmpty(requiredParameters))
                urlBuilder.AppendFormat("&openid.sreg.required={0}", HttpUtility.UrlEncode(requiredParameters));

            if (!string.IsNullOrEmpty(optionalParameters))
                urlBuilder.AppendFormat("&openid.sreg.optional={0}", HttpUtility.UrlEncode(optionalParameters));
        }

        return urlBuilder.ToString();
    }

    public bool IsOpenIdRequest(IDictionary<string, string> dictionary)
    {
        return dictionary.ContainsKey("openid.mode");
    }

    public OpenIdUser Authenticate(IDictionary<string, string> query)
    {
        var openIdUser = new OpenIdUser
                             {
                                 Identity = query["openid.claimed_id"],
                                 IsSuccess = query["openid.mode"] == "id_res"
                             };

        foreach (string keyName in query.Keys)
        {
            if (keyName.StartsWith("openid.sreg."))
                openIdUser.Parameters.Add(keyName.Replace("openid.sreg.", string.Empty), query[keyName]);
        }

        return openIdUser;
    }
}

    public class OpenIdException : Exception
    {
        public OpenIdException(string message) : base(message)
        {
        }
    }
}