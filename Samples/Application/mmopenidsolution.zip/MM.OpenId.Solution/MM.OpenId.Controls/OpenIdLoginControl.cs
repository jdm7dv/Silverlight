using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Browser;
using System.Windows.Controls;

namespace MM.OpenId.Controls
{
    [TemplatePart(Name = LoginButton, Type = typeof (Button))]
    [TemplatePart(Name = IdentityInput, Type = typeof (TextBox))]
    [TemplatePart(Name = IdentitySuccessLabel, Type = typeof (TextBlock))]
    [TemplateVisualState(Name = VisualStates.Unauthenticated, GroupName = VisualStates.CommonStates)]
    [TemplateVisualState(Name = VisualStates.Authenticated, GroupName = VisualStates.CommonStates)]
    public class OpenIdLoginControl : ContentControl
    {
        private const string IdentityInput = "IdentityInput";
        private const string IdentitySuccessLabel = "IdentitySuccessLabel";
        private const string LoginButton = "LoginButton";

        public static readonly DependencyProperty DownloaderProperty =
            DependencyProperty.Register("Downloader", typeof (IDownloader), typeof (OpenIdLoginControl), null);

        public static readonly DependencyProperty OptionalParametersProperty =
            DependencyProperty.Register(
                "OptionalParameters",
                typeof (List<String>),
                typeof (OpenIdLoginControl),
                new PropertyMetadata(new List<String>()));

        public List<String> OptionalParameters
        {
            get { return m_openIdService.OptionalParameters; }
            set { m_openIdService.OptionalParameters = value; }
        }

        public static readonly DependencyProperty RequiredParametersProperty =
            DependencyProperty.Register(
                "RequiredParameters",
                typeof (List<String>),
                typeof (OpenIdLoginControl),
                new PropertyMetadata(new List<String>()));

        public List<String> RequiredParameters
        {
            get { return m_openIdService.RequiredParameters; }
            set { m_openIdService.RequiredParameters = value; }
        }



        private readonly OpenIdService m_openIdService = new OpenIdService();

        private TextBox m_identityInput;
        private TextBlock m_identitySuccessLabel;
        private Button m_loginButton;

        public event EventHandler<AuthenticatedEventArgs> OnAuthentication;

        public OpenIdLoginControl()
        {
            DefaultStyleKey = typeof (OpenIdLoginControl);
        }

        public IDownloader Downloader
        {
            get { return m_openIdService.Downloader; }
            set { m_openIdService.Downloader = value; }
        }


        public OpenIdUser User { get; set; }

        public override void OnApplyTemplate()
        {
            base.OnApplyTemplate();

            m_identityInput = (TextBox) GetTemplateChild(IdentityInput);
            m_loginButton = (Button) GetTemplateChild(LoginButton);
            m_identitySuccessLabel = (TextBlock) GetTemplateChild(IdentitySuccessLabel);

            if (m_loginButton != null)
                m_loginButton.Click += LoginButtonClick;

            DetermineAuthenticationStatus();
        }

        private void DetermineAuthenticationStatus()
        {
            //Read the querystring because if routed back from OpenId it will contain import information.
            IDictionary<string, string> query = HtmlPage.Document.QueryString;
            if (m_openIdService.IsOpenIdRequest(query))
            {
                OpenIdUser openIdUser = m_openIdService.Authenticate(query);
                User = openIdUser.IsSuccess ? openIdUser : null;
            }

            if (User != null)
            {
                //Authenticated
                if (OnAuthentication != null)
                    OnAuthentication(this, new AuthenticatedEventArgs(User));
                if (m_identitySuccessLabel != null)
                    m_identitySuccessLabel.Text = User.Identity;
                VisualStateManager.GoToState(this, VisualStates.Authenticated, false);
            }
            else
            {
                //Not Authenticated
                VisualStateManager.GoToState(this, VisualStates.Unauthenticated, false);
            }
        }

        private void LoginButtonClick(object sender, RoutedEventArgs e)
        {
            if (m_identityInput != null)
                m_openIdService.DefineLoginUrl(m_identityInput.Text, LoginUrlDefined);
        }

        private static void LoginUrlDefined(string loginUrl)
        {
            HtmlPage.Window.Navigate(new Uri(loginUrl));
        }

        #region Nested type: VisualStates

        private static class VisualStates
        {
            internal const string Authenticated = "Authenticated";
            internal const string CommonStates = "CommonStates";
            internal const string Unauthenticated = "Unauthenticated";
        }

        #endregion
    }
}