using System;
using System.Net;
using System.Windows;
using System.Windows.Browser;

namespace MM.OpenId.Controls
{
    public class StandardProxyDownloader : IDownloader
    {
        public static readonly DependencyProperty ProxyUriProperty =
            DependencyProperty.Register("ProxyUri", typeof (Uri), typeof (StandardProxyDownloader), null);

        public Uri ProxyUri { get; set; }

        public void Download(string url, Action<string> callBackOnComplete)
        {
            string urlToDownload = string.Format(ProxyUri.ToString(), HttpUtility.UrlEncode(url));

            var wc = new WebClient();
            wc.DownloadStringCompleted += (sender, e) =>
                                              {
                                                  if (e.Error != null)
                                                      callBackOnComplete(string.Empty);
                                                  else
                                                      callBackOnComplete(e.Result);
                                              };
            wc.DownloadStringAsync(new Uri(urlToDownload));

        }
    }
}