using System.Collections.Generic;

namespace MM.OpenId.Controls
{
    public class OpenIdUser
    {
        public OpenIdUser()
        {
            Parameters = new Dictionary<string, string>();
        }

        public string Identity { get; set; }
        public bool IsSuccess { get; set; }
        internal IDictionary<string,string> Parameters { get; set; }

        public void Add(string key, string value)
        {
            Parameters.Add(key,value);
        }

        public string this[string key]
        {
            get
            {
                if(Parameters.ContainsKey(key))
                    return Parameters[key];
                return null;
            }
        }
    }
}