namespace MM.OpenId.Controls
{
    public class Server
    {
        public string ServerUrl { get; set; }
        public string DelegateUrl { get; set; }
    }
}