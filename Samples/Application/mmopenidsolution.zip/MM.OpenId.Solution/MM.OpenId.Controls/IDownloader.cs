using System;

namespace MM.OpenId.Controls
{
    public interface IDownloader
    {
        void Download(string url, Action<string> callBackOnComplete);
    }
}