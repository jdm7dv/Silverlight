﻿To run the example project RIA Service July preview is required. It's not required for the control, but for the Proxy that's used.

Identity for demo purposes:
Identity: http://openid.mymonster.nl/demo
Password: demo

About Templating:
Because every application-team will probably want to have the login-control fit in their own application design, the OpenIdLoginControl is templatable as well. It's only required to have the following elements in place:
- IdentitySuccessLabel typeof TextBlock
- IdentityInput typeof TextBox
- LoginButton typeof Button
The following two Visual States exist:
- Authenticated
- Unauthenticated

About Proxies:

The OpenIdLoginControl needs to make use of the entered id as a html page. Because this access is out of our control, we are never sure there will be a CrossDomain.xml at the other end. That's why this control supports two built-in Downloaders:
- DefaultDownloader: Makes use of Silverlights built-in download capacities, but sadly will almost never work because the other end needs to accept crossdomain access.
Usage: <openid:DefaultDownloader />
- StandardProxyDownloader: Can make use of a known proxy, own-built or at least in your own control for the Cross Domain access. The normal url will be supplied as an argument.
Usage: <openid:StandardProxyDownloader ProxyUri="http://localhost:88/proxy.php?url={0}" />

Besides that you are allowed to provide your own implementation of IDownloader. In the Silverlight example project there's an implementation that makes use of the RIA Services Proxy Downloader built by me as well (http://mark.mymonster.nl/2009/05/16/silverlight-3-and-ria-service-cross-domain-proxy-enhanced/).
Usage: <SUI:CrossDomainProxyDownloader ProxyUri="DataService.axd/MM-Ria-CrossDomainProxy-DomainProxy/" />