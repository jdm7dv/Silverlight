﻿using System.Windows.Controls;
using MM.OpenId.Controls;

namespace MM.OpenId.SUI
{
    public partial class MainPage : UserControl
    {
        public MainPage()
        {
            InitializeComponent();
        }

        private void LoginControl_OnOnAuthentication(object sender, AuthenticatedEventArgs e)
        {
            if (LoginControl.User != null)
            {
                ContentAfterLogin.Text = "Logged in: " + LoginControl.User["email"];
            }
            else
            {
                ContentAfterLogin.Text = "Not signed in yet.";
            }
        }
    }
}