using System;
using System.Windows;
using MM.OpenId.Controls;
using MM.Ria.CrossDomainProxy;

namespace MM.OpenId.SUI
{
    public class CrossDomainProxyDownloader : IDownloader
    {
        #region IDownloader Members

        public void Download(string url, Action<string> callBackOnComplete)
        {
            var request = new ProxyRequest {Url = url};
            var domainProxy = new DomainProxy();
            domainProxy.Process(request, operation =>
                                             {
                                                 if (operation.HasError)
                                                     callBackOnComplete(string.Empty);
                                                 else
                                                     callBackOnComplete(operation.Value.Content);
                                             }, null);
        }

        #endregion
        public static readonly DependencyProperty ProxyUriProperty =
            DependencyProperty.Register("ProxyUri", typeof(Uri), typeof(CrossDomainProxyDownloader), null);
        public Uri ProxyUri { get; set; }
    }
}