﻿//******************************************************************************
// Module           :   Default.aspx.cs
// Description      :   code behind
//******************************************************************************
// Author           :   Alexander Bell
// Copyright        :   2009 Infosoft International Inc.
// DateCreated      :   07/03/2009
// LastModified     :   07/19/2009
// Version          :   1.02
//******************************************************************************
// DISCLAIMER: This Application is provide on AS IS basis without any warranty
//******************************************************************************

//******************************************************************************
// TERMS OF USE     :   This module is copyrighted.
//                  :   You can use it at your sole risk provided that you keep
//                  :   the original copyright note. 
//NOTE: ALL .WMV/.JPG FILES ARE FOR DEMO PURPOSE ONLY: DO NOT COPY/DISTRIBUTE!
//******************************************************************************
using System;

public partial class _Default : System.Web.UI.Page 
{
    
    // Silverlight Media Player styles (skins)
    protected enum MediaPlayerSkins
    {
        AudioGray,
        Basic,
        Classic,
        Console,
        Expression,
        Futuristic,
        Professional,
        Simple
    }

    // media source 
    // NOTE: THIS .WMV FILE IS FOR DEMO PURPOSE ONLY: DO NOT COPY/DISTRIBUTE!!!
    //**************************************************************************************
    private const string _domain = @"http://www.webinfocentral.com/";
    private string _source = _domain + "VIDEO/JJ2008/WMV/JJ2008_100.wmv";
    
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {

            #region Media Player initial settings
            MediaPlayer1.AutoPlay = true;
            MediaPlayer1.ScaleMode = System.Web.UI.SilverlightControls.ScaleMode.Zoom;
            MediaPlayer1.MediaSource = _source;
            MediaPlayer1.PlaceholderSource=_domain + @"VIDEO/JJ2008/ImgMain.JPG";
            MediaPlayer1.Width=600;
            MediaPlayer1.Height = 440;
            #endregion

            // NOTE: ALL .JPG FILEs ARE FOR DEMO PURPOSE ONLY: DO NOT COPY/DISTRIBUTE!
            #region Adding Media Player chapters
            
            System.Web.UI.SilverlightControls.MediaChapter mc =
            new System.Web.UI.SilverlightControls.MediaChapter();

            mc.Position = 18;
            mc.ThumbnailSource = 
            @"http://www.webinfocentral.com/VIDEO/JJ2008/ImgChapters/13P1010042.JPG";
            mc.Title = "Chapter1";
            MediaPlayer1.Chapters.Add(mc);
            mc = null;

            mc = new System.Web.UI.SilverlightControls.MediaChapter();
            mc.Position = 37;
            mc.ThumbnailSource = 
            @"http://www.webinfocentral.com/VIDEO/JJ2008/ImgChapters/18P1010048.JPG";
            mc.Title = "Chapter2";
            MediaPlayer1.Chapters.Add(mc);
            mc = null;

            mc = new System.Web.UI.SilverlightControls.MediaChapter();
            mc.Position = 70;
            mc.ThumbnailSource = 
            @"http://www.webinfocentral.com/VIDEO/JJ2008/ImgChapters/11P1010036.JPG";
            mc.Title = "Chapter3";
            MediaPlayer1.Chapters.Add(mc);
            mc = null;

            mc = new System.Web.UI.SilverlightControls.MediaChapter();
            mc.Position = 107;
            mc.ThumbnailSource = 
            @"http://www.webinfocentral.com//VIDEO/JJ2008/ImgChapters/08P1010026.JPG";
            mc.Title = "Chapter4";
            MediaPlayer1.Chapters.Add(mc);
            mc = null;

            mc = new System.Web.UI.SilverlightControls.MediaChapter();
            mc.Position = 134;
            mc.ThumbnailSource = 
            @"http://www.webinfocentral.com/VIDEO/JJ2008/ImgChapters/06P1010010.JPG";
            mc.Title = "Chapter5";
            MediaPlayer1.Chapters.Add(mc);
            mc = null;
            #endregion

            #region Dropdown Style selector
            // populate dropdown with Media Player styles (skin): looping through enum
            foreach (MediaPlayerSkins skin in Enum.GetValues(typeof(MediaPlayerSkins)))
            { cmbSkins.Items.Add(skin.ToString()); }

            // set dropdown autopostback
            cmbSkins.AutoPostBack = true;

            // select Professional style
            cmbSkins.SelectedValue = MediaPlayerSkins.Professional.ToString(); 
            
            MediaPlayer1.MediaSkinSource =
            "~/MediaPlayerSkins/" + cmbSkins.SelectedValue + ".xaml";
            #endregion
        }
    }

    #region User Events
    ///<summary>Select Media Player Skin</summary>
    protected void cmbSkins_SelectedIndexChanged(object sender, EventArgs e)
    {
        MediaPlayer1.MediaSkinSource =
            "~/MediaPlayerSkins/" + cmbSkins.SelectedValue + ".xaml";
    }
    #endregion
}