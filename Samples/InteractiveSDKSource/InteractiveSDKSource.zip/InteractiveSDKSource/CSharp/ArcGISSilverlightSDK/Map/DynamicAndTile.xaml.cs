﻿using System;
using System.Windows;
using System.Windows.Controls;

namespace ArcGISSilverlightSDK
{
    public partial class DynamicAndTile : UserControl
    {
        public DynamicAndTile()
        {
            InitializeComponent();
        }
    }
}
