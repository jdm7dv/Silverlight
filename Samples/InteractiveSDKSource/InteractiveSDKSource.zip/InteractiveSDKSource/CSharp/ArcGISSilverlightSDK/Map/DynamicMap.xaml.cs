﻿using System;
using System.Windows;
using System.Windows.Controls;

namespace ArcGISSilverlightSDK
{
    public partial class DynamicMap : UserControl
    {
        public DynamicMap()
        {
            InitializeComponent();
        }
    }
}
