﻿Imports Microsoft.VisualBasic
Imports System
Imports System.Windows
Imports System.Windows.Controls
Imports System.Windows.Data
Imports System.Windows.Media
Imports ESRI.ArcGIS.Client
Imports ESRI.ArcGIS.Client.Symbols
Imports ESRI.ArcGIS.Client.Tasks
Imports ESRI.ArcGIS.Client.ValueConverters

Namespace ArcGISSilverlightSDK
    Partial Public Class Find
        Inherits UserControl
        Public Sub New()
            InitializeComponent()
        End Sub

        Private Sub ExecuteButton_Click(ByVal sender As Object, ByVal e As RoutedEventArgs)
            Dim graphicsLayer As GraphicsLayer = TryCast(MyMap.Layers("MyGraphicsLayer"), GraphicsLayer)
            graphicsLayer.ClearGraphics()

            Dim findTask As New FindTask("http://sampleserver1.arcgisonline.com/ArcGIS/rest/services/" & "Demographics/ESRI_Census_USA/MapServer")
            AddHandler findTask.Failed, AddressOf FindTask_Failed

            Dim findParameters As New FindParameters()
            ' Layer ids to search
            findParameters.LayerIds.AddRange(New Integer() {3, 5})
            ' Fields in layers to search
            findParameters.SearchFields.AddRange(New String() {"NAME", "STATE_NAME", "STATE_ABBR", "TRACT", "BLOCK", "BLKGRP"})

            ' Bind data grid to find results.  Bind to the LastResult property which returns a list
            ' of FindResult instances.  When LastResult is updated, the ItemsSource property on the 
            ' will update.  
            Dim resultFeaturesBinding As New Binding("LastResult")
            resultFeaturesBinding.Source = findTask
            FindDetailsDataGrid.SetBinding(DataGrid.ItemsSourceProperty, resultFeaturesBinding)

            findParameters.SearchText = FindText.Text
            findTask.ExecuteAsync(findParameters)

            ' Since binding to DataGrid, handling the ExecuteComplete event is not necessary.
        End Sub

        Private Sub FindDetails_SelectionChanged(ByVal sender As Object, ByVal e As SelectionChangedEventArgs)
            ' Highlight the graphic feature associated with the selected row
            Dim dataGrid As DataGrid = TryCast(sender, DataGrid)

            Dim selectedIndex As Integer = dataGrid.SelectedIndex
            If selectedIndex > -1 Then
                Dim findResult As FindResult = CType(FindDetailsDataGrid.SelectedItem, FindResult)
                Dim graphic As Graphic = findResult.Feature

                Select Case graphic.Attributes("Shape").ToString()
                    Case "Polygon"
                        graphic.Symbol = DefaultFillSymbol
                    Case "Polyline"
                        graphic.Symbol = DefaultLineSymbol
                    Case "Point"
                        graphic.Symbol = DefaultMarkerSymbol
                End Select

                Dim graphicsLayer As GraphicsLayer = TryCast(MyMap.Layers("MyGraphicsLayer"), GraphicsLayer)
                graphicsLayer.ClearGraphics()
                graphicsLayer.Graphics.Add(graphic)
            End If
        End Sub

        Private Sub FindTask_Failed(ByVal sender As Object, ByVal args As TaskFailedEventArgs)
            MessageBox.Show("Find failed: " & args.Error.Message)
        End Sub
    End Class
End Namespace
