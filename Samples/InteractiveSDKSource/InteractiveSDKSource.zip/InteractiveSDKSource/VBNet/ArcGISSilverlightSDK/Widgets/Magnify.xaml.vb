﻿Imports Microsoft.VisualBasic
Imports System
Imports System.Collections.Generic
Imports System.Linq
Imports System.Net
Imports System.Windows
Imports System.Windows.Controls
Imports System.Windows.Documents
Imports System.Windows.Input
Imports System.Windows.Media
Imports System.Windows.Media.Animation
Imports System.Windows.Shapes

Namespace ArcGISSilverlightSDK
    Partial Public Class Magnify
        Inherits UserControl
        Public Sub New()
            InitializeComponent()

            MyMagnifier.Initialize(MyMap)
        End Sub

        Private Sub MyMagnifyImage_MouseLeftButtonDown(ByVal sender As Object, ByVal e As MouseButtonEventArgs)
            MyMagnifier.Enabled = Not MyMagnifier.Enabled
        End Sub
    End Class
End Namespace
