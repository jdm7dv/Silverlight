﻿Imports Microsoft.VisualBasic
Imports System
Imports System.Collections.Generic
Imports System.Linq
Imports System.Net
Imports System.Windows
Imports System.Windows.Controls
Imports System.Windows.Documents
Imports System.Windows.Input
Imports System.Windows.Media
Imports System.Windows.Media.Animation
Imports System.Windows.Shapes

Namespace ArcGISSilverlightSDK
    Partial Public Class Navigation
        Inherits UserControl
        Public Sub New()
            InitializeComponent()

            MyNavigation.Map = MyMap
        End Sub
    End Class
End Namespace
