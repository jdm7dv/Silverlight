﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace OfficeExport
{
    /// <summary>
    /// Specifies the export settings specific to Word documents.
    /// </summary>
    public class WordExportSettings
        : ExportSettings
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="WordExportSettings"/> class.
        /// </summary>
        public WordExportSettings()
        {
            this.OptimizeFor = OfficeExport.OptimizeFor.Print;
            this.Item = ExportItem.DocumentContent;
            this.KeepIRM = true;
        }

        /// <summary>
        /// Specifies whether to optimize for screen or print. Default value is <see cref="OfficeExport.OptimizeFor.Print"/>
        /// </summary>
        /// <value>The optimization setting</value>
        public OptimizeFor OptimizeFor { get; set; }
        /// <summary>
        /// Specifies whether the export process includes text only or includes text with markup. Default value is <see cref="ExportItem.DocumentContent"/>
        /// </summary>
        /// <value>The item.</value>
        public ExportItem Item { get; set; }
        /// <summary>
        /// Specifies whether to copy IRM permissions to an XPS document if the source document has IRM protections. Default value is True.
        /// </summary>
        /// <value><c>true</c> if keep IRM; otherwise, <c>false</c>.</value>
        public bool KeepIRM { get; set; }

    }
}
