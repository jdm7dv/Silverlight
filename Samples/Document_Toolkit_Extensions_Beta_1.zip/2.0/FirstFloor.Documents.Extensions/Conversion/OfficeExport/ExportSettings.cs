﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace OfficeExport
{
    /// <summary>
    /// Provides the shared settings for an export.
    /// </summary>
    public abstract class ExportSettings
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ExportSettings"/> class.
        /// </summary>
        public ExportSettings()
        {
            this.Format = ExportFormat.Xps;
            this.OpenAfterExport = false;
            this.IncludeDocProps = true;
            this.Range = ExportRange.AllDocument;
            this.From = 1;
            this.To = 1;
        }

        /// <summary>
        /// Specifies either PDF or XPS format. Default value is <see cref="ExportFormat.Xps"/>.
        /// </summary>
        /// <value>The export format.</value>
        public ExportFormat Format { get; set; }
        /// <summary>
        /// Specifies whether to open the new file after exporting the contents. Default value is False.
        /// </summary>
        /// <value><c>true</c> if open after export; otherwise, <c>false</c>.</value>
        public bool OpenAfterExport { get; set; }
        /// <summary>
        /// Specifies whether to include document properties in the newly exported file. Default value if True.
        /// </summary>
        /// <value><c>true</c> if include properties; otherwise, <c>false</c>.</value>
        public bool IncludeDocProps { get; set; }
        /// <summary>
        /// Specifies the export range of the document. Default value is <see cref="ExportRange.AllDocument"/>.
        /// </summary>
        /// <value>The range.</value>
        public ExportRange Range { get; set; }
        /// <summary>
        /// Specifies the starting page number. Default value is 1.
        /// </summary>
        /// <remarks>
        /// This property is only used when the <see cref="ExportSettings.Range"/> property has value <see cref="ExportRange.FromTo"/>.
        /// </remarks>
        /// <value>From.</value>
        public int From { get; set; }
        /// <summary>
        /// Specifies the ending page number. Default value is 1.
        /// </summary>
        /// <value>To.</value>
        public int To { get; set; }
    }
}
