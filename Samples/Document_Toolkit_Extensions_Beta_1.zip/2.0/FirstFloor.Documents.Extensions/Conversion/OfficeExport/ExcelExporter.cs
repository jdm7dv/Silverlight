﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace OfficeExport
{
    /// <summary>
    /// Exports Excel work sheets to XPS or PDF.
    /// </summary>
    public class ExcelExporter
        : Exporter<WordExportSettings>
    {
        /// <summary>
        /// Creates an instance of the export settings.
        /// </summary>
        /// <returns></returns>
        protected override WordExportSettings CreateSettings()
        {
            return new WordExportSettings();
        }

        /// <summary>
        /// Implements the actual export logic.
        /// </summary>
        /// <param name="sourcePath">The source path.</param>
        /// <param name="targetPath">The target path.</param>
        protected override void OnExport(string sourcePath, string targetPath)
        {
            throw new NotImplementedException();
        }
    }
}
