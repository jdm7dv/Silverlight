Conversion
==========
Includes projects for XPS document conversion and automation of exporting Microsoft Office 2010 documents to PDF and XPS documents. Currently supports the export of Excel, Powerpoint and Word documents.

Requires Office 2010 to be installed on the local machine for the Office projects.


OfficeExport (.NET 4 library)
-----------------------------
Implements COM automation wrapper for office document export. The library hides the actual interop libraries.


OfficeExportApp (.NET 4 console app)
------------------------------------
Provides a console application wrapper for the OfficeExport library.


XpsConvert (.NET 4 library)
---------------------------
Processes XPS documents and converts images not supported by Silverlight (TIFF & Windows Media Photo) to JPEG images.
