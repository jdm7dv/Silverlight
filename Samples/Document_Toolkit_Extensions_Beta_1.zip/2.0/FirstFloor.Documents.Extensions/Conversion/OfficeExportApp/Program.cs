﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

using OfficeExport;

namespace OfficeExportApp
{
    class Program
    {
        static void WriteUsage()
        {
            Console.WriteLine("Exports Microsoft Excel, PowerPoint and Word documents to XPS or PDF.");
            Console.WriteLine();
            Console.WriteLine("OFFICEEXPORT source [destination]");
            Console.WriteLine();
        }

        static void WriteError(string message)
        {
            Console.WriteLine("ERROR: {0}", message);
            Console.WriteLine();
        }

        static void Main(string[] args)
        {
            Console.WriteLine("Office Document To PDF/XPS Exporter");
            Console.WriteLine("Copyright (c) 2010 First Floor Software. All rights reserved.");
            Console.WriteLine();

            if (args.Length == 0) {
                WriteUsage();
            }
            else {
                var source = args[0];

                var exporter = ExporterBase.GetExporterForFile(source);
                if (exporter == null) {
                    WriteError("Source document is not supported");
                }
                else {
                    try {
                        Console.Write("Exporting...");
                        var targetFileName = string.Format("{0}{1}", Path.GetFileNameWithoutExtension(source), exporter.PreferredFileExtension);
                        var target = Path.Combine(Path.GetDirectoryName(source), targetFileName);

                        exporter.Export(source, target);

                        Console.WriteLine("OK");
                        Console.WriteLine("Export to '{0}' completed successfully", targetFileName);
                    }
                    catch (Exception e) {
                        Console.WriteLine("FAILED");

                        WriteError(e.Message);
                    }
                }
            }

            Console.ReadKey();
        }
    }
}
