Package Readers
===============
Contains package readers that use 3rd party ZIP libraries to read XPS documents. 3rd party ZIP libraries typically achieve a better performance than the DefaultPackageReader that is included in Document Toolkit.


DotNetZip (SL4 library)
-----------------------
Provides a package reader based on a Silverlight port of the DotNetZip library (Microsoft Public License (Ms-PL).

See also http://dotnetzip.codeplex.com


SharpZipLib (SL4 library)
-------------------------
Provides a package reader based on a Silverlight port of the SharpZip library (modified GPL license).

See also http://www.icsharpcode.net/OpenSource/SharpZipLib/Default.aspx