Sample Browser
==============
Provides the complete source code of the Document Toolkit sample browser application. The sample browser application demonstrates all features of Document Toolkit using a variety of samples.


DocumentServices (.NET 4 lib)
-----------------------------
Demonstrates on-the-fly document conversion using the third-party Aspose.Words component and includes a document service for handling requests for individual XPS document parts.


SampleBrowser: (SL4 app)
------------------------
The actual Silverlight application containing all samples


SampleBrowser.Web (ASP.NET 4 Web App)
-------------------------------------
The web application hosting the SampleBrowser.


How To
======
Follow these steps to run the sample browser application.

1. Open the solution in VS.NET 2010
2. (optional) Remove the Office2Xps and Office2XpsApp projects from the solution if you do not have Office 2010 installed
3. Build the solution
3. (!) Set the SampleBrowser.Web project as StartUp Project
4. Run the application.


The Document Toolkit Sample Browser is also available online at http://firstfloorsoftware.com/liveapps/DocumentToolkit.