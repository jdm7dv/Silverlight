﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;

using Aspose.Words;
using DocumentServices.Storage;

namespace DocumentServices.RequestHandlers
{
    /// <summary>
    /// Converts uploaded documents to XPS on-the-fly using Aspose.Words and writes the entire result XPS document to the output.
    /// </summary>
    public class ConvertToXpsHandler
        : IRequestHandler
    {
        /// <summary>
        /// Handles the request.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="store">The store.</param>
        public void HandleRequest(HttpContext context, IDocumentStore store)
        {
            // limit requests to 512kb
            if (context.Request.ContentLength > 2 << 18) {
                throw new NotSupportedException();
            }

            // load document
            Document document = new Document(context.Request.InputStream);
            // convert to XPS
            document.Save(context.Response.OutputStream, SaveFormat.Xps);
        }
    }
}
