﻿using System;
using System.Collections.Generic;
using System.Web;
using System.IO;

namespace DocumentServices.Storage
{
    /// <summary>
    /// Represents a single part of a document.
    /// </summary>
    public class DocumentPartInfo
    {
        private string contentType;
        private Stream stream;

        /// <summary>
        /// Gets or sets the content type of the part.
        /// </summary>
        /// <value>The type of the content.</value>
        public string ContentType
        {
            get { return this.contentType; }
            set { this.contentType = value; }
        }

        /// <summary>
        /// Gets or sets the part stream.
        /// </summary>
        /// <value>The stream.</value>
        public Stream Stream
        {
            get { return this.stream; }
            set { this.stream = value; }
        }
    }
}