﻿using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Packaging;
using System.Linq;
using System.Web;
using System.Windows.Xps.Packaging;

namespace DocumentServices.Storage.FileSystem
{
    /// <summary>
    /// Represents an abstraction access layer for the documents available in a folder on the server's file system. 
    /// </summary>
    /// <remarks>
    /// This file-based implementation uses a folder as backing store.
    /// </remarks>
    public class FileSystemDocumentStore
        : DocumentStoreBase
    {
        private string folder;

        /// <summary>
        /// Initializes a new instance of the <see cref="FileSystemDocumentStore"/> class.
        /// </summary>
        /// <param name="folder">The folder.</param>
        public FileSystemDocumentStore(string folder)
        {
            if (string.IsNullOrEmpty(folder)) {
                throw new ArgumentNullException("folder");
            }
            if (!Directory.Exists(folder)) {
                throw new ArgumentException("Specified folder does not exist");
            }
            this.folder = folder;
        }

        /// <summary>
        /// Adds specified document to the store.
        /// </summary>
        /// <param name="name">The name.</param>
        /// <param name="document">The document.</param>
        public override void AddDocument(string name, Stream document)
        {
            if (ContainsDocument(name)) {
                throw new ArgumentException("Document already exists");
            }

            const int bufferSize = 16384;

            var path = Path.Combine(this.folder, name);
            using (var fileStream = File.OpenWrite(path)) {
                byte[] buffer = new byte[bufferSize];
                int read;
                while ((read = document.Read(buffer, 0, bufferSize)) > 0) {
                    fileStream.Write(buffer, 0, read);
                }
            }
        }

        /// <summary>
        /// Determines whether the specified document exists.
        /// </summary>
        /// <param name="name">The name.</param>
        /// <returns>
        /// 	<c>true</c> if the specified document exists; otherwise, <c>false</c>.
        /// </returns>
        public override bool ContainsDocument(string name)
        {
            return File.Exists(Path.Combine(this.folder, name));
        }

        /// <summary>
        /// Opens the specified document for reading.
        /// </summary>
        /// <param name="name">The name.</param>
        /// <returns></returns>
        public override Stream OpenDocument(string name)
        {
            return File.OpenRead(Path.Combine(this.folder, name));
        }

        /// <summary>
        /// Gets the document's last modification date.
        /// </summary>
        /// <param name="name">The name.</param>
        /// <returns></returns>
        public override DateTime GetDocumentLastModified(string name)
        {
            return File.GetLastWriteTime(Path.Combine(this.folder, name));
        }

        /// <summary>
        /// Gets all documents contained in this store.
        /// </summary>
        /// <returns></returns>
        public override IEnumerable<DocumentInfo> GetDocuments()
        {
            var files = Directory.GetFiles(this.folder, "*.xps");

            foreach (var file in files) {
                string name = Path.GetFileName(file);
                using (var stream = OpenDocument(name)) {
                    yield return ReadDocumentInfo(name, stream);
                }
            }
        }

        /// <summary>
        /// Removes specified document from the store.
        /// </summary>
        /// <param name="name">The name.</param>
        public override void RemoveDocument(string name)
        {
            File.Delete(Path.Combine(this.folder, name));
        }
    }
}