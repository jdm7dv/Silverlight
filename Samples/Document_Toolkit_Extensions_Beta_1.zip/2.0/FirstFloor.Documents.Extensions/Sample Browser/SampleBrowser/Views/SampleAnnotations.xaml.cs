﻿using System;
using System.Collections.Generic;
using System.IO.IsolatedStorage;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Windows.Navigation;

using FirstFloor.Documents.Annotations;
using FirstFloor.Documents.Annotations.Storage;
using FirstFloor.Documents.Controls;
using SharpZipLib;
using System.IO;
using SampleBrowser.Annotations;

namespace SampleBrowser.Views
{
    public partial class SampleAnnotations : Page
    {
        private const string AnnotationsFileName = "annotations.xml";

        public SampleAnnotations()
        {
            InitializeComponent();

            // use the annotation store declared in XAML
            var annotations = (AnnotationStore)LayoutRoot.Resources["AnnotationStore"];

            // register the custom annotation factories
            annotations.RegisterFactory(new InkFactory());
            annotations.RegisterFactory(new UnderlineFactory());

            try {
                // check whether an annotation store is available in isolated storage
                var iso = IsolatedStorageFile.GetUserStoreForApplication();
                if (iso.FileExists(AnnotationsFileName)) {
                    using (var stream = iso.OpenFile(AnnotationsFileName, FileMode.Open)) {
                        annotations.Load(stream);
                    }
                }
            }
            catch (Exception) {
                // too bad, failed to load annotations
            }

            // enable annotation service
            var service = new AnnotationService(this.Viewer);
            service.Enable(annotations);

            this.Loaded += (o, e) => {
                this.DataSource.PackageReader = new SharpZipPackageReader(new Uri("Assets/Documents/WhitePaper.xps", UriKind.Relative));
            };
        }

        protected override void OnNavigatedFrom(NavigationEventArgs e)
        {
            base.OnNavigatedFrom(e);

            // save annotations to isolated storage
            var store = (AnnotationStore)LayoutRoot.Resources["AnnotationStore"];
            try {
                var iso = IsolatedStorageFile.GetUserStoreForApplication();

                
                using (var stream = iso.OpenFile(AnnotationsFileName, FileMode.Create)) {
                    store.Save(stream);
                }
            }
            catch (Exception) {
                // too bad, failed to save annotations.
            }

            // properly clears the datasource and closes the package reader
            this.DataSource.PackageReader = null;
        }

        private void DataSource_LoadError(object sender, ErrorEventArgs e)
        {
            new ErrorWindow(e.Error).Show();
        }

    }
}
