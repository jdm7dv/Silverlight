﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Windows.Navigation;
using System.Xml.Linq;

namespace SampleBrowser.Views
{
    public partial class Samples : Page
    {
        public Samples()
        {
            InitializeComponent();

            // load samples as defined in Samples.xml
            var samples = XDocument.Load("Samples.xml");

            this.Accordion.ItemsSource = from g in samples.Descendants("Group")
                                         orderby (string)g.Attribute("Name")
                                         select new GroupInfo() {
                                             Name = (string)g.Attribute("Name"),
                                             Samples = from s in g.Elements("Sample")
                                                       orderby (string)s.Attribute("Name")
                                                       select new SampleInfo() {
                                                           Name = (string)s.Attribute("Name"),
                                                           Description = (string)s.Attribute("Description"),
                                                           Link = (string)s.Attribute("Link")
                                                       }
                                         };

        }

    }
}
