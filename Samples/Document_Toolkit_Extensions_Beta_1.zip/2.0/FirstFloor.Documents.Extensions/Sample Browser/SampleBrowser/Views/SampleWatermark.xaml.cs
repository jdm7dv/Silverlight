﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Windows.Navigation;
using SharpZipLib;
using FirstFloor.Documents.Controls;

namespace SampleBrowser.Views
{
    public partial class SampleWatermark : Page
    {
        public SampleWatermark()
        {
            InitializeComponent();

            this.Loaded += (o, e) => {
                this.DataSource.PackageReader = new SharpZipPackageReader(new Uri("Assets/Documents/WhitePaper.xps", UriKind.Relative));
            };
        }

        protected override void OnNavigatedFrom(NavigationEventArgs e)
        {
            base.OnNavigatedFrom(e);

            // properly clears the datasource and closes the package reader
            this.DataSource.PackageReader = null;
        }

        private void DataSource_LoadError(object sender, ErrorEventArgs e)
        {
            new ErrorWindow(e.Error).Show();
        }

    }
}
