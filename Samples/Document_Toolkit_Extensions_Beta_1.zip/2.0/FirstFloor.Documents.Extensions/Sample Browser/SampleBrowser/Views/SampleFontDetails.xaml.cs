﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Windows.Navigation;

using FirstFloor.Documents.Fonts;

namespace SampleBrowser.Views
{
    public partial class SampleFontDetails : Page
    {
        private FontFamily currentFontFamily;

        public SampleFontDetails()
        {
            InitializeComponent();

            var fonts = Fonts.AllFonts().ToArray();
            this.cmbFont.ItemsSource = fonts;
            this.cmbFont.SelectedItem = fonts.First();
        }

        private void cmbFont_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            var font = (Fonts.FontInfo)this.cmbFont.SelectedItem;
            if (font != null) {
                // use font parser to create a typeface
                var parser = new FontParser();
                var fontInfo = parser.ParseFontInfo(font.FontStream);
                var typeface = parser.ParseFontFace(fontInfo, 0);

                // databind to UI
                var localizedTypeface = typeface.GetDefaultLocalizedTypeface();
                this.DataContext = localizedTypeface;
                this.currentFontFamily = new FontFamily(string.Format("{0}#{1}", font.FontUri, localizedTypeface.FamilyName));

                UpdateSampleTexts();
            }
        }

        private void UpdateSampleTexts()
        {
            foreach (var text in GetSampleTexts()) {
                if (text != null) {
                    text.FontFamily = this.currentFontFamily;
                }
            }
        }

        private IEnumerable<TextBlock> GetSampleTexts()
        {
            for (int i = 1; i <= 9; i++) {
                yield return (TextBlock)this.FindName(string.Format("sample{0}", i));
            }
        }

        private void sampleTexts_Loaded(object sender, System.Windows.RoutedEventArgs e)
        {
            UpdateSampleTexts();
        }
    }
}
