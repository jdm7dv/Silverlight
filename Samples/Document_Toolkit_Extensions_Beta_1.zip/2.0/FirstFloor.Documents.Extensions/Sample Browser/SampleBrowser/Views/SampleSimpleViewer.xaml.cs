﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Navigation;
using FirstFloor.Documents.Controls;
using SharpZipLib;

namespace SampleBrowser.Views
{
    public partial class SampleSimpleViewer : Page
    {
        public SampleSimpleViewer()
        {
            InitializeComponent();

            this.Loaded += (o, e) => {
                this.DataSource.PackageReader = new SharpZipPackageReader(new Uri("Assets/Documents/WhitePaper.xps", UriKind.Relative));
            };
        }

        protected override void OnNavigatedFrom(NavigationEventArgs e)
        {
            base.OnNavigatedFrom(e);

            // properly clears the datasource and closes the package reader
            this.DataSource.PackageReader = null;
        }

        private void DataSource_LoadError(object sender, ErrorEventArgs e)
        {
            new ErrorWindow(e.Error).Show();
        }

        private void Printer_PrintError(object sender, ErrorEventArgs e)
        {
            new ErrorWindow(e.Error).Show();
        }

    }
}
