﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Media.Effects;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Windows.Interactivity;
using System.Xml.Linq;

using FirstFloor.Documents.Controls;

namespace SampleBrowser.Behaviors
{
    /// <summary>
    /// Represents an interactive form fill behavior.
    /// </summary>
    public class FormFillBehavior
        : Behavior<FixedPageViewer>
    {
        private List<TextBox> textBoxes = new List<TextBox>();

        /// <summary>
        /// Called after the behavior is attached to an AssociatedObject.
        /// </summary>
        /// <remarks>Override this to hook up functionality to the AssociatedObject.</remarks>
        protected override void OnAttached()
        {
            base.OnAttached();

            this.AssociatedObject.FixedPageChanged += OnFixedPageChanged;
        }

        /// <summary>
        /// Called when the behavior is being detached from its AssociatedObject, but before it has actually occurred.
        /// </summary>
        /// <remarks>Override this to unhook functionality from the AssociatedObject.</remarks>
        protected override void OnDetaching()
        {
            base.OnDetaching();

            this.AssociatedObject.FixedPageChanged -= OnFixedPageChanged;
        }

        private void OnFixedPageChanged(object sender, EventArgs e)
        {
            if (this.AssociatedObject.FixedPage == null) {
                // page is unloaded, release the textboxes
                foreach (var textBox in this.textBoxes) {
                    // release event handler (important, do not leak memory)
                    textBox.TextChanged -= textBox_TextChanged;

                    // remove textbox from its parent
                    ((Canvas)textBox.Parent).Children.Remove(textBox);
                }
            }
            else {
                if (this.textBoxes.Count == 0) {
                    // page is loaded for the first time, start creating textboxes

                    // load form data for this page from a custom XML document located in the XAP
                    var form = XDocument.Load("Assets/Documents/Change Request Form.xml");
                    var controls = from page in form.Descendants("Page")
                                   from text in page.Elements("Text")
                                   where (int)page.Attribute("PageNumber") == this.AssociatedObject.FixedPage.PageNumber
                                   select new {
                                       Left = (double)text.Attribute("Left"),
                                       Top = (double)text.Attribute("Top"),
                                       Right = (double)text.Attribute("Right"),
                                       Bottom = (double)text.Attribute("Bottom"),
                                       Multiline = (bool?)text.Attribute("Multiline") ?? false,
                                       Description = (string)text.Attribute("Description"),
                                   };

                    foreach (var control in controls) {
                        var textBox = CreateTextBox(control.Left, control.Top, control.Right, control.Bottom, control.Multiline, control.Description);
                        this.textBoxes.Add(textBox);
                    }
                }

                // create a parent canvas for all input controls
                var canvas = new Canvas();
                this.AssociatedObject.FixedPage.Children.Add(canvas);

                // add textboxes to the canvas
                foreach (var textBox in this.textBoxes) {
                    canvas.Children.Add(textBox);
                }
            }
        }

        private TextBox CreateTextBox(double left, double top, double right, double bottom, bool multiline, string tooltip)
        {
            var textBox = new TextBox() {
                Width = right - left,
                Height = bottom - top,
                FontFamily = new FontFamily("Verdana"),
                FontSize = 12,
                AcceptsReturn = multiline,
                Background = new SolidColorBrush(Color.FromArgb(0xff, 0xdd, 0xdd, 0xff))
            };
            Canvas.SetLeft(textBox, left);
            Canvas.SetTop(textBox, top);
            ToolTipService.SetToolTip(textBox, tooltip);
            textBox.TextChanged += textBox_TextChanged;

            return textBox;
        }

        private void textBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            // TODO: do something useful here
        }
    }
}

