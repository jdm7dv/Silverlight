﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Media;

using FirstFloor.Documents;

namespace SampleBrowser.MetadataViewModel
{
    /// <summary>
    /// Represents the content type collection node.
    /// </summary>
    public class ContentTypeCollectionNode
        : Node
    {
        private XpsDocument owner;

        /// <summary>
        /// Initializes a new instance of the <see cref="ContentTypeCollectionNode"/> class.
        /// </summary>
        /// <param name="owner">The owner.</param>
        /// <param name="options">The options.</param>
        public ContentTypeCollectionNode(XpsDocument owner, ViewModelOptions options)
            : base(options)
        {
            this.owner = owner;
        }

        /// <summary>
        /// Gets the text.
        /// </summary>
        /// <value>The text.</value>
        public override string Text
        {
            get { return string.Format("Content types ({0})", this.owner.ContentTypes.Count()); }
        }

        /// <summary>
        /// Gets the icon.
        /// </summary>
        /// <value>The image source.</value>
        public override string Icon
        {
            get { return "/SampleBrowser;component/Assets/Icons/folder_picture.png"; }
        }

        /// <summary>
        /// Gets the child nodes.
        /// </summary>
        /// <value>The nodes.</value>
        public override IEnumerable<Node> Children
        {
            get
            {
                foreach (string type in this.owner.ContentTypes.Select(ct => {return ct.Type;}).Distinct()) {
                    yield return new ContentTypeNode(type, this.Options);
                }

            }
        }
    }
}
