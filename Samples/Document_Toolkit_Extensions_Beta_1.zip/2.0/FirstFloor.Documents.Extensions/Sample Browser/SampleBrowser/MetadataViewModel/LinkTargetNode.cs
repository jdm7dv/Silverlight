﻿using System;
using System.Windows.Media;
using System.Windows.Media.Imaging;

using FirstFloor.Documents;

namespace SampleBrowser.MetadataViewModel
{
    /// <summary>
    /// Represents a link target node.
    /// </summary>
    public class LinkTargetNode
        : Node
    {
        private LinkTarget target;

        /// <summary>
        /// Initializes a new instance of the <see cref="LinkTargetNode"/> class.
        /// </summary>
        /// <param name="target">The target.</param>
        /// <param name="options">The options.</param>
        public LinkTargetNode(LinkTarget target, ViewModelOptions options)
            : base(options)
        {
            this.target = target;
        }

        /// <summary>
        /// Gets the text.
        /// </summary>
        /// <value>The text.</value>
        public override string Text
        {
            get { return this.target.Name; }
        }

        /// <summary>
        /// Gets the icon.
        /// </summary>
        /// <value>The icon uri.</value>
        public override string Icon
        {
            get { return "/SampleBrowser;component/Assets/Icons/link.png"; }
        }

        /// <summary>
        /// Gets the page that is associated with this node instace.
        /// </summary>
        /// <value>The page.</value>
        public override PageContent Page
        {
            get { return this.target.Page; }
        }
    }
}
