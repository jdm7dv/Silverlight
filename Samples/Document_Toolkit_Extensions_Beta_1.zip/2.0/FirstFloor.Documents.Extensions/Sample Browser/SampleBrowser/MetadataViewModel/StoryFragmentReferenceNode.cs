﻿using System;
using System.Globalization;
using System.Windows.Media;

using FirstFloor.Documents;
using FirstFloor.Documents.DocumentStructures;

namespace SampleBrowser.MetadataViewModel
{
    /// <summary>
    /// Represents a story fragment reference node
    /// </summary>
    public class StoryFragmentReferenceNode
        : Node
    {
        private FixedDocument owner;

        /// <summary>
        /// Initializes a new instance of the <see cref="StoryFragmentReferenceNode"/> class.
        /// </summary>
        /// <param name="owner">The owner.</param>
        /// <param name="fragment">The fragment.</param>
        /// <param name="options">The options.</param>
        public StoryFragmentReferenceNode(FixedDocument owner, StoryFragmentReference fragment, ViewModelOptions options)
            : base(options)
        {
            this.owner = owner;
            this.Fragment = fragment;
        }

        /// <summary>
        /// Gets the text.
        /// </summary>
        /// <value>The text.</value>
        public override string Text
        {
            get { return this.Fragment.FragmentName ?? string.Format("Page {0}", this.Fragment.Page); }
        }

        /// <summary>
        /// Gets the icon.
        /// </summary>
        /// <value>The icon uri.</value>
        public override string Icon
        {
            get { return "/SampleBrowser;component/Assets/Icons/page_go.png"; }
        }

        /// <summary>
        /// Gets a reference to the fragment.
        /// </summary>
        /// <value>The fragment.</value>
        public StoryFragmentReference Fragment { get; private set; }

        /// <summary>
        /// Gets the page that is associated with this node instace.
        /// </summary>
        /// <value>The page.</value>
        public override PageContent Page
        {
            get { return this.owner.Owner.GetPage(this.Fragment.Page); }
        }
    }
}
