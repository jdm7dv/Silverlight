﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Media;

using FirstFloor.Documents;
using FirstFloor.Documents.DocumentStructures;

namespace SampleBrowser.MetadataViewModel
{
    /// <summary>
    /// Represents the document outline node.
    /// </summary>
    public class OutlineNode
        : Node
    {
        private FixedDocument owner;

        /// <summary>
        /// Initializes a new instance of the <see cref="OutlineNode"/> class.
        /// </summary>
        /// <param name="owner">The owner.</param>
        /// <param name="options">The options.</param>
        public OutlineNode(FixedDocument owner, ViewModelOptions options)
            : base(options)
        {
            this.owner = owner;
        }

        /// <summary>
        /// Gets the text.
        /// </summary>
        /// <value>The text.</value>
        public override string Text
        {
            get { return "Table of contents"; }
        }

        /// <summary>
        /// Gets the icon.
        /// </summary>
        /// <value>The icon uri.</value>
        public override string Icon
        {
            get { return "/SampleBrowser;component/Assets/Icons/table.png"; }
        }

        /// <summary>
        /// Gets a reference to the document outline.
        /// </summary>
        /// <value>The outline.</value>
        public IEnumerable<OutlineEntry> Outline
        {
            get { return this.owner.DocumentStructure.DocumentOutline; }
        }

        /// <summary>
        /// Gets the child nodes.
        /// </summary>
        /// <value>The nodes.</value>
        public override IEnumerable<Node> Children
        {
            get
            {
                foreach (OutlineEntry entry in this.Outline.Where(e => { return e.OutlineLevel == null || e.OutlineLevel == 1; })) {
                    yield return new OutlineEntryNode(this.owner, entry, this.Options);
                }
            }
        }
    }
}
