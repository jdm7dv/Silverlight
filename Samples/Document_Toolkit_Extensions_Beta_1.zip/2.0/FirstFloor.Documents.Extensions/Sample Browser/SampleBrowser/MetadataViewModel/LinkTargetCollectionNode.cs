﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Media;

using FirstFloor.Documents;

namespace SampleBrowser.MetadataViewModel
{
    /// <summary>
    /// Represents the link target collection node.
    /// </summary>
    public class LinkTargetCollectionNode
        : Node
    {
        private IEnumerable<LinkTarget> targets;

        /// <summary>
        /// Initializes a new instance of the <see cref="LinkTargetCollectionNode"/> class.
        /// </summary>
        /// <param name="targets">The targets.</param>
        /// <param name="options">The options.</param>
        public LinkTargetCollectionNode(IEnumerable<LinkTarget> targets, ViewModelOptions options)
            : base(options)
        {
            this.targets = targets;
        }

        /// <summary>
        /// Gets the text.
        /// </summary>
        /// <value>The text.</value>
        public override string Text
        {
            get { return string.Format("Link targets ({0})", this.targets.Count()); }
        }

        /// <summary>
        /// Gets the icon.
        /// </summary>
        /// <value>The icon uri.</value>
        public override string Icon
        {
            get { return "/SampleBrowser;component/Assets/Icons/folder_link.png"; }
        }

        /// <summary>
        /// Gets the child nodes.
        /// </summary>
        /// <value>The nodes.</value>
        public override IEnumerable<Node> Children
        {
            get
            {
                foreach (LinkTarget target in this.targets) {
                    yield return new LinkTargetNode(target, this.Options);
                }
            }
        }
    }
}
