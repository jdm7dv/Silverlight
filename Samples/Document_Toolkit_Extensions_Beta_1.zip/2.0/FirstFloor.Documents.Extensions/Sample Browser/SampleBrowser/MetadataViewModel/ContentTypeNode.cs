﻿using System;
using System.Windows.Media;

using FirstFloor.Documents;

namespace SampleBrowser.MetadataViewModel
{
    /// <summary>
    /// Represents a content-type node.
    /// </summary>
    public class ContentTypeNode
        : Node
    {
        private string contentType;

        /// <summary>
        /// Initializes a new instance of the <see cref="ContentTypeNode"/> class.
        /// </summary>
        /// <param name="contentType">Type of the content.</param>
        /// <param name="options">The options.</param>
        public ContentTypeNode(string contentType, ViewModelOptions options)
            : base(options)
        {
            this.contentType = contentType;
        }

        /// <summary>
        /// Gets the text.
        /// </summary>
        /// <value>The text.</value>
        public override string Text
        {
            get { return this.contentType; }
        }

        /// <summary>
        /// Gets the icon.
        /// </summary>
        /// <value>The icon uri.</value>
        public override string Icon
        {
            get { return "/SampleBrowser;component/Assets/Icons/page_world.png"; }
        }
    }
}
