﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

using FirstFloor.Documents;

namespace SampleBrowser.MetadataViewModel
{
    /// <summary>
    /// Represents the node of a single relationship.
    /// </summary>
    public class RelationshipNode
        : Node
    {
        private PageContent page;
        private PackageRelationship relationship;

        /// <summary>
        /// Initializes a new instance of the <see cref="RelationshipNode"/> class.
        /// </summary>
        /// <param name="page">The page.</param>
        /// <param name="relationship">The relationship.</param>
        /// <param name="options">The options.</param>
        public RelationshipNode(PageContent page, PackageRelationship relationship, ViewModelOptions options)
            : base(options)
        {
            this.page = page;
            this.relationship = relationship;
        }

        /// <summary>
        /// Gets the text.
        /// </summary>
        /// <value>The text.</value>
        public override string Text
        {
            get { return this.relationship.TargetUri.OriginalString; }
        }

        /// <summary>
        /// Gets the icon.
        /// </summary>
        /// <value>The icon uri.</value>
        public override string Icon
        {
            get
            {
                string fileName = "link";

                ContentType contentType = this.page.Owner.ContentTypes.GetContentType(this.relationship.TargetUri);
                if (contentType != null) {
                    if (contentType.IsFontContentType()) {
                        fileName = "font";
                    }
                    else if (contentType.IsImageContentType()) {
                        fileName = "picture";
                    }
                }
                return string.Format("/SampleBrowser;component/Assets/Icons/{0}.png", fileName);
            }
        }

        /// <summary>
        /// Gets the page that is associated with this node instace.
        /// </summary>
        /// <value>The page.</value>
        public override PageContent Page
        {
            get { return this.page; }
        }
    }
}
