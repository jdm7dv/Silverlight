﻿using System;
using System.Collections.Generic;
using System.Windows.Media;

using FirstFloor.Documents;
using FirstFloor.Documents.DocumentStructures;

namespace SampleBrowser.MetadataViewModel
{
    /// <summary>
    /// Represents a block element node.
    /// </summary>
    public class BlockElementNode
        : Node
    {
        private PageContent page;
        /// <summary>
        /// Initializes a new instance of the <see cref="BlockElementNode"/> class.
        /// </summary>
        /// <param name="page">The page.</param>
        /// <param name="element">The element.</param>
        /// <param name="options">The options.</param>
        public BlockElementNode(PageContent page, BlockElement element, ViewModelOptions options)
            : base(options)
        {
            this.page = page;
            this.Element = element;
        }

        /// <summary>
        /// Gets the page that is associated with this node instace.
        /// </summary>
        /// <value>The page.</value>
        public override PageContent Page
        {
            get { return this.page; }
        }

        /// <summary>
        /// Gets the element.
        /// </summary>
        /// <value>The structure.</value>
        public BlockElement Element { get; private set; }

        /// <summary>
        /// Gets the text.
        /// </summary>
        /// <value>The text.</value>
        public override string Text
        {
            get
            {
                if (this.Element is FigureStructure) { return "Figure"; }
                else if (this.Element is ListItemStructure) { return "ListItem"; }
                else if (this.Element is ListStructure) { return "List"; }
                else if (this.Element is ParagraphStructure) { return "Paragraph"; }
                else if (this.Element is SectionStructure) { return "Section"; }
                else if (this.Element is TableCellStructure) { return "TableCell"; }
                else if (this.Element is TableRowGroupStructure) { return "TableRowGroup"; }
                else if (this.Element is TableRowStructure) { return "TableRow"; }
                else if (this.Element is TableStructure) { return "Table"; }

                NamedElement namedElement = this.Element as NamedElement;
                if (namedElement != null) {
                    return namedElement.NameReference;
                }
                
                return null;
            }
        }

        /// <summary>
        /// Gets the icon.
        /// </summary>
        /// <value>The image source.</value>
        public override string Icon
        {
            get
            {
                string name = "brick";
                if (this.Element is NamedElement) {
                    name = "brick_go";
                }
                return string.Format("/SampleBrowser;component/Assets/Icons/{0}.png", name);
            }
        }

        /// <summary>
        /// Gets the child nodes.
        /// </summary>
        /// <value>The nodes.</value>
        public override IEnumerable<Node> Children
        {
            get
            {
                SemanticBasicElement basicElement = this.Element as SemanticBasicElement;
                if (basicElement != null) {
                    foreach (BlockElement element in basicElement.BlockElements) {
                        yield return new BlockElementNode(this.page, element, this.Options);
                    }
                }
            }
        }
    }
}
