﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Media;

using FirstFloor.Documents;

namespace SampleBrowser.MetadataViewModel
{
    /// <summary>
    /// Represents a collection of properties
    /// </summary>
    public class PropertyCollectionNode
        : Node
    {
        private PackageProperties properties;
        /// <summary>
        /// Initializes a new instance of the <see cref="PropertyCollectionNode"/> class.
        /// </summary>
        /// <param name="properties">The properties.</param>
        /// <param name="options">The options.</param>
        public PropertyCollectionNode(PackageProperties properties, ViewModelOptions options)
            : base(options)
        {
            this.properties = properties;
        }

        /// <summary>
        /// Gets the text.
        /// </summary>
        /// <value>The text.</value>
        public override string Text
        {
            get { return string.Format("Properties ({0})", this.properties != null ? this.properties.Count() : 0); }
        }

        /// <summary>
        /// Gets the icon.
        /// </summary>
        /// <value>The icon uri.</value>
        public override string Icon
        {
            get { return "/SampleBrowser;component/Assets/Icons/package_green.png"; }
        }

        /// <summary>
        /// Gets the child nodes.
        /// </summary>
        /// <value>The nodes.</value>
        public override IEnumerable<Node> Children
        {
            get
            {
                if (this.properties != null && this.properties.Count() > 0) {
                    foreach (KeyValuePair<string, string> property in this.properties) {
                        yield return new PropertyNode(property, this.Options);
                    }
                }
            }
        }
    }
}
