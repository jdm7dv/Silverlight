﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Media;

using FirstFloor.Documents;

namespace SampleBrowser.MetadataViewModel
{
    /// <summary>
    /// Represents a page node.
    /// </summary>
    public class PageNode
        : Node
    {
        private PageContent page;
        /// <summary>
        /// Initializes a new instance of the <see cref="PageNode"/> class.
        /// </summary>
        /// <param name="page">The page.</param>
        /// <param name="options">The options.</param>
        public PageNode(PageContent page, ViewModelOptions options)
            : base(options)
        {
            this.page = page;
        }

        /// <summary>
        /// Gets the text.
        /// </summary>
        /// <value>The text.</value>
        public override string Text
        {
            get { return string.Format("Page {0}", this.page.PageNumber); }
        }

        /// <summary>
        /// Gets the icon.
        /// </summary>
        /// <value>The icon uri.</value>
        public override string Icon
        {
            get { return "/SampleBrowser;component/Assets/Icons/page.png"; }
        }

        /// <summary>
        /// Gets the page that is associated with this node instace.
        /// </summary>
        /// <value>The page.</value>
        public override PageContent Page
        {
            get { return this.page; }
        }

        /// <summary>
        /// Gets the child nodes.
        /// </summary>
        /// <value>The nodes.</value>
        public override IEnumerable<Node> Children
        {
            get
            {
                if ((this.Options & ViewModelOptions.IncludePageLinkTargets) > 0 && this.page.LinkTargets.Count() > 0) {
                    yield return new LinkTargetCollectionNode(this.page.LinkTargets, this.Options);
                }

                if ((this.Options & ViewModelOptions.IncludeRelationships) > 0) {
                    yield return new RelationshipsCollectionNode(this.page, this.page, this.Options);
                }

                if ((this.Options & ViewModelOptions.IncludePageStoryFragments) > 0) {
                    yield return new StoryFragmentCollectionNode(this.page, this.Options);
                }
            }
        }
    }
}
