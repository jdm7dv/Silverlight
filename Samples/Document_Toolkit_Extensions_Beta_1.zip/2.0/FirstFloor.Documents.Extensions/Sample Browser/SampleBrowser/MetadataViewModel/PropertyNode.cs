﻿using System;
using System.Collections.Generic;
using System.Windows.Media;

using FirstFloor.Documents;

namespace SampleBrowser.MetadataViewModel
{
    /// <summary>
    /// Represents a property node.
    /// </summary>
    public class PropertyNode
        : Node
    {
        private KeyValuePair<string, string> property;

        /// <summary>
        /// Initializes a new instance of the <see cref="PropertyNode"/> class.
        /// </summary>
        /// <param name="property">The property.</param>
        /// <param name="options">The options.</param>
        public PropertyNode(KeyValuePair<string, string> property, ViewModelOptions options)
            : base(options)
        {
            this.property = property;
        }

        /// <summary>
        /// Gets the text.
        /// </summary>
        /// <value>The text.</value>
        public override string Text
        {
            get { return string.Format("{0}: {1}", this.property.Key, this.property.Value); }
        }

        /// <summary>
        /// Gets the icon.
        /// </summary>
        /// <value>The icon uri.</value>
        public override string Icon
        {
            get { return "/SampleBrowser;component/Assets/Icons/bullet_green.png"; }
        }
    }
}
