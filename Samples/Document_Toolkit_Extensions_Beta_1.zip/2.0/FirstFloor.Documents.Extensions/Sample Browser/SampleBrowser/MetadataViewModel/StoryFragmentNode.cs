﻿using System;
using System.Collections.Generic;
using System.Windows.Media;

using FirstFloor.Documents;
using FirstFloor.Documents.DocumentStructures;

namespace SampleBrowser.MetadataViewModel
{
    /// <summary>
    /// Represents a story fragment node.
    /// </summary>
    public class StoryFragmentNode
        : Node
    {
        private PageContent page;

        /// <summary>
        /// Initializes a new instance of the <see cref="StoryFragmentNode"/> class.
        /// </summary>
        /// <param name="page">The page.</param>
        /// <param name="fragment">The fragment.</param>
        /// <param name="options">The options.</param>
        public StoryFragmentNode(PageContent page, StoryFragment fragment, ViewModelOptions options)
            : base(options)
        {
            this.page = page;
            this.Fragment = fragment;
        }

        /// <summary>
        /// Gets the fragment.
        /// </summary>
        /// <value>The fragment.</value>
        public StoryFragment Fragment { get; private set; }

        /// <summary>
        /// Gets the page that is associated with this node instace.
        /// </summary>
        /// <value>The page.</value>
        public override PageContent Page
        {
            get { return this.page; }
        }

        /// <summary>
        /// Gets the text.
        /// </summary>
        /// <value>The text.</value>
        public override string Text
        {
            get { return this.Fragment.FragmentType.ToString(); }
        }

        /// <summary>
        /// Gets the icon.
        /// </summary>
        /// <value>The icon uri.</value>
        public override string Icon
        {
            get { return "/SampleBrowser;component/Assets/Icons/script_code.png"; }
        }

        /// <summary>
        /// Gets the child nodes.
        /// </summary>
        /// <value>The nodes.</value>
        public override IEnumerable<Node> Children
        {
            get
            {
                foreach (BlockElement element in this.Fragment.BlockElements) {
                    yield return new BlockElementNode(this.page, element, this.Options);
                }
            }
        }
    }
}
