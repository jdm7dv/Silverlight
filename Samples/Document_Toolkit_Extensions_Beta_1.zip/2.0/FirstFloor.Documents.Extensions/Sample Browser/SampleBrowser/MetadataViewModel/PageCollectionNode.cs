﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Media;

using FirstFloor.Documents;

namespace SampleBrowser.MetadataViewModel
{
    /// <summary>
    /// Represents the page collection node.
    /// </summary>
    public class PageCollectionNode
        : Node
    {
        private FixedDocument owner;

        /// <summary>
        /// Initializes a new instance of the <see cref="PageCollectionNode"/> class.
        /// </summary>
        /// <param name="owner">The owner.</param>
        /// <param name="options">The options.</param>
        public PageCollectionNode(FixedDocument owner, ViewModelOptions options)
            : base(options)
        {
            this.owner = owner;
        }

        /// <summary>
        /// Gets the text.
        /// </summary>
        /// <value>The text.</value>
        public override string Text
        {
            get { return string.Format("Pages ({0})", this.Pages.Count()); }
        }

        /// <summary>
        /// Gets the icon.
        /// </summary>
        /// <value>The icon uri.</value>
        public override string Icon
        {
            get { return "/SampleBrowser;component/Assets/Icons/folder_page.png"; }
        }

        /// <summary>
        /// Gets a reference to the collection of pages.
        /// </summary>
        /// <value>The pages.</value>
        public IEnumerable<PageContent> Pages
        {
            get { return this.owner.Pages; }
        }

        /// <summary>
        /// Gets the page that is associated with this node instace.
        /// </summary>
        /// <value>The page.</value>
        public override PageContent Page
        {
            get
            {
                // first page;
                return this.owner.Pages.FirstOrDefault();
            }
        }

        /// <summary>
        /// Gets the child nodes.
        /// </summary>
        /// <value>The nodes.</value>
        public override IEnumerable<Node> Children
        {
            get
            {
                foreach (PageContent page in this.Pages) {
                    yield return new PageNode(page, this.Options);
                }
            }
        }
    }
}
