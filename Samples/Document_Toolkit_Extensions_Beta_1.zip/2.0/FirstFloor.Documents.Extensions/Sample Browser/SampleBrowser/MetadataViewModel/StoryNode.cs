﻿using System;
using System.Collections.Generic;
using System.Windows.Media;

using FirstFloor.Documents;
using FirstFloor.Documents.DocumentStructures;

namespace SampleBrowser.MetadataViewModel
{
    /// <summary>
    /// Represents a story node.
    /// </summary>
    public class StoryNode
        : Node
    {
        private FixedDocument owner;

        /// <summary>
        /// Initializes a new instance of the <see cref="StoryNode"/> class.
        /// </summary>
        /// <param name="owner">The owner.</param>
        /// <param name="story">The story.</param>
        /// <param name="options">The options.</param>
        public StoryNode(FixedDocument owner, Story story, ViewModelOptions options)
            : base(options)
        {
            this.owner = owner;
            this.Story = story;
        }

        /// <summary>
        /// Gets the text.
        /// </summary>
        /// <value>The text.</value>
        public override string Text
        {
            get { return this.Story.StoryName; }
        }

        /// <summary>
        /// Gets the icon.
        /// </summary>
        /// <value>The icon uri.</value>
        public override string Icon
        {
            get { return "/SampleBrowser;component/Assets/Icons/script.png"; }
        }

        /// <summary>
        /// Gets a reference to the story.
        /// </summary>
        /// <value>The story.</value>
        public Story Story { get; private set; }

        /// <summary>
        /// Gets the child nodes.
        /// </summary>
        /// <value>The nodes.</value>
        public override IEnumerable<Node> Children
        {
            get
            {
                foreach (StoryFragmentReference fragment in this.Story.Fragments) {
                    yield return new StoryFragmentReferenceNode(this.owner, fragment, this.Options);
                }
            }
        }
    }
}
