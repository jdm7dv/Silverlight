﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Collections.Generic;
using System.IO;

namespace SampleBrowser
{
/// <summary>
    /// A helper class for fonts.
    /// </summary>
    public static class Fonts
    {
        public class FontInfo
        {
            public string Name { get; set; }
            public Uri FontUri { get; set; }
            public Stream FontStream
            {
                get
                {
                    var streamInfo = Application.GetResourceStream(this.FontUri);
                    return streamInfo.Stream;
                }
            }
        }
        /// <summary>
        /// Retrieves information for all fonts available as resource in this assembly.
        /// </summary>
        /// <returns></returns>
        public static IEnumerable<FontInfo> AllFonts()
        {
            yield return new FontInfo() {
                Name = "Kootenay",
                FontUri = new Uri("/SampleBrowser;component/Assets/Fonts/kooten.ttf", UriKind.Relative)
            };
            yield return new FontInfo() {
                Name = "Lindsey",
                FontUri = new Uri("/SampleBrowser;component/Assets/Fonts/linds.ttf", UriKind.Relative)
            };
            yield return new FontInfo() {
                Name = "Miramonte",
                FontUri = new Uri("/SampleBrowser;component/Assets/Fonts/miramo.ttf", UriKind.Relative)
            };
            yield return new FontInfo() {
                Name = "Miramonte Bold",
                FontUri = new Uri("/SampleBrowser;component/Assets/Fonts/miramob.ttf", UriKind.Relative)
            };
            yield return new FontInfo() {
                Name = "Pericles",
                FontUri = new Uri("/SampleBrowser;component/Assets/Fonts/peric.ttf", UriKind.Relative)
            };
            yield return new FontInfo() {
                Name = "Pericles Light",
                FontUri = new Uri("/SampleBrowser;component/Assets/Fonts/pericl.ttf", UriKind.Relative)
            };
            yield return new FontInfo() {
                Name = "Pescadero",
                FontUri = new Uri("/SampleBrowser;component/Assets/Fonts/pesca.ttf", UriKind.Relative)
            };
            yield return new FontInfo() {
                Name = "Pescadero Bold",
                FontUri = new Uri("/SampleBrowser;component/Assets/Fonts/pescab.ttf", UriKind.Relative)
            };
        }
    }
}
