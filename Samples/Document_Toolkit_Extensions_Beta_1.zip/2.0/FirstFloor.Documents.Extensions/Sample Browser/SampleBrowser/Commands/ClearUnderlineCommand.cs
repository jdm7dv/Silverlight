﻿using System;

using FirstFloor.Documents.Annotations;
using FirstFloor.Documents.Controls.Commands;
using SampleBrowser.Annotations;

namespace SampleBrowser.Commands
{
    /// <summary>
    /// Clears all underline annotations from the current text selection
    /// </summary>
    public class ClearUnderlineCommand
        : SelectionCommand
    {
        /// <summary>
        /// Gets a value indicating whether this command requires text to be selected.
        /// </summary>
        /// <value>
        /// 	<c>true</c> if this command requires selected text; otherwise, <c>false</c>.
        /// </value>
        protected override bool RequiresSelectedText
        {
            get { return true; }
        }

        /// <summary>
        /// Implements the actual command execution.
        /// </summary>
        /// <param name="parameter">The parameter.</param>
        protected override void OnExecute(object parameter)
        {
            var service = AnnotationService.GetService(this.Selection.TextContainer);
            if (service != null && service.IsEnabled) {
                Underline.ClearUnderlinesForSelection(service);
                this.Selection.Unselect();
            }
        }
    }
}
