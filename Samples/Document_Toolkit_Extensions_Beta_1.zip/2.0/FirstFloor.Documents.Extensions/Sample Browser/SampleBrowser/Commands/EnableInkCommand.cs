﻿using System;
using System.Windows.Markup;
using System.Windows.Media;

using FirstFloor.Documents.Annotations;
using FirstFloor.Documents.Controls;
using FirstFloor.Documents.Controls.Commands;
using SampleBrowser.Annotations;
using System.Windows;

namespace SampleBrowser.Commands
{
    /// <summary>
    /// The command that enables ink editing.
    /// </summary>
    public class EnableInkCommand
        : InkCommandBase
    {
        /// <summary>
        /// Defines the method that determines whether the command can execute in its current state.
        /// </summary>
        /// <param name="parameter">Data used by the command. If the command does not require data to be passed, this object can be set to null.</param>
        /// <returns>
        /// true if this command can be executed; otherwise, false.
        /// </returns>
        public override bool CanExecute(object parameter)
        {
            return base.CanExecute(parameter) && !this.InkEditorSettings.IsEnabled;
        }

        /// <summary>
        /// Implements the actual command execution.
        /// </summary>
        /// <param name="parameter">The parameter.</param>
        protected override void OnExecute(object parameter)
        {
            this.InkEditorSettings.IsEnabled = true;
            this.InkEditorSettings.StrokeColor = Colors.Red;
        }
    }
}
