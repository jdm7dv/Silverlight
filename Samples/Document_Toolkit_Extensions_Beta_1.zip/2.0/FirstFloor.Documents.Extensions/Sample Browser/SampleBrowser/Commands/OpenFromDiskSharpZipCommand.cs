﻿using System;
using System.IO;
using FirstFloor.Documents.Controls.Commands;
using FirstFloor.Documents.IO;
using SharpZipLib;

namespace SampleBrowser.Commands
{
    /// <summary>
    /// The command that opens an XPS document from disk using the SharpZipPackageReader and assigns it to a DocumentDataSource.
    /// </summary>
    public class OpenFromDiskSharpZipCommand
        : OpenFromDiskCommand
    {
        /// <summary>
        /// Creates a package reader for given stream.
        /// </summary>
        /// <param name="stream">The stream.</param>
        /// <returns></returns>
        public override IPackageReader CreatePackageReader(Stream stream)
        {
            return new SharpZipPackageReader(stream);
        }
    }
}
