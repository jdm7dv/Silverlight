﻿using System;
using System.Collections.Generic;

namespace SampleBrowser
{
    public class GroupInfo
    {
        public string Name { get; set; }
        public IEnumerable<SampleInfo> Samples { get; set; }
    }
}
