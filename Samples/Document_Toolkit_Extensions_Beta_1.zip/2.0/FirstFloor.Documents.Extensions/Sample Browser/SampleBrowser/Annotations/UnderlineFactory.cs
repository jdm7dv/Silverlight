﻿using System;
using System.Linq;
using System.Xml.Linq;

using FirstFloor.Documents;
using FirstFloor.Documents.Annotations.Storage;
using System.Windows.Media;

namespace SampleBrowser.Annotations
{
    /// <summary>
    /// Reads and writes underline annotations.
    /// </summary>
    /// <remarks>
    /// The underline factory provides persistence to an XML based store.
    /// </remarks>
    public class UnderlineFactory
        : AnnotationFactory<Underline>
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="UnderlineFactory"/> class.
        /// </summary>
        public UnderlineFactory()
            : base(Underline.TypeUnderline)
        {
        }

        /// <summary>
        /// Creates the annotation.
        /// </summary>
        /// <returns>The annotation.</returns>
        public override Underline CreateAnnotation()
        {
            return new Underline();
        }

        /// <summary>
        /// Read an annotation from given element.
        /// </summary>
        /// <param name="element">The element.</param>
        /// <returns>The annotation.</returns>
        protected override Underline Read(XElement element)
        {
            var underline = base.Read(element);
            Color c;
            if (ParserHelper.TryParseColor((string)element.Attribute("Color"), out c)) {
                underline.Color = c;
            }

            var ranges = from range in element.Descendants(XName.Get("TextRange", AnnotationStore.NamespaceAnnotations))
                         select new TextRange(
                             new TextPointer((int)range.Attribute("StartPageNumber"), (int)range.Attribute("StartTextIndex")),
                             new TextPointer((int)range.Attribute("EndPageNumber"), (int)range.Attribute("EndTextIndex")));


            foreach (var range in ranges) {
                underline.TextRanges.Add(range);
            }

            return underline;
        }

        /// <summary>
        /// Write an annotation.
        /// </summary>
        /// <param name="annotation">The annotation.</param>
        /// <returns>
        /// The XML element representing the annotation.
        /// </returns>
        protected override XElement Write(Underline annotation)
        {
            var element = base.Write(annotation);
            element.Add(
                new XElement(XName.Get("TextRanges", AnnotationStore.NamespaceAnnotations),
                    from range in annotation.TextRanges
                    select new XElement(XName.Get("TextRange", AnnotationStore.NamespaceAnnotations),
                        new XAttribute("StartPageNumber", range.Start.PageNumber),
                        new XAttribute("StartTextIndex", range.Start.TextIndex),
                        new XAttribute("EndPageNumber", range.End.PageNumber),
                        new XAttribute("EndTextIndex", range.End.TextIndex))));

            return element;
        }
    }
}
