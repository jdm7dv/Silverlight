﻿using System;
using System.Collections.ObjectModel;
using System.Collections.Specialized;
using System.Linq;
using System.Windows.Media;
using System.Windows.Shapes;
using System.Xml.Linq;

using FirstFloor.Documents;
using FirstFloor.Documents.Annotations;
using FirstFloor.Documents.Annotations.Storage;

namespace SampleBrowser.Annotations
{
    /// <summary>
    /// Represents a text red underline annotation.
    /// </summary>
    public class Underline
        : Annotation
    {
        /// <summary>
        /// Identifies the underline annotation type.
        /// </summary>
        public static readonly XName TypeUnderline = XName.Get("Underline", AnnotationStore.NamespaceAnnotations);

        private Color color = Colors.Red;      // default underline color

        /// <summary>
        /// Initializes a new instance of the <see cref="Underline"/> class.
        /// </summary>
        public Underline()
            : base(TypeUnderline)
        {
            this.TextRanges = new ObservableCollection<TextRange>();
            this.TextRanges.CollectionChanged += OnTextRangesChanged;
        }

        private void OnTextRangesChanged(object sender, NotifyCollectionChangedEventArgs e)
        {
            OnPropertyChanged("TextRanges");
        }

        /// <summary>
        /// Gets or sets the underline color.
        /// </summary>
        /// <value>The underline color.</value>
        public Color Color
        {
            get { return this.color; }
            set
            {
                if (this.color != value) {
                    this.color = value;
                    OnPropertyChanged("Color");
                }
            }
        }

        /// <summary>
        /// Gets the text ranges of this annotation instance.
        /// </summary>
        /// <value>The text ranges.</value>
        public ObservableCollection<TextRange> TextRanges { get; private set; }

        /// <summary>
        /// Determines whether the current annotation instance includes specified page.
        /// </summary>
        /// <param name="pageNumber">The page number.</param>
        /// <returns>
        /// 	<c>true</c> if the specified page is included; otherwise, <c>false</c>.
        /// </returns>
        public override bool ContainsPage(int pageNumber)
        {
            foreach (var range in this.TextRanges) {
                if (range.ContainsPage(pageNumber)) {
                    return true;
                }
            }
            return false;
        }

        /// <summary>
        /// Renders the annotation.
        /// </summary>
        /// <param name="context">The context.</param>
        public override void RenderAnnotation(AnnotationRenderContext context)
        {
            if (context == null) {
                throw new ArgumentNullException("context");
            }

            foreach (var range in this.TextRanges) {
                foreach (var glyphs in context.Page.AllGlyphs) {
                    var rect = context.Page.Intersect(glyphs, range);
                    if (!rect.IsEmpty) {
                        var line = new Line() {
                            Stroke = new SolidColorBrush(this.Color),
                            StrokeThickness = 2,
                            X1 = rect.Left,
                            Y1 = rect.Bottom,
                            X2 = rect.Right,
                            Y2 = rect.Bottom
                        };
                        line.StrokeDashArray.Add(2);
                        line.StrokeDashArray.Add(1);

                        context.AnnotationLayer.Children.Add(line);
                    }
                }
            }
        }

        private static void ClipUnderlines(AnnotationStore store, TextRange clip)
        {
            foreach (var underline in store.OfType<Underline>().ToArray()) {
                if (underline.TextRanges.Clip(clip)) {
                    // remove entire underline when its text range collection is empty.
                    if (underline.TextRanges.IsEmpty()) {
                        store.Remove(underline);
                    }
                }
            }
        }

        /// <summary>
        /// Creates the underline annotation for the current selection of the viewer control associated with the specified <see cref="AnnotationService"/>.
        /// </summary>
        /// <param name="service">The service.</param>
        /// <param name="color">The color.</param>
        /// <returns></returns>
        public static Annotation CreateUnderlineForSelection(AnnotationService service, Color? color)
        {
            if (service == null || !service.IsEnabled){
                throw new InvalidOperationException();
            }

            if (!service.TextContainer.Selection.IsEmpty) {
                service.Store.BeginEdit();

                // make sure underlines do not overlap by clipping the existing underlines
                ClipUnderlines(service.Store, service.TextContainer.Selection);

                // create new underline
                var underline = new Underline();
                if (color.HasValue) {
                    underline.Color = color.Value;
                }
                underline.TextRanges.Add(service.TextContainer.Selection.Clone());

                service.Store.Add(underline);
                service.Store.EndEdit();

                return underline;
            }
            return null;
        }

        /// <summary>
        /// Clears all underline annotations from the current selection of the viewer control associated with the given <see cref="AnnotationService"/>.
        /// </summary>
        /// <param name="service">The service.</param>
        public static void ClearUnderlinesForSelection(AnnotationService service)
        {
            if (service == null || !service.IsEnabled) {
                throw new InvalidOperationException();
            }
            if (!service.TextContainer.Selection.IsEmpty) {
                service.Store.BeginEdit();
                ClipUnderlines(service.Store, service.TextContainer.Selection);
                service.Store.EndEdit();
            }
        }
    }
}
