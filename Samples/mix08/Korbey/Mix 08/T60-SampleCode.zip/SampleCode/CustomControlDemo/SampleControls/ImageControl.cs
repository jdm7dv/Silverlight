﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace SampleControls
{
    public class ImageControl : Control
    {
        public static readonly DependencyProperty FrameBrushProperty = DependencyProperty.Register("FrameBrush", typeof(Brush), typeof(ImageControl), null);
        public static readonly DependencyProperty SourceProperty = DependencyProperty.Register("Source", typeof(ImageSource), typeof(ImageControl), null);

        public Brush FrameBrush
        {
            get
            {
                return (Brush)GetValue(FrameBrushProperty);
            }

            set
            {
                SetValue(FrameBrushProperty, value);

            }
        }

        public ImageSource Source
        {
            get
            {
                return (ImageSource)GetValue(SourceProperty);
            }

            set
            {
                SetValue(SourceProperty, value);
            }
        }

    }
}
