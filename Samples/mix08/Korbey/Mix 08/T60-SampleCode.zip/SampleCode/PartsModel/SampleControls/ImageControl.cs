﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace SampleControls
{

    [TemplatePart(Name = "RootElement", Type = typeof(FrameworkElement))]
    [TemplatePart(Name = "FocusVisualElement", Type = typeof(FrameworkElement))]

    [TemplatePart(Name = "Normal State", Type = typeof(Storyboard))]
    [TemplatePart(Name = "MouseOver State", Type = typeof(Storyboard))]
    [TemplatePart(Name = "Pressed State", Type = typeof(Storyboard))]

    public partial class ImageControl : Control
    {

        public ImageControl()
        {
            IsTabStop = true;

            MouseEnter += new MouseEventHandler(ImageControl_MouseEnter);
            MouseLeave += new MouseEventHandler(ImageControl_MouseLeave);
            MouseLeftButtonDown += new MouseButtonEventHandler(ImageControl_MouseLeftButtonDown);
            MouseLeftButtonUp += new MouseButtonEventHandler(ImageControl_MouseLeftButtonUp);

            GotFocus += new RoutedEventHandler(ImageControl_GotFocus);
            LostFocus += new RoutedEventHandler(ImageControl_LostFocus);
        }


        protected override void OnApplyTemplate()
        {
            base.OnApplyTemplate();
            // Get Element Parts
            rootElement = (FrameworkElement)GetTemplateChild("RootElement");
            focusVisualElement = (FrameworkElement)GetTemplateChild("FocusVisualElement");

            // Get Storyboard Parts
            if (rootElement != null)
            {
                normalState = (Storyboard)rootElement.Resources["Normal State"];
                mouseOverState = (Storyboard)rootElement.Resources["MouseOver State"];
                pressedState = (Storyboard)rootElement.Resources["Pressed State"];
            }
        }


        #region Focus

        void ImageControl_GotFocus(object sender, RoutedEventArgs e)
        {
            focusVisualElement.Opacity = 1;
        }

        void ImageControl_LostFocus(object sender, RoutedEventArgs e)
        {
            focusVisualElement.Opacity = 0;
        }

        #endregion Focus

        #region GoToState

        void GoToState(Storyboard state)
        {

            if (state != null)
            {
                state.Begin();
            }


            if (currentState != null)
            {
                currentState.Stop();
            }
            currentState = state;
        }

        #endregion GoToState

        #region Initiating State Changes

        void ImageControl_MouseEnter(object sender, MouseEventArgs e)
        {
            GoToState(mouseOverState);
        }

        void ImageControl_MouseLeave(object sender, MouseEventArgs e)
        {
            GoToState(normalState);
        }


        void ImageControl_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            GoToState(pressedState);
        }

        void ImageControl_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            Focus();
            GoToState(normalState);
        }

        #endregion Initiating State Changes

        #region DPs
        public static readonly DependencyProperty SourceProperty = DependencyProperty.Register("Source", typeof(ImageSource), typeof(ImageControl), null);

        public ImageSource Source
        {
            get
            {
                return (ImageSource)GetValue(SourceProperty);
            }

            set
            {
                SetValue(SourceProperty, value);
            }
        }

        public static readonly DependencyProperty FrameBrushProperty = DependencyProperty.Register("FrameBrush", typeof(Brush), typeof(ImageControl), null);

        public Brush FrameBrush
        {
            get
            {
                return (Brush)GetValue(FrameBrushProperty);
            }

            set
            {
                SetValue(FrameBrushProperty, value);

            }
        }

        #endregion DPs

        #region privates
        private Storyboard normalState, mouseOverState, currentState, pressedState;
        private FrameworkElement rootElement, focusVisualElement;
        #endregion
    }
}
