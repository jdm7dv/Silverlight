﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace UserControlDemo
{
    public partial class AddressControl : UserControl
    {
        public AddressControl()
        {
            InitializeComponent();
        }


        private void HandleKeyDown(object sender, KeyEventArgs e)
        {
            Address address = null;
            if (e.Key == Key.K && Keyboard.Modifiers == ModifierKeys.Control)
            {
                address = new Address()
                {
                    Street1 = "1 Microsoft Way",
                    Street2 = "Building 10",
                    CityStateZip = "Redmond, WA 98052"
                };
            }
            else if (e.Key == Key.U && Keyboard.Modifiers == ModifierKeys.Control)
            {
                address = new Address()
                {
                    Street1 = "The Venetian",
                    Street2 = "3355 Las Vegas Boulevard South",
                    CityStateZip = "Las Vegas, NV 89109"
                };
            }
            if (address != null)
                this.DataContext = address;
        }

        private void HandleGotFocus(object sender, RoutedEventArgs e)
        {
            TextBox box = e.Source as TextBox;
            if (box != null)
            {
                box.Select(0, box.Text.Length);
            }
        } 
    }
}
