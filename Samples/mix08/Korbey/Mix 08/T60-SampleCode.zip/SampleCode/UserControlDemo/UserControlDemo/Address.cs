﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.ComponentModel;

namespace UserControlDemo {
    
    public class Address {
        public string Street1 { get; set; }
        public string Street2 { get; set; }
        public string CityStateZip { get; set; }

        public override string ToString() {
            return Street1 + " " + Street2 + " " + CityStateZip;
        }
    }
}
