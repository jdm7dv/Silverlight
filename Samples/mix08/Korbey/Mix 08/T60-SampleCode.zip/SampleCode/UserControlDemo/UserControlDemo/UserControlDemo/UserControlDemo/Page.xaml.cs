﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.ComponentModel;

namespace UserControlDemo
{
    public partial class Page : UserControl
    {
        public Page()
        {
            InitializeComponent();

            this.DataContext=new Address();
        }

        private void HandleKeyDown(object sender, KeyEventArgs e) {
            Address address = null;
            if (e.Key == Key.K && Keyboard.Modifiers == ModifierKeys.Control) {
                address = new Address() { 
                    Street1 = "1 Microsoft Way", 
                    Street2="Building 10/2314", 
                    CityStateZip="Redmond, WA 98052" };
            } else if (e.Key == Key.U && Keyboard.Modifiers == ModifierKeys.Control) {
                address = new Address() { 
                    Street1 = "912 148th Avenue", 
                    Street2 = "Appt. 337", 
                    CityStateZip = "Bellevue, WA 98173" };
            }
            if (address != null)
                this.DataContext = address;
        }

        private void HandleGotFocus(object sender, RoutedEventArgs e) {
            TextBox box = e.Source as TextBox;
            if (box != null) {
                box.Select(0, box.Text.Length);
            }
        }

        private void CompletePurchase(object sender, MouseButtonEventArgs e)
        {
            Address address = DataContext as Address;
            this.output.Text = address.ToString();
        }
    }
}
