﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Net;
using System.Xml;
using System.Xml.Linq;
using System.IO;
using System.ServiceModel.Syndication;


namespace MixBeCollabDemo
{
    public partial class Page : UserControl
    {
        #region Fields
        private Photo _activePhoto;
        private Photo _pendingPhoto;
        private ActionType _actionType;
        private Point _photoCenter;
        private Point _lastPosition;
        private bool _photosLoaded;
        private int _pageIndex;
        #endregion

        public Page()
        {
            // Initialize
            InitializeComponent();
            _pageIndex = 0;

            // Add Event Handlers
            MouseLeftButtonUp += new MouseButtonEventHandler(Page_MouseLeftButtonUp);
            MouseLeave += new MouseEventHandler(Page_MouseLeave);
            MouseMove += new MouseEventHandler(Page_MouseMove);

            // TODO : Add the Loaded event
            this.Loaded += new RoutedEventHandler(Page_Loaded);

            // Load the pictures
            LoadPictures();
        }

        void Page_Loaded(object sender, RoutedEventArgs e)
        {
            this.bubbels.Begin();
        }

      
       
        private void LoadPictures()
        {
            // Initialize Flickr URI
            string tags = "mixessentialsbe";
            //todo: create your own API key at Flickr and copy here:
            string key = "flickr api key here";
            string flickrApi = string.Format("http://api.flickr.com/services/rest/?method=flickr.photos.search&api_key={0}&tags={1}", key, tags);


            // Asynchronous call to REST Service
            WebClient rest = new WebClient();
            rest.DownloadStringCompleted += new DownloadStringCompletedEventHandler(rest_DownloadStringCompleted);
            rest.DownloadStringAsync(new Uri(flickrApi));           
           
        }

        void rest_DownloadStringCompleted(object sender, DownloadStringCompletedEventArgs e)
        {
            if (!_photosLoaded && (0 != Width) && (0 != Height))
            {
                string url = string.Empty;
                SurfaceLayoutRoot.Children.Clear();

                // Parse XML Returned
                XDocument doc = XDocument.Parse(e.Result);

                if (doc.Element("rsp").Attribute("stat").Value == "ok")
                {
                    // Current Page Logic
                    int totalPages = Convert.ToInt32(doc.Descendants("photos").Single().Attribute("total").Value);
                    if (_pageIndex >= totalPages)
                        _pageIndex = 0;

                    // Get Photo collection using Linq to XML
                    var photos = (from results in doc.Descendants("photo")
                                  select new
                                  {
                                      id = results.Attribute("id").Value.ToString(),
                                      farm = results.Attribute("farm").Value.ToString(),
                                      server = results.Attribute("server").Value.ToString(),
                                      secret = results.Attribute("secret").Value.ToString()
                                  }).Skip(_pageIndex * 10).Take(10);

                    // Add a photo control for each Photo returned
                    foreach (var photo in photos)
                    {
                        url = string.Format("http://farm{0}.static.flickr.com/{1}/{2}_{3}_m.jpg",
                          photo.farm, photo.server, photo.id, photo.secret);

                        new Photo(this, this.SurfaceLayoutRoot, new Uri(url));
                    }

                    _photosLoaded = true;
                }
            }
        }

        #region Individual Photo Logic
        void Page_MouseLeave(object sender, MouseEventArgs e)
        {
            OnMouseLeftButtonUpOrLeave();
        }

        void Page_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            OnMouseLeftButtonUpOrLeave();
        }

        void OnMouseLeftButtonUpOrLeave()
        {
            if (null != _activePhoto)
            {
                // Tell the previously active photo to hide its controls (in case the mouse already left it)
                var previouslyActivePhoto = _activePhoto;
                _activePhoto = null;
                previouslyActivePhoto.HideControls();
            }
            if (null != _pendingPhoto)
            {
                // Tell the pending photo (if any) to show its controls
                _pendingPhoto.ShowControls();
                _pendingPhoto = null;
            }
        }

        void Page_MouseMove(object sender, MouseEventArgs e)
        {
            if (null != _activePhoto)
            {
                // Perform the appropriate transform on the active photo
                var position = e.GetPosition(null);
                switch (_actionType)
                {
                    case ActionType.Moving:
                        // Move it by the amount of the mouse move
                        _activePhoto.Translate(position.X - _lastPosition.X, position.Y - _lastPosition.Y);
                        break;
                    case ActionType.RotatingScaling:
                        // Rotate it according to the angle the mouse moved around the photo's center
                        var radiansToDegrees = 360 / (2 * Math.PI);
                        var lastAngle = Math.Atan2(_lastPosition.Y - _photoCenter.Y, _lastPosition.X - _photoCenter.X) * radiansToDegrees;
                        var currentAngle = Math.Atan2(position.Y - _photoCenter.Y, position.X - _photoCenter.X) * radiansToDegrees;
                        _activePhoto.Rotate(currentAngle - lastAngle);

                        // Scale it according to the distance the mouse moved relative to the photo's center
                        var lastLength = Math.Sqrt(Math.Pow(_lastPosition.Y - _photoCenter.Y, 2) + Math.Pow(_lastPosition.X - _photoCenter.X, 2));
                        var currentLength = Math.Sqrt(Math.Pow(position.Y - _photoCenter.Y, 2) + Math.Pow(position.X - _photoCenter.X, 2));
                        _activePhoto.Scale(currentLength / lastLength);
                        break;
                }
                _lastPosition = position;
            }
        }

        internal void SetActivePhoto(Photo photo, ActionType actionType, Point photoCenter, Point lastPosition)
        {
            if (null == _activePhoto)
            {
                // Set the active photo and note the relevant details
                _activePhoto = photo;
                _actionType = actionType;
                _photoCenter = photoCenter;
                _lastPosition = lastPosition;

                // Bring the active photo to the top
                SurfaceLayoutRoot.Children.Remove(_activePhoto);
                SurfaceLayoutRoot.Children.Add(photo);
            }
        }

        internal Photo GetActivePhoto()
        {
            return _activePhoto;
        }

        internal void SetPendingPhoto(Photo photo)
        {
            _pendingPhoto = photo;
        }
        #endregion

        private void buttonRefresh_Click(object sender, RoutedEventArgs e)
        {
            
            // Do some initialization
            _photosLoaded = false;
            _pageIndex++;

            // Remove previous photos
            SurfaceLayoutRoot.Children.Clear();

            // Reload the pictures
            LoadPictures();
        }

       


    }

    #region Enumerators
    internal enum ActionType { Selecting, Moving, RotatingScaling };
    #endregion
}
