A sample document "Hamlet.docx" was included as an example of how text can be brough in from Silverlight's Drop Target API.  

Action:
Simply drag and drop the word doc from Windows Explorer into the text area of the running RichNotepad app, and see the text that is imported.