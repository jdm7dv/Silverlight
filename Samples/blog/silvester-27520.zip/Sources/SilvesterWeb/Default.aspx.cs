﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

namespace SilvesterWeb
{
    public partial class _Default : System.Web.UI.Page
    {
        protected void Page_Load( object sender, EventArgs e )
        {
            TwitterWebService service = new TwitterWebService();

            GridView dataView = new GridView();
            dataView.AutoGenerateColumns = true;
            dataView.DataSource = service.GetUserTimeline( "SilverlightShow", null, null );
            dataView.DataBind();

            form1.Controls.Add( dataView );
        }
    }
}
