﻿namespace SilvesterWeb.BusinessObjects
{
    using System;

    [Serializable]
    public class User
    {
        //public int Id
        //{
        //    get;
        //    set;
        //}

        public string ScreenName
        {
            get;
            set;
        }

        //public string ScreenName
        //{
        //    get;
        //    set;
        //}

        //public string Location
        //{
        //    get;
        //    set;
        //}

        //public string Description
        //{
        //    get;
        //    set;
        //}

        public string ProfileImageUrl
        {
            get;
            set;
        }

        public string Url
        {
            get;
            set;
        }

        //public bool Protected
        //{
        //    get;
        //    set;
        //}

        //public int FollowersCountr
        //{
        //    get;
        //    set;
        //}
    }
}
