﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Collections.Generic;

namespace Wishpot
{

    [TemplatePart(Name = "Star1", Type = typeof(StarControl))]
    [TemplatePart(Name = "Star2", Type = typeof(StarControl))]
    [TemplatePart(Name = "Star3", Type = typeof(StarControl))]
    [TemplatePart(Name = "Star4", Type = typeof(StarControl))]
    [TemplatePart(Name = "Star5", Type = typeof(StarControl))]


    public class RatingControl : Control
    {
        public RatingControl()
        {
            stars = new List<StarControl>(5);
            DefaultStyleKey = typeof(RatingControl);

        }

        List<StarControl> stars;


        public override void OnApplyTemplate()
        {
            base.OnApplyTemplate();

            if (stars.Count != 0)
            {
                // clear stars from previous template, removing all event handler references
                foreach (StarControl star in stars)
                {
                    star.MouseLeftButtonUp -= new MouseButtonEventHandler(star_MouseLeftButtonUp);
                    star.MouseLeftButtonDown -= new MouseButtonEventHandler(star_MouseLeftButtonDown);
                }
                stars.Clear();
            }


            // find star parts in template
            AddStarPart("Star1");
            AddStarPart("Star2");
            AddStarPart("Star3");
            AddStarPart("Star4");
            AddStarPart("Star5");

            // hook up Click & MouseEventer event handlers to each star
            foreach (StarControl star in stars)
            {
                star.MouseLeftButtonUp += new MouseButtonEventHandler(star_MouseLeftButtonUp);
                star.MouseLeftButtonDown += new MouseButtonEventHandler(star_MouseLeftButtonDown);
            }

            ShowRatingOf(Rating, false, false);


        }

        void star_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            if (IsInteractive)
            {
                var starControl = (StarControl)sender;
                ShowRatingOf(starControl.StarNumber, false, true);
            }
        }

        void star_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            if (IsInteractive)
            {
                var starControl = (StarControl)sender;

                if (starControl.StarNumber == Rating)
                {
                    ShowRatingOf(starControl.StarNumber, false, false);
                }
                else
                {
                    Rating = starControl.StarNumber;
                }
            }

        }

        protected override void OnMouseLeave(MouseEventArgs e)
        {
            base.OnMouseLeave(e);

            if (IsInteractive)
            {
                ShowRatingOf(Rating, false, false);

            }
        }

        protected override void OnMouseEnter(MouseEventArgs e)
        {
            base.OnMouseEnter(e);
            if (IsInteractive)
            {
                ShowRatingOf(Rating, true, false);
            }
        }






        void AddStarPart(string starPart)
        {

            var starControl = (StarControl)GetTemplateChild(starPart);
            if (starControl != null)
            {
                // if part exists, add to stars
                stars.Add(starControl);
            }
        }



        // RatingProperty DP
        public DependencyProperty RatingProperty = 
            DependencyProperty.Register("Rating", typeof(int), typeof(RatingControl),
            new PropertyMetadata(OnRatingChanged));

        private static void OnRatingChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            var ratingControl = (RatingControl)d;
            ratingControl.ShowRatingOf(ratingControl.Rating, false, false);

        }
        

        public int Rating
        {

            get
            {
                return (int)GetValue(RatingProperty);
            }

            set
            {
                SetValue(RatingProperty, value);

            }
        }

        // IsInteractive Property
        public bool IsInteractive { get; set; }


        internal void ShowRatingOf(int rating, bool isEmphasized, bool isUpdated)
        {
            if (stars.Count == 0) return;

            for (int i = 1; i <= stars.Count; i++)
            {
                if (i <= rating)
                {
                    stars[i - 1].IsEmphasized = isEmphasized;
                    stars[i - 1].IsUpdated = isUpdated;
                    stars[i - 1].IsStarred = true;
                }
                else
                {
                    stars[i - 1].IsEmphasized = isEmphasized;
                    stars[i - 1].IsUpdated = false;
                    stars[i - 1].IsStarred = false;
                }
            }
        }
        

    }
}
