﻿using System.ComponentModel;
using System;

namespace Wishpot
{

    public class Wish : INotifyPropertyChanged
    {

        public Wish()
        {
            // I misread documentation, and there's no rating on a wish.
            // just a product.  :)  But since I coded my demo assuming there was...
            // each wish gets a default random rating.  

            var random = new Random(DateTime.Now.Millisecond);
            Priority = random.Next(4).ToString();
        }

        public string Title
        {
            get
            {
                return title;
            }
            set
            {
                title = value;
                NotifyPropertyChanged("Title");
            }
        }

        public string Rating
        {
            get
            {
                return rating;
            }
            set
            {
                int num = Convert.ToInt32(value);
                if ((num < 1) || (num > 5))
                {
                    throw new ArgumentException("Rating must be between 1 and 5");
                }
                rating = value;
                NotifyPropertyChanged("Rating");
            }
        }

        public string Notes
        {
            get
            {
                return notes;
            }
            set
            {
                notes = value;
                NotifyPropertyChanged("Notes");
            }
        }

        public string Priority
        {
            get
            {
                return priority;
            }
            set
            {
                int pri = Convert.ToInt32(value);
                if ((pri < 1) || (pri > 5))
                    throw new ArgumentException("Priority must be between 1 and 5");
                priority = value;
                NotifyPropertyChanged("Priority");
            }
        }

        public string Price
        {
            get
            {
                return price;
            }
            set
            {
                price = value;
                NotifyPropertyChanged("ProductPictureUri");
            }
        }



        public string ProductPictureUri
        {
            get
            {
                return productPictureUri;
            }
            set
            {
                productPictureUri = value;
                NotifyPropertyChanged("ProductPictureUri");
            }
        }

        #region INotifyPropertyChanged Members

        public event PropertyChangedEventHandler PropertyChanged;

        #endregion


        #region Private Helpers

        private void NotifyPropertyChanged(String propertyName)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }

        #endregion

        #region Private Fields
        private string productPictureUri;
        private string priority;
        private string price;
        private string rating;
        private string title;
        private string notes;
        #endregion
    }

    

}