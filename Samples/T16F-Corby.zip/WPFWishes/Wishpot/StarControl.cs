﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Wishpot;

namespace Wishpot
{
    // VisualStates contract
    [TemplateVisualState(Name = "Updated", GroupName = "EmphasisStates")]
    [TemplateVisualState(Name = "Emphasized", GroupName = "EmphasisStates")]
    [TemplateVisualState(Name = "Understated", GroupName = "EmphasisStates")]

    [TemplateVisualState(Name = "Starred", GroupName = "StarStates")]
    [TemplateVisualState(Name = "Unstarred", GroupName = "StarStates")]


    public class StarControl : Control
    {
        public StarControl()
        {
            DefaultStyleKey = typeof(StarControl);
        }


        public override void OnApplyTemplate()
        {
            base.OnApplyTemplate();
            UpdateVisualState(false);

        }



        public Boolean IsStarred
        {

            get
            {
                return isStarred;
            }

            set
            {
                isStarred = value;
                UpdateVisualState(true);

            }
        }

        public Boolean IsUpdated
        {

            get
            {
                return isUpdated;
            }

            set
            {
                isUpdated = value;
                UpdateVisualState(true);

            }
        }

        public bool IsEmphasized
        {

            get
            {
                return isEmphasized;
            }

            set
            {
                isEmphasized = value;
                UpdateVisualState(true);

            }
        }

        public int StarNumber { get; set; }

        bool isStarred = false;
        bool isEmphasized = false;
        bool isUpdated = false;

        void UpdateVisualState(bool useTransitions)
        {
            if (isEmphasized)
            {
                VisualStateManager.GoToState(this, "Emphasized", useTransitions);
            }
            else if (isUpdated)
            {
                VisualStateManager.GoToState(this, "Updated", useTransitions);
            }
            else
            {
                VisualStateManager.GoToState(this, "Understated", useTransitions);
            }


            if (isStarred)
            {
                VisualStateManager.GoToState(this, "Starred", useTransitions);
            }

            else
            {
                VisualStateManager.GoToState(this, "Unstarred", useTransitions);
            }
        }


    }

}
