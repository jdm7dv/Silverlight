﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.ComponentModel;
using System.Windows.Data;

namespace Wishpot
{
    public class PriorityValueConverter : IValueConverter
    {
       #region IValueConverter Members

        public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            string intStr = (string)value;
            int pri = System.Convert.ToInt32(intStr);

            switch (pri)
            {
                case 1: return @"I neeed it!";
                case 2: return @"I really really want it";
                case 3: return @"I want it";
                case 4: return @"I wouldn't mind having it";
                case 5: return @"Thinking about it";
            }
            return @"invalid priority";
        }

        public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            throw new NotImplementedException();
        }

        #endregion
    }


}
