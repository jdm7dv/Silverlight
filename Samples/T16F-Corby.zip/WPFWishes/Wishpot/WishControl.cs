﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace Wishpot
{

    public class WishControl : Control
    {

        public WishControl()
        {
            DefaultStyleKey = typeof(WishControl);
        }

        public static DependencyProperty WishProperty = DependencyProperty.Register("Wish", typeof(Wish), typeof(WishControl), null);
        public Wish Wish
        {
            get
            {
                return (Wish)GetValue(WishProperty);
            }

            set
            {
                SetValue(WishProperty, value);
            }
        }


    }
}

