﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Wishpot;
using System.Windows.Data;

namespace WishDetailsDemo
{
    public partial class MainPage : UserControl
    {
        public MainPage()
        {
            InitializeComponent();

            var wish = new Wish();
            wish.Price = "$2,397";
            wish.Notes = "This is awesome! But it would mean I would need more lenses. :)";
            wish.Title = "Nikon D700, Prosumer Full Frame SLR";
            wish.Rating = "4";
            wish.Priority = "3";
            wish.ProductPictureUri = "images/camera.jpg";
            DataContext = wish;
        }

        private void TextBox_KeyUp(object sender, KeyEventArgs e)
        {
            BindingExpression exp = RatingTextBox.GetBindingExpression(TextBox.TextProperty);
            exp.UpdateSource();
        }


    }
}
