﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Collections;
using System.Windows.Media.Effects;

namespace Wishpot
{
    public class SplatterPanel : Panel
    {
        public SplatterPanel()
        {
            random = new Random((int)DateTime.Now.Ticks);
            MaxPriority = 5;
        }

        #region Public Properties

        //MaxPriority 
        public int MaxPriority { get; set;}

        //SplatterPanel.Priority Attached DP
        public static DependencyProperty PriorityProperty = 
            DependencyProperty.RegisterAttached("Priority", typeof(int), typeof(SplatterPanel), new PropertyMetadata(-1));

        public static int GetPriority(DependencyObject obj)
        {
            return (int)obj.GetValue(SplatterPanel.PriorityProperty);
        }

        public static void SetPriority(DependencyObject obj, int priority)
        {
            obj.SetValue(SplatterPanel.PriorityProperty, priority);

        }
        #endregion 

        #region Public Methods
        public void Resplatter()
        {

            InvalidateArrange();
        }

        #endregion

        #region Layout: Measure/Arrange
        protected override Size MeasureOverride(Size availableSize)
        {
            // All children must ALWAYS be measured.

            foreach (UIElement child in this.Children)
            {
                child.Measure(availableSize);
            }

            // Do NOT return infinity for the desired size width or height, which might happen if you
            // blindly return the availableSize. Returning an infinite dimension will cause an exception
            // to be thrown.

            Size desiredSize = new Size(
                double.IsPositiveInfinity(availableSize.Width) ? Application.Current.Host.Content.ActualWidth : availableSize.Width,
                double.IsPositiveInfinity(availableSize.Height) ? Application.Current.Host.Content.ActualHeight : availableSize.Height);

            return desiredSize;
        }


        protected override Size ArrangeOverride(Size finalSize)
        {
            var random = new Random();

            UIElement[] shuffledChildren = Shuffle(Children);
            foreach (UIElement child in shuffledChildren)
            {
                int randomX = GetRandomCoordinate(true, finalSize, child);
                int randomY = GetRandomCoordinate(false, finalSize, child);

                // Get desired size from child
                var childSize = new Size(child.DesiredSize.Width, child.DesiredSize.Height);

                // Create the rect the child should draw into
                var childRect = new Rect(new Point(randomX, randomY), childSize);

                // bad citizen: clobbering render transforms
                child.RenderTransform = new TransformGroup();
                child.RenderTransformOrigin = new Point(.5, .5);

                RandomRotate(child);

                ApplyPriority(child);

                child.Arrange(childRect);
             
            }

            return finalSize;
        }

        #endregion

        #region Helpers

        private void ApplyPriority(UIElement child)
        {

            int priority = (int) child.GetValue(SplatterPanel.PriorityProperty);

            double effectivePriority = priority <= MaxPriority ? priority : MaxPriority;
            if (effectivePriority == -1)
            {
                effectivePriority = MaxPriority;
            }

            // make it so you can never be zero by adding !
            double scale = (effectivePriority) / (MaxPriority);

            var scaleTransform = new ScaleTransform();
            scaleTransform.ScaleX = scale;
            scaleTransform.ScaleY = scale;

            ((TransformGroup)child.RenderTransform).Children.Add(scaleTransform);
            

        }

        private void RandomRotate(UIElement child)
        {

                // bad citizen: effect
                if (child.Effect == null)
                {
                    var dropShadow = new DropShadowEffect();
                    dropShadow.BlurRadius = 10;
                    dropShadow.ShadowDepth = 8;
                    dropShadow.Opacity = 0.4;
                    child.Effect = dropShadow;
                }

                RotateTransform rotate = new RotateTransform();
                rotate.Angle = random.Next(-20, 20);
                ((TransformGroup)child.RenderTransform).Children.Add(rotate);
        }

        private int GetRandomCoordinate(bool isX, Size panelSize, UIElement child)
        {
            double bound;


            if (isX)
            {
                bound = panelSize.Width - child.DesiredSize.Width - 10;
                if (bound <= 0)
                    bound = panelSize.Width;
            }
            else
            {
                bound = panelSize.Height - child.DesiredSize.Height - 10;
                if (bound <= 0)
                    bound = panelSize.Height;
            }
            return random.Next((int)bound);
        }


        private UIElement[] Shuffle(UIElementCollection children)
        {

            UIElement[] shuffledChildren = new UIElement[children.Count];
            for (int i = 0; i < children.Count; i++)
            {
                shuffledChildren[i] = children[i];
            }

            UIElement temp;
            for (int i = 0; i < children.Count; i++)
            {
                int randomIndex = random.Next(children.Count);
                temp = shuffledChildren[i];
                shuffledChildren[i] = shuffledChildren[randomIndex];
                shuffledChildren[randomIndex] = temp;
            }
            return shuffledChildren;
        }

        private Random random;
        #endregion



    }
}
