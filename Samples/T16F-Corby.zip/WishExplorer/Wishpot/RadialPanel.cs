﻿// Author:  Dave Relyea

using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using System;
using System.Windows.Media;
using System.Windows.Media.Animation;

namespace Wishpot
{
    public class RadialPanel : Panel
    {

        #region InsideDiameter

        public double InsideDiameter
        {
            get { return (double)GetValue(InsideDiameterProperty); }
            set { SetValue(InsideDiameterProperty, value); }
        }

        public static readonly DependencyProperty InsideDiameterProperty =
            DependencyProperty.Register("InsideDiameter", typeof(double), typeof(RadialPanel), new PropertyMetadata(0.0));

        #endregion

        #region IntervalAngle DP

        public double IntervalAngle
        {
            get { return (double)GetValue(IntervalAngleProperty); }
            set { SetValue(IntervalAngleProperty, value); }
        }

        // Using a DependencyProperty as the backing store for IntervalAngle.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty IntervalAngleProperty =
            DependencyProperty.Register("IntervalAngle", typeof(double), typeof(RadialPanel), new PropertyMetadata(20.0));

        #endregion

        #region OpenDuration DP
        public Duration OpenDuration
        {
            get { return (Duration)GetValue(OpenDurationProperty); }
            set { SetValue(OpenDurationProperty, value); }
        }

        public static readonly DependencyProperty OpenDurationProperty =
            DependencyProperty.Register("OpenDuration", typeof(Duration), typeof(RadialPanel), new PropertyMetadata(new Duration(TimeSpan.FromSeconds(1))));

        #endregion

        #region CloseDuration DP

        public Duration CloseDuration
        {
            get { return (Duration)GetValue(CloseDurationProperty); }
            set { SetValue(CloseDurationProperty, value); }
        }

        public static readonly DependencyProperty CloseDurationProperty =
            DependencyProperty.Register("CloseDuration", typeof(Duration), typeof(RadialPanel), new PropertyMetadata(new Duration(TimeSpan.FromSeconds(1))));

        #endregion

        #region IsOpen DP

        public bool IsOpen
        {
            get { return (bool)GetValue(IsOpenProperty); }
            set { SetValue(IsOpenProperty, value); }
        }

        public static readonly DependencyProperty IsOpenProperty =
            DependencyProperty.Register("IsOpen", typeof(bool), typeof(RadialPanel), new PropertyMetadata(false, OnIsOpenChanged));

        private static void OnIsOpenChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            ((RadialPanel)d).OnIsOpenChanged((bool) e.NewValue);
        }

        private void OnIsOpenChanged(bool newValue)
        {
            if (newValue)
                Open();
            else
                Close();
        }

        #endregion

        #region Angle

        public static double GetAngle(DependencyObject obj)
        {
            return (double)obj.GetValue(AngleProperty);
        }

        public static void SetAngle(DependencyObject obj, double value)
        {
            obj.SetValue(AngleProperty, value);
        }

        public static readonly DependencyProperty AngleProperty =
            DependencyProperty.RegisterAttached("Angle", typeof(double), typeof(RadialPanel), new PropertyMetadata(OnAngleChanged));

        private static void OnAngleChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            FrameworkElement element = (FrameworkElement)d;

            RadialPanel panel = element.Parent as RadialPanel;

            if (panel != null)
            {
                ((RadialPanel)element.Parent).AdjustForAngle(element);
                ((RadialPanel)element.Parent).InvalidateArrange();
            }
        }

        #endregion

        private void Open()
        {
            List<UIElement> children = new List<UIElement>(this.Children);
            int childCount = children.Count;

            Duration duration = OpenDuration;

            for (int childIndex = 0; childIndex < childCount; ++childIndex)
            {
                FrameworkElement child = children[childIndex] as FrameworkElement;
                RadialPanelProperties properties = GetProperties(child);

                properties.OpenAnimation.Duration = duration;
                properties.OpenStoryboard.Begin();

                properties.CloseStoryboard.Stop();
            }
        }

        private void Close()
        {
            List<UIElement> children = new List<UIElement>(this.Children);
            int childCount = children.Count;

            Duration duration = CloseDuration;

            for (int childIndex = 0; childIndex < childCount; ++childIndex)
            {
                FrameworkElement child = children[childIndex] as FrameworkElement;
                RadialPanelProperties properties = GetProperties(child);

                properties.CloseAnimation.Duration = duration;
                properties.CloseStoryboard.Begin();

                properties.OpenStoryboard.Stop();
            }
        }

        #region Properties DP

        private static RadialPanelProperties GetProperties(DependencyObject obj)
        {
            object o = obj.ReadLocalValue(PropertiesProperty);
            if (o == DependencyProperty.UnsetValue)
            {
                RadialPanelProperties properties = new RadialPanelProperties((FrameworkElement)obj);
                SetProperties(obj, properties);

                Initialize(obj as UIElement);

                return properties;
            }
            else
                return (RadialPanelProperties)o;
        }

        private static void SetProperties(DependencyObject obj, RadialPanelProperties value)
        {
            obj.SetValue(PropertiesProperty, value);
        }

        public static readonly DependencyProperty PropertiesProperty =
            DependencyProperty.RegisterAttached("Properties", typeof(RadialPanelProperties), typeof(RadialPanel), null);

        #endregion

        protected override Size MeasureOverride(Size availableSize)
        {
            double circumference = Math.PI * InsideDiameter;

            List<UIElement> children = new List<UIElement>(this.Children);

            int childCount = children.Count;

            double totalAngle = (childCount - 1) * IntervalAngle;
            double angle = -(totalAngle / 2);
            double insideDiameter = InsideDiameter;
            double maxDesiredSize = 0;

            for (int childIndex = 0; childIndex < childCount; ++childIndex)
            {
                UIElement child = children[childIndex];
                RadialPanelProperties properties = GetProperties(child);

                child.Measure(InfiniteSize);

                properties.Angle = angle;

                properties.RotateAnimation.To = angle;
                properties.RotateStoryboard.Begin();

                AdjustForAngle((FrameworkElement)child);

                angle += IntervalAngle;

                if (child.DesiredSize.Width > maxDesiredSize)
                    maxDesiredSize = child.DesiredSize.Width;
            }

            return new Size(maxDesiredSize * 2 + InsideDiameter, maxDesiredSize * 2 + InsideDiameter);
        }

        protected override Size ArrangeOverride(Size finalSize)
        {
            int childCount = this.Children.Count;

            List<UIElement> children = new List<UIElement>(this.Children);
            double centerX = finalSize.Width / 2;
            double centerY = finalSize.Height / 2;

            for (int childIndex = 0; childIndex < childCount; ++childIndex)
            {
                UIElement child = children[childIndex];
                RadialPanelProperties properties = GetProperties(child);
                child.Arrange(new Rect(centerX + properties.X, centerY + properties.Y - child.DesiredSize.Height / 2, child.DesiredSize.Width, child.DesiredSize.Height));
            }

            return finalSize;
        }

        /// <summary>
        /// This is where one-time initialization of the element is performed
        /// </summary>
        private static void Initialize(UIElement element)
        {
            RadialPanelProperties properties = GetProperties(element);

            element.RenderTransformOrigin = new Point(0, .5);

            RadialPanel.SetAngle(element, 0);
        }

        private void AdjustForAngle(FrameworkElement child)
        {
            RadialPanelProperties properties = GetProperties(child);

            bool flip = (Math.Abs(properties.Angle % 360) > 90);

            PlaneProjection planeProjection = (PlaneProjection)child.Projection;

            double offset = child.DesiredSize.Width / 2;
            double insideDiameter = InsideDiameter;

            double currentAngle = GetAngle(child);
            double radians = DegreesToRadians(currentAngle);

            properties.Rotate.Angle = currentAngle;

            properties.Translate.X = -offset;

            properties.X = insideDiameter / 2 * Math.Cos(radians);
            properties.Y = insideDiameter / 2 * Math.Sin(radians);

            if (flip)
            {
                planeProjection.RotationX = 180;
                planeProjection.RotationY = IsOpen ? 180 : 270;
                planeProjection.CenterOfRotationX = 1;
                planeProjection.GlobalOffsetX = -offset;

                properties.OpenAnimation.To = 180;
                properties.CloseAnimation.To = 270;
            }
            else
            {
                planeProjection.RotationX = 0;
                planeProjection.RotationY = IsOpen ? 0 : 90;
                planeProjection.CenterOfRotationX = 0;
                planeProjection.GlobalOffsetX = offset;

                properties.OpenAnimation.To = 0;
                properties.CloseAnimation.To = 90;
            }
        }

        private static double DegreesToRadians(double degrees)
        {
            return (degrees * Math.PI) / 180.0;
        }

        private class RadialPanelProperties
        {
            public RadialPanelProperties(FrameworkElement element)
            {
                element.Projection = Plane = new PlaneProjection();
                TransformGroup group;
                element.RenderTransform = group = new TransformGroup();
                group.Children.Add(Translate = new TranslateTransform());
                group.Children.Add(Rotate = new RotateTransform());

                OpenStoryboard = new Storyboard();
                OpenStoryboard.Children.Add(OpenAnimation = new DoubleAnimation());

                Storyboard.SetTarget(OpenAnimation, element.Projection);
                Storyboard.SetTargetProperty(OpenAnimation, new PropertyPath("(RotationY)"));

                CloseStoryboard = new Storyboard();
                CloseStoryboard.Children.Add(CloseAnimation = new DoubleAnimation());

                Storyboard.SetTarget(CloseAnimation, element.Projection);
                Storyboard.SetTargetProperty(CloseAnimation, new PropertyPath("(RotationY)"));

                RotateStoryboard = new Storyboard();
                RotateStoryboard.Children.Add(RotateAnimation = new DoubleAnimation());
                RotateAnimation.EasingFunction = new BackEase();

                Storyboard.SetTarget(RotateAnimation, element);
                Storyboard.SetTargetProperty(RotateAnimation, new PropertyPath(RadialPanel.AngleProperty));
            }

            public double Angle;
            public double X;
            public double Y;

            public Storyboard OpenStoryboard;
            public DoubleAnimation OpenAnimation;

            public Storyboard CloseStoryboard;
            public DoubleAnimation CloseAnimation;

            public Storyboard RotateStoryboard;
            public DoubleAnimation RotateAnimation;

            public PlaneProjection Plane;
            public RotateTransform Rotate;
            public TranslateTransform Translate;
        }

        private static readonly Size InfiniteSize = new Size(double.PositiveInfinity, double.PositiveInfinity);
    }
}
