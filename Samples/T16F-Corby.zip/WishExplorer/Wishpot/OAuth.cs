﻿// Synchronized with http://code.google.com/p/oauth/source/browse/code/csharp/OAuthBase.cs version 565 5/19/2008 
using System;
using System.Security.Cryptography;
using System.Collections.Generic;
using System.Text;
using System.Windows.Browser;

namespace Wishpot
{
    /// <summary>
    /// Provides a predefined set of algorithms that are supported officially by the protocol
    /// </summary>
    public enum SignatureType
    {
        /// <summary>
        /// HMAC SHA1
        /// </summary>
        HMACSHA1,
        /// <summary>
        /// Plain Text
        /// </summary>
        Plaintext,
        /// <summary>
        /// RSA SHA1
        /// </summary>
        RSASHA1
    }

    /// <summary>
    /// Provides an internal structure to sort the query parameter
    /// </summary>
    public class QueryParameter
    {
        private string name;
        private string value;

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="name"></param>
        /// <param name="value"></param>
        public QueryParameter(string name, object value)
        {
            this.name = name;
            this.value = value.ToString();
        }

        /// <summary>
        /// Query Parameter name
        /// </summary>
        public string Name
        {
            get { return name; }
        }

        /// <summary>
        /// Query Parameter value
        /// </summary>
        public string Value
        {
            get { return value; }
        }
    }

    /// <summary>
    /// Comparer class used to perform the sorting of the query parameters
    /// </summary>
    public class QueryParameterComparer : IComparer<QueryParameter>
    {

        #region IComparer<QueryParameter> Members

        /// <summary>
        /// Compare query parameter
        /// </summary>
        /// <param name="x"></param>
        /// <param name="y"></param>
        /// <returns></returns>
        public int Compare(QueryParameter x, QueryParameter y)
        {
            if (x.Name == y.Name)
            {
                return string.Compare(x.Value, y.Value, StringComparison.OrdinalIgnoreCase);
            }
            else
            {
                return string.Compare(x.Name, y.Name, StringComparison.OrdinalIgnoreCase);
            }
        }

        #endregion
    }

    /// <summary>
    /// OAuthBase for Silverlight
    /// </summary>
    public class OAuthBase
    {
        /// <summary>
        /// OAuth Version
        /// </summary>
        protected const string OAuthVersion = "1.0";
        /// <summary>
        /// OAuth paramter prefix
        /// </summary>
        protected const string OAuthParameterPrefix = "oauth_";

        //
        // List of know and used oauth parameters' names
        //        
        /// <summary>
        /// Consumer key
        /// </summary>
        protected const string OAuthConsumerKeyKey = "oauth_consumer_key";
        /// <summary>
        /// Callback key
        /// </summary>
        protected const string OAuthCallbackKey = "oauth_callback";
        /// <summary>
        /// Version key
        /// </summary>
        protected const string OAuthVersionKey = "oauth_version";
        /// <summary>
        /// signature method key
        /// </summary>
        protected const string OAuthSignatureMethodKey = "oauth_signature_method";
        /// <summary>
        /// Signature key
        /// </summary>
        protected const string OAuthSignatureKey = "oauth_signature";
        /// <summary>
        /// Timestamp key
        /// </summary>
        protected const string OAuthTimestampKey = "oauth_timestamp";
        /// <summary>
        /// Nonce key
        /// </summary>
        protected const string OAuthNonceKey = "oauth_nonce";
        /// <summary>
        /// Token Key
        /// </summary>
        protected const string OAuthTokenKey = "oauth_token";
        /// <summary>
        /// Token secret
        /// </summary>
        protected const string OAuthTokenSecretKey = "oauth_token_secret";

        /// <summary>
        /// HMAC SHA1 Signature type
        /// </summary>
        protected const string HMACSHA1SignatureType = "HMAC-SHA1";
        /// <summary>
        /// Plain text signature type
        /// </summary>
        protected const string PlaintextSignatureType = "PLAINTEXT";
        /// <summary>
        /// RSA SHA1 Signature type
        /// </summary>
        protected const string RSASHA1SignatureType = "RSA-SHA1";

        /// <summary>
        /// Random number
        /// </summary>
        private Random random = new Random();

        /// <summary>
        /// unreserved characters
        /// </summary>
        private string unreservedChars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-_.~";

        /// <summary>
        /// Helper function to compute a hash value
        /// </summary>
        /// <param name="hashAlgorithm">The hashing algoirhtm used. If that algorithm needs some initialization, like HMAC and its derivatives, they should be initialized prior to passing it to this function</param>
        /// <param name="data">The data to hash</param>
        /// <returns>a Base64 string of the hash value</returns>
        static string ComputeHash(HashAlgorithm hashAlgorithm, string data)
        {
            if (hashAlgorithm == null)
            {
                throw new ArgumentNullException("hashAlgorithm");
            }

            if (string.IsNullOrEmpty(data))
            {
                throw new ArgumentNullException("data");
            }


            byte[] dataBuffer = System.Text.Encoding.UTF8.GetBytes(data);
            byte[] hashBytes = hashAlgorithm.ComputeHash(dataBuffer);

            return Convert.ToBase64String(hashBytes);
        }

        /// <summary>
        /// Internal function to cut out all non oauth query string parameters (all parameters not begining with "oauth_")
        /// </summary>
        /// <param name="parameters">The query string part of the Url</param>
        /// <returns>A list of QueryParameter each containing the parameter name and value</returns>
        static List<QueryParameter> GetQueryParameters(string parameters)
        {
            if (parameters.StartsWith("?", StringComparison.OrdinalIgnoreCase))
            {
                parameters = parameters.Remove(0, 1);
            }

            List<QueryParameter> result = new List<QueryParameter>();

            if (!string.IsNullOrEmpty(parameters))
            {
                string[] p = parameters.Split('&');
                foreach (string s in p)
                {
                    if (!string.IsNullOrEmpty(s) && !s.StartsWith(OAuthParameterPrefix, StringComparison.OrdinalIgnoreCase))
                    {
                        if (s.IndexOf('=') > -1)
                        {
                            string[] temp = s.Split('=');
                            result.Add(new QueryParameter(temp[0], temp[1]));
                        }
                        else
                        {
                            result.Add(new QueryParameter(s, string.Empty));
                        }
                    }
                }
            }

            return result;
        }

        /// <summary>
        /// This is a different Url Encode implementation since the default .NET one outputs the percent encoding in lower case.
        /// While this is not a problem with the percent encoding spec, it is used in upper case throughout OAuth
        /// </summary>
        /// <param name="value">The value to Url encode</param>
        /// <returns>Returns a Url encoded string</returns>
        /// <remarks>This will cause an ignorable CA1055 warning in code analysis.</remarks>
        protected string UrlEncode(string value)
        {
            StringBuilder result = new StringBuilder();

            foreach (char symbol in value)
            {
                if (unreservedChars.IndexOf(symbol) != -1)
                {
                    result.Append(symbol);
                }
                else
                {
                    result.Append('%' + String.Format(System.Globalization.CultureInfo.InvariantCulture, "{0:X2}", (int)symbol));
                }
            }

            return result.ToString();
        }

        /// <summary>
        /// Normalizes the request parameters according to the spec
        /// </summary>
        /// <param name="parameters">The list of parameters already sorted</param>
        /// <returns>a string representing the normalized parameters</returns>
        protected static string NormalizeRequestParameters(IList<QueryParameter> parameters)
        {
            StringBuilder sb = new StringBuilder();
            QueryParameter p = null;
            for (int i = 0; i < parameters.Count; i++)
            {
                p = parameters[i];
                sb.AppendFormat(System.Globalization.CultureInfo.InvariantCulture, "{0}={1}", p.Name, p.Value);

                if (i < parameters.Count - 1)
                {
                    sb.Append("&");
                }
            }

            return sb.ToString();
        }

        /// <summary>
        /// Generate the signature base that is used to produce the signature
        /// </summary>
        /// <param name="url">The full url that needs to be signed including its non OAuth url parameters</param>
        /// <param name="consumerKey">The consumer key</param>        
        /// <param name="token">The token, if available. If not available pass null or an empty string</param>
        /// <param name="tokenSecret">The token secret, if available. If not available pass null or an empty string</param>
        /// <param name="httpMethod">The http method used. Must be a valid HTTP method verb (POST,GET,PUT, etc)</param>
        /// <param name="signatureType">The signature type. To use the default values use <see cref="SignatureType">OAuthBase.SignatureTypes</see>.</param>
        /// <param name="nonce">Nonce</param>
        /// <param name="timestamp">Time Stamp</param>
        /// <returns>The signature base</returns>
        public string GenerateSignatureBase(Uri url, string consumerKey, string token, string tokenSecret, string httpMethod, string timestamp, string nonce, string signatureType)
        {
            if (token == null)
            {
                token = string.Empty;
            }

            if (tokenSecret == null)
            {
                tokenSecret = string.Empty;
            }

            if (string.IsNullOrEmpty(consumerKey))
            {
                throw new ArgumentNullException("consumerKey");
            }

            if (string.IsNullOrEmpty(httpMethod))
            {
                throw new ArgumentNullException("httpMethod");
            }

            if (string.IsNullOrEmpty(signatureType))
            {
                throw new ArgumentNullException("signatureType");
            }

            List<QueryParameter> parameters = GetQueryParameters(url.Query);
            parameters.Add(new QueryParameter(OAuthVersionKey, OAuthVersion));
            parameters.Add(new QueryParameter(OAuthNonceKey, nonce));
            parameters.Add(new QueryParameter(OAuthTimestampKey, timestamp));
            parameters.Add(new QueryParameter(OAuthSignatureMethodKey, signatureType));
            parameters.Add(new QueryParameter(OAuthConsumerKeyKey, consumerKey));

            if (!string.IsNullOrEmpty(token))
            {
                parameters.Add(new QueryParameter(OAuthTokenKey, token));
            }

            parameters.Sort(new QueryParameterComparer());

            string normalizedRequestParameters = NormalizeRequestParameters(parameters);

            StringBuilder signatureBase = new StringBuilder();
            signatureBase.AppendFormat(System.Globalization.CultureInfo.InvariantCulture, "{0}&", httpMethod.ToUpper(System.Globalization.CultureInfo.InvariantCulture));
            signatureBase.AppendFormat(System.Globalization.CultureInfo.InvariantCulture, "{0}&", UrlEncode(string.Format(System.Globalization.CultureInfo.InvariantCulture, "{0}://{1}{2}", url.Scheme, url.Host, url.AbsolutePath)));
            signatureBase.AppendFormat(System.Globalization.CultureInfo.InvariantCulture, "{0}", UrlEncode(normalizedRequestParameters));

            System.Diagnostics.Debug.WriteLine(signatureBase);

            return signatureBase.ToString();
        }

        /// <summary>
        /// Generate the signature value based on the given signature base and hash algorithm
        /// </summary>
        /// <param name="signatureBase">The signature based as produced by the GenerateSignatureBase method or by any other means</param>
        /// <param name="hash">The hash algorithm used to perform the hashing. If the hashing algorithm requires initialization or a key it should be set prior to calling this method</param>
        /// <returns>A base64 string of the hash value</returns>
        public static string GenerateSignatureUsingHash(string signatureBase, HashAlgorithm hash)
        {
            return ComputeHash(hash, signatureBase);
        }

        /// <summary>
        /// Generates a signature using the HMAC-SHA1 algorithm
        /// </summary>		
        /// <param name="url">The full url that needs to be signed including its non OAuth url parameters</param>
        /// <param name="consumerKey">The consumer key</param>
        /// <param name="consumerSecret">The consumer seceret</param>
        /// <param name="token">The token, if available. If not available pass null or an empty string</param>
        /// <param name="tokenSecret">The token secret, if available. If not available pass null or an empty string</param>
        /// <param name="httpMethod">The http method used. Must be a valid HTTP method verb (POST,GET,PUT, etc)</param>
        /// <param name="nonce">Nonce</param>
        /// <param name="timestamp">Time Stamp</param>
        /// <returns>A base64 string of the hash value</returns>
        public string GenerateSignature(Uri url, string consumerKey, string consumerSecret, string token, string tokenSecret, string httpMethod, string timestamp, string nonce)
        {
            return GenerateSignature(url, consumerKey, consumerSecret, token, tokenSecret, httpMethod, timestamp, nonce, SignatureType.HMACSHA1);
        }

        /// <summary>
        /// Generates a signature using the specified signatureType 
        /// </summary>		
        /// <param name="url">The full url that needs to be signed including its non OAuth url parameters</param>
        /// <param name="consumerKey">The consumer key</param>
        /// <param name="consumerSecret">The consumer seceret</param>
        /// <param name="token">The token, if available. If not available pass null or an empty string</param>
        /// <param name="tokenSecret">The token secret, if available. If not available pass an empty string</param>
        /// <param name="httpMethod">The http method used. Must be a valid HTTP method verb (POST,GET,PUT, etc)</param>
        /// <param name="signatureType">The type of signature to use</param>
        /// <param name="nonce">Nonce</param>
        /// <param name="timestamp">UNIX time stamp</param>
        /// <returns>A base64 string of the hash value</returns>
        public string GenerateSignature(Uri url, string consumerKey, string consumerSecret, string token, string tokenSecret, string httpMethod, string timestamp, string nonce, SignatureType signatureType)
        {
            switch (signatureType)
            {
                case SignatureType.Plaintext:
                    return HttpUtility.UrlEncode(string.Format(System.Globalization.CultureInfo.InvariantCulture, "{0}&{1}", consumerSecret, tokenSecret));

                case SignatureType.HMACSHA1:
                    string signatureBase = GenerateSignatureBase(url, consumerKey, token, tokenSecret, httpMethod, timestamp, nonce, HMACSHA1SignatureType);

                    HMACSHA1 hmacsha1 = new HMACSHA1();
                    hmacsha1.Key = Encoding.UTF8.GetBytes(string.Format(System.Globalization.CultureInfo.InvariantCulture, "{0}&{1}", UrlEncode(consumerSecret), UrlEncode(tokenSecret)));

                    return GenerateSignatureUsingHash(signatureBase, hmacsha1);

                case SignatureType.RSASHA1:
                    throw new NotImplementedException();
                default:
                    throw new ArgumentException("Unknown signature type", "signatureType");
            }
        }

        /// <summary>
        /// Generate the timestamp for the signature        
        /// </summary>
        /// <returns></returns>
        public virtual string GenerateTimestamp()
        {
            // Default implementation of UNIX time of the current UTC time
            TimeSpan ts = DateTime.UtcNow - new DateTime(1970, 1, 1, 0, 0, 0, 0);
            return Math.Floor(ts.TotalSeconds).ToString(System.Globalization.CultureInfo.InvariantCulture);
        }

        /// <summary>
        /// Generate a nonce
        /// </summary>
        /// <returns></returns>
        public virtual string GenerateNonce()
        {
            // Just a simple implementation of a random number between 123400 and 9999999
            return random.Next(123400, 9999999).ToString(System.Globalization.CultureInfo.InvariantCulture);
        }

    }
}
