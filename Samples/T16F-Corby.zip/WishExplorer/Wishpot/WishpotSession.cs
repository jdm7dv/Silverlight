﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.ComponentModel;
using System.Windows.Browser;
using System.Collections.Generic;
using System.IO.IsolatedStorage;
using System.IO;
using System.Collections.ObjectModel;
using System.Xml.Serialization;

namespace Wishpot
{
    public class WishpotSession
    {
        private const bool DEBUG = true;


        // To obtain keys, go to:  http://www.wishpot.com/help/developers.aspx
        private const string developerKey = @"";
        private const string privateKey = @"";
        private const string apiHost = @"http://www.wishpot.com";
        private const string loginUri = @"https://www.wishpot.com/secure/signin.aspx";


        #region Public Methods

        public void GetRequestTokenAsync()
        {
            Uri uri = GenerateUri("/api/RequestToken.ashx", "GET", "", "");
            WebClient webClient = new WebClient();
            webClient.DownloadStringCompleted += new DownloadStringCompletedEventHandler(webClient_DownloadRequestTokenCompleted);
            webClient.DownloadStringAsync(uri);
        }

        public void GetAccessTokenAsync(string requestToken)
        {
            Uri uri = GenerateUri("/api/AccessToken.ashx", "GET", requestToken, OAuthTokenSecret);
            OAuthToken = requestToken;

            WebClient webClient = new WebClient();
            webClient.DownloadStringCompleted += new DownloadStringCompletedEventHandler(webClient_DownloadAccessTokenCompleted);
            webClient.DownloadStringAsync(uri);
        }

        #endregion


        void webClient_DownloadRequestTokenCompleted(object sender, DownloadStringCompletedEventArgs e)
        {


            if (e.Error == null)
            {

                Uri uri = null;
                string loginTokenResponse = e.Result;
                OAuthTokenSecret = GetQueryParamValue(e.Result, @"oauth_token_secret=");

                uri = new Uri(loginUri + "?" + loginTokenResponse + "&oauth_callback=" + System.Windows.Browser.HtmlPage.Document.DocumentUri);
                System.Windows.Browser.HtmlPage.Window.Navigate(uri);
            }
        }

        void webClient_DownloadAccessTokenCompleted(object sender, DownloadStringCompletedEventArgs e)
        {
            if (e.Error == null)
            {

                OAuthToken = GetQueryParamValue(e.Result, @"oauth_token=");
                OAuthTokenSecret = GetQueryParamValue(e.Result, @"oauth_token_secret=");
                UserId = GetQueryParamValue(e.Result, @"uid=");
               

                if (Authorized != null)
                    Authorized(this, null);
            }

        }

        string GetQueryParamValue(string query, string param)
        {

            var startIndex = query.IndexOf(param, StringComparison.OrdinalIgnoreCase);
            var endIndex = query.IndexOf("&",startIndex + param.Length,StringComparison.OrdinalIgnoreCase);
            string value;
            if (endIndex == -1)
            {
                value  = query.Substring(startIndex + param.Length);
            } 
            else
            {
                value = query.Substring(startIndex + param.Length, endIndex - startIndex - param.Length);
            }
            return value;

        }


        public event EventHandler<GetWishListsCompletedEventArgs> GetWishListsCompleted;

        public Collection<Wish> GetWishListsAsync(string userId)
        {
            WebClient wc = new WebClient();
            wc.OpenReadCompleted += new OpenReadCompletedEventHandler(wc_GetWishLists);
            Uri uri = GenerateUri("/restapi/User/" + userId + "/Lists", "GET", OAuthToken, OAuthTokenSecret);
            wc.OpenReadAsync(uri);
            return null;
        }

        void wc_GetWishLists(object sender, OpenReadCompletedEventArgs e)
        {
            Lists lists = null;
            if (e.Error == null)
            {

                XmlSerializer serializer = new XmlSerializer(typeof(Lists));
                lists = (Lists)serializer.Deserialize(e.Result);
            }

            
                if (GetWishListsCompleted != null) 
                {
                    GetWishListsCompleted(this, new GetWishListsCompletedEventArgs(lists, e.Error, e.Cancelled, e.UserState));
                }
        }


        public event EventHandler<GetWishesCompletedEventArgs> GetWishesCompleted;
        public void GetWishesAsync(string userId, ListsList list)
        {

            WebClient wc = new WebClient();
            wc.OpenReadCompleted += new OpenReadCompletedEventHandler(wc_GetWishes);
            Uri uri = GenerateUri("/restapi/List/" + list.Id + "/Wishes", "GET", OAuthToken, OAuthTokenSecret);
            wc.OpenReadAsync(uri);

        }




        void wc_GetWishes(object sender, OpenReadCompletedEventArgs e)
        {
            
            if (e.Error == null)
            {

                XmlSerializer serializer = new XmlSerializer(typeof(Wishes));
                Wishes wishes = (Wishes)serializer.Deserialize(e.Result);


                totalWishes = wishes.Items.Length;
                Collection<Wish> finalWishes = new Collection<Wish>();
                foreach (WishesWish wish in wishes.Items)
                {
                    WebClient wc = new WebClient();
                    wc.OpenReadCompleted += new OpenReadCompletedEventHandler(wc_GetWish);
                    Uri uri = GenerateUri("/restapi/Wish/Details/" + wish.Id, "GET", OAuthToken, OAuthTokenSecret);
                    wc.OpenReadAsync(uri, finalWishes);
                }

            }
        }

        int totalWishes;
        void wc_GetWish(object sender, OpenReadCompletedEventArgs e)
        {
            if (e.Error == null)
            {
                Collection<Wish> wishes = (Collection<Wish>)e.UserState;
                XmlSerializer serializer = new XmlSerializer(typeof(Wish));
                Wish wish = (Wish)serializer.Deserialize(e.Result);

                wishes.Add(wish);
                if (wishes.Count== totalWishes)
                {
                    if (GetWishesCompleted != null)
                        GetWishesCompleted(this, new GetWishesCompletedEventArgs(wishes, e.Error, e.Cancelled, null));

                }
            }
            else
            {


            }


        }



        Uri GenerateUri(string part, string httpMethod, string token, string secretToken)
        {
            OAuthBase oAuth = new OAuthBase();


            string nonce = oAuth.GenerateNonce();
            string timeStamp = oAuth.GenerateTimestamp();
            string signature = oAuth.GenerateSignature(new Uri(apiHost + part), developerKey, privateKey, token, secretToken, httpMethod, timeStamp, nonce);

            signature = HttpUtility.UrlEncode(signature);

            List<QueryParameter> queryParameters = new List<QueryParameter>();
            queryParameters.Add(new QueryParameter("oauth_consumer_key", developerKey));

            if (!String.Equals(token, ""))
            {
                queryParameters.Add(new QueryParameter("oauth_token", token));

            }

            queryParameters.Add(new QueryParameter("oauth_nonce", nonce));
            queryParameters.Add(new QueryParameter("oauth_timestamp", timeStamp));
            queryParameters.Add(new QueryParameter("oauth_signature_method", "HMAC-SHA1"));
            queryParameters.Add(new QueryParameter("oauth_version", "1.0"));
            queryParameters.Add(new QueryParameter("oauth_signature", signature));


            string uriString = apiHost + part + GenerateQueryParameters(queryParameters);
            return new Uri(uriString);
        }



        public event EventHandler Authorized;


        static string GenerateQueryParameters(List<QueryParameter> queryParameters)
        {
            if (queryParameters == null || queryParameters.Count == 0)
            {
                return "";
            }

            queryParameters.Sort(new QueryParameterComparer());

            bool first = true;

            string queryParameterString = "";

            foreach (var param in queryParameters)
            {
                if (first)
                {
                    queryParameterString += "?" + param.Name + "=" + param.Value;

                    first = false;
                }
                else
                {
                    queryParameterString += "&" + param.Name + "=" + param.Value;
                }
            }

            return queryParameterString;
        }

        #region Properties
        ///<summary>
        ///the OAuth token secret stored in isolated storage
        ///</summary>
        public static string OAuthTokenSecret
        {
            get
            {
                using (var store = IsolatedStorageFile.GetUserStoreForApplication())
                {
                    using (IsolatedStorageFileStream oauthFile = store.OpenFile("oauth_token_secret.txt", FileMode.Open))
                    {
                        System.IO.StreamReader reader = new StreamReader(oauthFile);

                        string oauth_token_secret = reader.ReadToEnd();

                        oauthFile.Close();

                        return oauth_token_secret;
                    }
                }
            }
            set
            {
                using (var store = IsolatedStorageFile.GetUserStoreForApplication())
                {
                    using (IsolatedStorageFileStream oauthFile = store.CreateFile("oauth_token_secret.txt"))
                    {
                        StreamWriter writer = new StreamWriter(oauthFile);

                        writer.Write(value);

                        writer.Flush();

                        oauthFile.Close();
                    }
                }

            }
        }
        /// <summary>
        /// Developer Key
        /// </summary>
        public string DeveloperKey { get; set; }
        /// <summary>
        /// Private Key
        /// </summary>
        public string PrivateKey { get; set; }

        /// <summary>
        /// OAuth Token
        /// </summary>
        public string OAuthToken { get; set; }

        /// <summary>
        /// Status
        /// </summary>
        public string Status { get; set; }

        public string UserId { get; set; }

        #endregion
    }



    public class GetWishListsCompletedEventArgs : AsyncCompletedEventArgs
    {
        public GetWishListsCompletedEventArgs(Lists lists, Exception error, bool cancelled, object userState)
            : base(error, cancelled, userState)
        {

            Lists = lists;
        }
        public Lists Lists { get; private set; }
    }


    public class GetWishesCompletedEventArgs : AsyncCompletedEventArgs
    {
        public GetWishesCompletedEventArgs(Collection<Wish> wishes, Exception error, bool cancelled, object userState)
            : base(error, cancelled, userState)
        {

            Wishes = wishes;
        }
        public Collection<Wish> Wishes { get; private set; }
    }


}
