﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Wishpot;
using System.Xml.Serialization;
using System.IO;

namespace WishExplorer
{
    public partial class WishesPage : UserControl
    {

        public WishesPage(string wishpotToken)
        {
            InitializeComponent();
            WishpotToken = wishpotToken;
            Loaded += new RoutedEventHandler(WishesPage_Loaded);
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
           WishTray.Resplatter();
        }

        void WishesPage_Loaded(object sender, RoutedEventArgs e)
        {
            if (App.UseCachedData)
            {
                LoadCachedData();
            } else{
                Loading.Opacity = 100;
                session = new WishpotSession();
                session.Authorized += new EventHandler(session_Authorized);
                session.GetAccessTokenAsync(WishpotToken);
            }
        }

        void session_Authorized(object sender, EventArgs e)
        {
            session.GetWishListsCompleted += new EventHandler<GetWishListsCompletedEventArgs>(session_GetWishListsCompleted);
            session.GetWishListsAsync(session.UserId);
        }

        void session_GetWishListsCompleted(object sender, GetWishListsCompletedEventArgs e)
        {
            if (e.Error == null)
            {
                session.GetWishesCompleted += new EventHandler<GetWishesCompletedEventArgs>(session_GetWishesCompleted);
                session.GetWishesAsync(session.UserId, e.Lists.Items[0]);
            }
        }

        void session_GetWishesCompleted(object sender, GetWishesCompletedEventArgs e)
        {
            
            wishControls = new List<WishControl>();
            foreach (Wish wish in e.Wishes)
            {
                AddWishControl(wish);
            } 
            Loading.Opacity = 0;
            RatingListBox.SelectedIndex = 0;
        }

        void LoadCachedData()
        {
            wishControls = new List<WishControl>();
            int numWishes = 9;
            for (int i = 1; i <= numWishes; i++)
            {
                
                XmlSerializer serializer = new XmlSerializer(typeof(Wish));

                var resourceInfo = Application.GetResourceStream(new Uri("WishData/wish" + i.ToString() + ".txt", UriKind.RelativeOrAbsolute));
                Wish wish = (Wish)serializer.Deserialize(resourceInfo.Stream);
                AddWishControl(wish);
            }
            RatingListBox.SelectedIndex = 0;
        }

        void AddWishControl(Wish wish)
        {
            var wishControl = new WishControl();
            wishControl.Wish = wish;
            int wishPri = Convert.ToInt32(wish.Priority);
            // reverse, since Wishpot pri is 0-4
            wishPri = Math.Abs(wishPri - 5);
            wishControl.SetValue(SplatterPanel.PriorityProperty, wishPri);
            wishControls.Add(wishControl);
        }


        string WishpotToken { get; set; }
        WishpotSession session;


        private void ListBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (wishControls == null) return;
                List<WishControl> wishesToAdd = new List<WishControl>();
                List<WishControl> wishesToRemove = new List<WishControl>();

                foreach (Object obj in e.AddedItems)
                {
                    var ratingControl = obj as RatingControl;
                    foreach (WishControl wishControl in wishControls)
                    {
                        if (Convert.ToInt32(wishControl.Wish.Rating) == ratingControl.Rating)
                        {
                            wishesToAdd.Add(wishControl);
                        }
                    }
                }

                foreach (Object obj in e.RemovedItems)
                {
                    var ratingControl = obj as RatingControl;
                    foreach (UIElement child in WishTray.Children)
                    {
                        WishControl wishControl = child as WishControl;
                        if (Convert.ToInt32(wishControl.Wish.Rating) == ratingControl.Rating)
                        {
                            wishesToRemove.Add(wishControl);
                        }
                    }
                }

                foreach (WishControl wishControl in wishesToAdd)
                {
                    WishTray.Children.Add(wishControl);
                }
                foreach (WishControl wishControl in wishesToRemove)
                {
                    WishTray.Children.Remove(wishControl);
                }

        }

        List<WishControl> wishControls;
    }
}
