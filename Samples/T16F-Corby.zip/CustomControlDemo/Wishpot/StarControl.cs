﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Wishpot;

namespace Wishpot
{

    // VisualStates contract
    [TemplateVisualState(Name = "Updated", GroupName = "EmphasisStates")]
    [TemplateVisualState(Name = "Emphasized", GroupName = "EmphasisStates")]
    [TemplateVisualState(Name = "Understated", GroupName = "EmphasisStates")]

    [TemplateVisualState(Name = "Starred", GroupName = "StarStates")]
    [TemplateVisualState(Name = "Unstarred", GroupName = "StarStates")]
    public class StarControl : Control
    {
        public StarControl()
        {
            // determines where to look for built-in style
            DefaultStyleKey = typeof(StarControl);
        }

        public override void OnApplyTemplate()
        {
            base.OnApplyTemplate();

            // initial visual state change w/o transitions
            UpdateVisualState(false);
        }


        #region Public Properties
        public Boolean IsStarred
        {

            get
            {
                return isStarred;
            }

            set
            {
                isStarred = value;
                UpdateVisualState(true);
            }
        }

        public Boolean IsUpdated
        {

            get
            {
                return isUpdated;
            }

            set
            {
                isUpdated = value;
                UpdateVisualState(true);
            }
        }

        public bool IsEmphasized
        {

            get
            {
                return isEmphasized;
            }

            set
            {
                isEmphasized = value;
                UpdateVisualState(true);
            }
        }

        public int StarNumber { get; set; }

        #endregion

        #region Helpers

        // Drives logic state of control, call GoToState to update visual state
        void UpdateVisualState(bool useTransitions)
        {
            if (isEmphasized)
            {
                VisualStateManager.GoToState(this, "Emphasized", useTransitions);
            }
            else if (isUpdated)
            {
                VisualStateManager.GoToState(this, "Updated", useTransitions);
            }
            else
            {
                VisualStateManager.GoToState(this, "Understated", useTransitions);
            }


            if (isStarred)
            {
                VisualStateManager.GoToState(this, "Starred", useTransitions);
            }

            else
            {
                VisualStateManager.GoToState(this, "Unstarred", useTransitions);
            }
        }

        #endregion

        #region Private Fields
        bool isStarred = false;
        bool isEmphasized = false;
        bool isUpdated = false;
        #endregion

    }

}
