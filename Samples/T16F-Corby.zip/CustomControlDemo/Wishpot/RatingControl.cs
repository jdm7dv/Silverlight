﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Wishpot;
using System.Collections.Generic;
using System.Collections.ObjectModel;

namespace Wishpot
{



    [TemplatePart(Name = "Star1", Type = typeof(StarControl))]
    [TemplatePart(Name = "Star2", Type = typeof(StarControl))]
    [TemplatePart(Name = "Star3", Type = typeof(StarControl))]
    [TemplatePart(Name = "Star4", Type = typeof(StarControl))]
    [TemplatePart(Name = "Star5", Type = typeof(StarControl))]

    public class RatingControl : Control
    {
        public RatingControl()
        {
            DefaultStyleKey = typeof(RatingControl);
            stars = new List<StarControl>(5);
        }


        public override void OnApplyTemplate()
        {
            base.OnApplyTemplate();

            if (stars.Count != 0)
            {
                // clear stars from previous template, removing all event handler references
                foreach (StarControl star in stars)
                {
                    star.MouseLeftButtonUp -= new MouseButtonEventHandler(star_MouseLeftButtonUp);
                    star.MouseLeftButtonDown -= new MouseButtonEventHandler(star_MouseLeftButtonDown);
                }
                stars.Clear();
            }

            // find star parts in template
            AddStarPart("Star1");
            AddStarPart("Star2");
            AddStarPart("Star3");
            AddStarPart("Star4");
            AddStarPart("Star5");

            // hook up Click & MouseEventer event handlers to each star
            foreach (StarControl star in stars)
            {
                star.MouseLeftButtonUp += new MouseButtonEventHandler(star_MouseLeftButtonUp);
                star.MouseLeftButtonDown += new MouseButtonEventHandler(star_MouseLeftButtonDown);
            }

            // update visual look by setting appropriate properties on star parts
            ShowRatingOf(Rating, false, false);
        }

        #region Public Properties

        // RatingProperty DP
        public DependencyProperty RatingProperty = DependencyProperty.Register("Rating", typeof(int), typeof(RatingControl), new PropertyMetadata(OnRatingChanged));
        public int Rating
        {

            get
            {
                return (int)GetValue(RatingProperty);
            }

            set
            {
                SetValue(RatingProperty, value);

            }
        }

        // IsInteractive Property
        public bool IsInteractive { get; set; }

        #endregion // Public Properties

        #region Star Parts Mouse EventHandlers


        void star_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            if (IsInteractive)
            {
                var starControl = (StarControl)sender;
                ShowRatingOf(starControl.StarNumber, false, true);
            }
        }

        void star_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            if (IsInteractive)
            {
                var starControl = (StarControl)sender;

                if (starControl.StarNumber == Rating)
                {
                    ShowRatingOf(starControl.StarNumber, false, false);
                }
                else
                {
                    Rating = starControl.StarNumber;
                }
            }

        }
        #endregion //Star Parts Mouse EventHandlers

        #region Input Protected Overrides
        protected override void OnMouseLeave(MouseEventArgs e)
        {
            base.OnMouseLeave(e);

            if (IsInteractive)
            {
                ShowRatingOf(Rating, false, false);

            }
        }

        protected override void OnMouseEnter(MouseEventArgs e)
        {
            base.OnMouseEnter(e);
            if (IsInteractive)
            {
                ShowRatingOf(Rating, true, false);
            }
        }

        #endregion

        #region Private Helpers
        void AddStarPart(string starPart)
        {

            var starControl = (StarControl)GetTemplateChild(starPart);
            if (starControl != null)
            {
                // if part exists, add to stars
                stars.Add(starControl);
            }
        }

        private static void OnRatingChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            var ratingControl = (RatingControl)d;
            ratingControl.ShowRatingOf(ratingControl.Rating, false, false);

        }

        internal void ShowRatingOf(int rating, bool isEmphasized, bool isUpdated)
        {
            if (stars.Count == 0) return;

            for (int i = 1; i <= stars.Count; i++)
            {
                if (i <= rating)
                {
                    stars[i - 1].IsEmphasized = isEmphasized;
                    stars[i - 1].IsUpdated = isUpdated;
                    stars[i - 1].IsStarred = true;
                }
                else
                {
                    stars[i - 1].IsEmphasized = isEmphasized;
                    stars[i - 1].IsUpdated = false;
                    stars[i - 1].IsStarred = false;
                }
            }
        }
        #endregion

        #region Private Fields
        List<StarControl> stars;
        #endregion  //Private Fields
    }
}

