﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using TreeView;
using System.ComponentModel;
using System.Collections.ObjectModel;
using System.Windows.Data;
using System.Text;

namespace TreeViewSample
{
    public partial class Page : UserControl
    {
        //RWB start
        int doubleClicks = 0;
        int keyDowns = 0;
        StringBuilder s = new StringBuilder();
        //RWB end
        
        public Page()
        {
            InitializeComponent();
        }



        private void Tree_NodeClick(object sender, TreeViewEventArgs e)
        {
            
        }

        private void Tree_Drop(object sender, TreeViewEventArgs e)
        {
            e.DropAction = TreeView.TreeView.DropActions.InsertBefore;
        }

        private void DoubleClick()
        {
            doubleClicks++;
            txtDoubleClicks.Text = "DoubleClicks: " + doubleClicks.ToString();
        }

        private void coursesTree_TreeViewNodeDoubleClick(object sender, EventArgs e)
        {
            DoubleClick();

        }

        private void coursesTree_SelectionChanged(object sender, EventArgs e)
        {
            txtSelectedItemsCount.Text = "Selected Item Count: " + coursesTree.SelectedItems.Count.ToString();
        }
    }
}
