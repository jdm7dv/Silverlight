﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace TreeView
{


    [TemplatePart(Name = "ElementBackgroundHighlight", Type = typeof(Rectangle)), 
    TemplatePart(Name = "ElementCross", Type = typeof(TextBlock)), 
    TemplatePart(Name = "ElementBackground", Type = typeof(Rectangle))]
    internal class TreeViewCheckBox : ExtendedTextControl
    {
        // Fields
        private bool? _checked = false;
        private string _text = string.Empty;

        internal const string ElementBackgroundHighlightName = "ElementBackgroundHighlight";
        internal const string ElementBackgroundName = "ElementBackground";
        internal const string ElementCrossName = "ElementCross";

        // Events
        public event RoutedEventHandler Click;

        // Methods
        public TreeViewCheckBox()
        {
            base.EnableBaseEvents = true;
            this.IsChecked = false;
            base.Width = 13.0;
            base.Height = 13.0;
        }

        public override void OnApplyTemplate()
        {
            base.OnApplyTemplate();
            this.ElementBackground = (Rectangle)base.GetTemplateChild("ElementBackground");
            this.ElementBackgroundHighlight = (Rectangle)base.GetTemplateChild("ElementBackgroundHighlight");
            this.ElementCross = (TextBlock)base.GetTemplateChild("ElementCross");
            this.UpdateVisualState();
            this.TextStyleChanged();
        }

        protected override void OnKeyDown(object sender, KeyEventArgs e)
        {
            if (this.IsFocused && (e.Key == Key.Enter))
            {
                this.OnMouseDown(this, new MouseButtonEventArgs());
            }
        }

        protected override void OnMouseDown(object sender, MouseButtonEventArgs e)
        {
            if (base.IsEnabled)
            {
                bool? isChecked = this.IsChecked;
                this.IsChecked = isChecked.HasValue ? new bool?(!isChecked.GetValueOrDefault()) : null;
                this.RaiseClicked(this, null);
                base.OnMouseDown(sender, e);
            }
        }

        protected override void OnMouseEnter(object sender, MouseEventArgs e)
        {
            this.SetHilight(true);
        }

        protected override void OnMouseLeave(object sender, MouseEventArgs e)
        {
            base.OnMouseLeave(sender, e);
            this.SetHilight(false);
        }

        protected virtual void RaiseClicked(object sender, RoutedEventArgs args)
        {
            if (this.Click != null)
            {
                this.Click(sender, args);
            }
        }

        public void SetHilight(bool highlight)
        {
            if (base.IsEnabled)
            {
                if (this.ElementBackground != null)
                {
                    this.ElementBackground.Visibility = highlight ? Visibility.Collapsed : Visibility.Visible;
                }
                if (this.ElementBackgroundHighlight != null)
                {
                    this.ElementBackgroundHighlight.Visibility = highlight ? Visibility.Visible : Visibility.Collapsed;
                }
            }
        }

        protected override void UpdateVisualState()
        {
            if (base.ElementRoot != null)
            {
                double num3;
                double actualHeight;
                double num = 0.0;
                double num2 = 18.0;
                double num5 = 0.0;
                double num6 = 0.0;
                if (this._text.Length > 0)
                {
                    base.ElementText.Text = this._text;
                    num3 = base.ElementText.ActualWidth + num2;
                    actualHeight = base.ElementText.ActualHeight;
                    if (base.ElementText.ActualHeight > 13.0)
                    {
                        num6 = (base.ElementText.ActualHeight - 13.0) * 0.5;
                    }
                    else
                    {
                        num5 = (13.0 - base.ElementText.ActualHeight) * 0.5;
                    }
                    if (actualHeight < 13.0)
                    {
                        actualHeight = 13.0;
                    }
                }
                else
                {
                    num3 = 13.0;
                    actualHeight = 13.0;
                }
                this.ElementBackground.SetValue(Canvas.LeftProperty, num);
                this.ElementBackground.SetValue(Canvas.TopProperty, num6);
                this.ElementBackgroundHighlight.SetValue(Canvas.LeftProperty, num);
                this.ElementBackgroundHighlight.SetValue(Canvas.TopProperty, num6);
                this.ElementCross.SetValue(Canvas.LeftProperty, num + 3.0);
                this.ElementCross.SetValue(Canvas.TopProperty, num6 + 1.0);
                base.ElementText.SetValue(Canvas.LeftProperty, num2);
                base.ElementText.SetValue(Canvas.TopProperty, num5);
                base.ElementText.Visibility = (this._text.Length > 0) ? Visibility.Visible : Visibility.Collapsed;
                this.ElementCross.Visibility = this._checked.Value ? Visibility.Visible : Visibility.Collapsed;
                base.Cursor = base.IsEnabled ? Cursors.Hand : Cursors.Arrow;
                base.ElementText.Opacity = base.IsEnabled ? 1.0 : 0.7;
                this.ElementCross.Opacity = base.ElementText.Opacity;
                base.Width = num3;
                base.Height = actualHeight;
            }
            base.UpdateVisualState();
        }

        // Properties
        internal Rectangle ElementBackground {get;set;}


        internal Rectangle ElementBackgroundHighlight {get;set;}


        internal TextBlock ElementCross {get;set;}


        public bool? IsChecked
        {
            get
            {
                return this._checked;
            }
            set
            {
                this._checked = value;
                this.UpdateVisualState();
            }
        }

        public string Label
        {
            get
            {
                return this._text;
            }
            set
            {
                this._text = value;
                this.UpdateVisualState();
            }
        }

        public object ToolTip
        {
            get
            {
                return ToolTipService.GetToolTip(this);
            }
            set
            {
                ToolTipService.SetToolTip(this, value);
            }
        }
    }

 

}
