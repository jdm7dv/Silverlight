﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace TreeView
{
    public delegate void TreeEventHandler(object sender, TreeViewEventArgs e);

    public class TreeViewEventArgs : EventArgs
    {
        // Fields
        private bool _cancel;
        private TreeView.DropActions _dropAction;
        private string _id;
        private TreeViewNode _source;
        private TreeViewNode _target;

        // Methods
        public TreeViewEventArgs()
        {
            this._id = string.Empty;
        }

        public TreeViewEventArgs(string id)
        {
            this.ID = id;
            this._source = null;
            this._target = null;
            this._dropAction = TreeView.DropActions.AppendAsLastChild;
        }

        // Properties
        public bool Cancel
        {
            get
            {
                return this._cancel;
            }
            set
            {
                this._cancel = value;
            }
        }

        public TreeView.DropActions DropAction
        {
            get
            {
                return this._dropAction;
            }
            set
            {
                this._dropAction = value;
            }
        }

        public string ID
        {
            get
            {
                return this._id;
            }
            set
            {
                this._id = value;
            }
        }

        public TreeViewNode Source
        {
            get
            {
                return this._source;
            }
            set
            {
                this._source = value;
            }
        }

        public TreeViewNode Target
        {
            get
            {
                return this._target;
            }
            set
            {
                this._target = value;
            }
        }

    }
}
