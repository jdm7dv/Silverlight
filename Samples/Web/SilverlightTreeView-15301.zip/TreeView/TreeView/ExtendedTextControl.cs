﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace TreeView
{


    public abstract class ExtendedTextControl : ExtendedControl
    {
        // Fields
        internal const string ElementTextName = "ElementText";

        // Methods
        protected ExtendedTextControl()
        {
        }

        protected void ApplyTextStyle(TextBlock textElement)
        {
            if (textElement != null)
            {
                textElement.FontFamily = this.FontFamily;
                textElement.FontSize = this.FontSize;
                textElement.FontWeight = this.FontWeight;
                textElement.FontStyle = this.FontStyle;
                textElement.Foreground = this.Foreground;
            }
        }

        public override void OnApplyTemplate()
        {
            base.OnApplyTemplate();
            this.ElementText = (TextBlock)base.GetTemplateChild("ElementText");
        }

        protected virtual void TextStyleChanged()
        {
            this.ApplyTextStyle(this.ElementText);
        }

        // Properties
        internal TextBlock ElementText {get;set;}


        public new FontFamily FontFamily
        {
            get
            {
                return base.FontFamily;
            }
            set
            {
                base.FontFamily = value;
                this.TextStyleChanged();
            }
        }

        public new double FontSize
        {
            get
            {
                return base.FontSize;
            }
            set
            {
                base.FontSize = value;
                this.TextStyleChanged();
            }
        }

        public new FontStyle FontStyle
        {
            get
            {
                return base.FontStyle;
            }
            set
            {
                base.FontStyle = value;
                this.TextStyleChanged();
            }
        }

        public new FontWeight FontWeight
        {
            get
            {
                return base.FontWeight;
            }
            set
            {
                base.FontWeight = value;
                this.TextStyleChanged();
            }
        }

        public new Brush Foreground
        {
            get
            {
                return base.Foreground;
            }
            set
            {
                base.Foreground = value;
                this.TextStyleChanged();
            }
        }
    }

 

}
