﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace TreeView
{
    [TemplatePart(Name = "ElementBackground", Type = typeof(Rectangle)), 
    TemplatePart(Name = "ElementPlus", Type = typeof(UIElement)), 
    TemplatePart(Name = "ElementMinus", Type = typeof(UIElement))]
    public class TreeViewExpander : ExtendedControl
    {
        // Fields
        private bool _expanded;
        private bool _doubleSignLogic = false;

        internal const string ElementBackgroundName = "ElementBackground";
        internal const string ElementMinusName = "ElementMinus";
        internal const string ElementMinusAltName = "ElementMinusAlt";
        internal const string ElementPlusName = "ElementPlus";
        internal const string ElementPlusAltName = "ElementPlusAlt";

        // Events
        public event EventHandler Click;

        // Methods
        public TreeViewExpander()
        {
            base.EnableBaseEvents = true;
            base.Width = 11.0;
            base.Height = 11.0;
        }

        public override void OnApplyTemplate()
        {
            base.OnApplyTemplate();
            this.ElementBackground = (Rectangle)base.GetTemplateChild("ElementBackground");
            this.ElementPlus = (UIElement)base.GetTemplateChild("ElementPlus");
            this.ElementMinus = (UIElement)base.GetTemplateChild("ElementMinus");
            this.UpdateVisualState();
        }

        protected override void OnMouseDown(object sender, MouseButtonEventArgs args)
        {
            this.Expanded = !this.Expanded;
            this.RaiseClick(this, null);
        }

        private void RaiseClick(object sender, EventArgs args)
        {
            if (this.Click != null)
            {
                this.Click(sender, args);
            }
        }

        protected override void UpdateVisualState()
        {
            if (base.ElementRoot != null)
            {
                this.ElementPlus.Visibility = this._expanded ? Visibility.Collapsed : Visibility.Visible;

                if (!_doubleSignLogic)
                    this.ElementMinus.Visibility = this._expanded ? Visibility.Visible : Visibility.Collapsed;
            }
            base.UpdateVisualState();
        }

        // Properties
        internal Rectangle ElementBackground {get;set;}


        internal UIElement ElementMinus { get; set; }

        internal UIElement ElementPlus { get; set; }



        public bool Expanded
        {
            get
            {
                return this._expanded;
            }
            set
            {
                this._expanded = value;
                this.UpdateVisualState();
            }
        }

        public bool DoubleSignLogic
        {
            get
            {
                return this._doubleSignLogic;
            }
            set
            {
                this._doubleSignLogic = value;
                this.UpdateVisualState();
            }
        }
    }

 

}
