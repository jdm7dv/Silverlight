﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace CustomerService
{
    [ServiceContract]
    public interface IService1
    {
        [OperationContract]
        int CountUsers();

    }

    //[DataContract]
    //public class User
    //{
    //    [DataMember]
    //    public bool IsMember { get; set; }

    //    [DataMember]
    //    public string Name { get; set; }

    //    [DataMember]
    //    public int Age { get; set; }
    //}

}

