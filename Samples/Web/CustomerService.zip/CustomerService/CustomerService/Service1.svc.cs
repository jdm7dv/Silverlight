﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using System.Collections;


namespace CustomerService
{
    public class Service1 : IService1
    //public class Service1
    {
        public int CountUsers()
        {
            DataSet1TableAdapters.addressesTableAdapter addressAdapter = new CustomerService.DataSet1TableAdapters.addressesTableAdapter();
            DataSet1.addressesDataTable addresses = addressAdapter.GetData();
            ArrayList addressList = new ArrayList();
            foreach (DataSet1.addressesRow addressRow in addresses)
            {
                addressList.Add(addressRow.Name + " - " + addressRow.Phone);
            }
            int rows = addressList.Count;
            return rows;
        }

    }
}