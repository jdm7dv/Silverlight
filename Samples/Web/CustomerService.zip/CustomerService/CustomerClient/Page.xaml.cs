﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.ServiceModel;
using System.ServiceModel.Channels;
    

namespace CustomerClient
{
    public partial class Page : UserControl
    {
        public Page()
        {
            InitializeComponent();
            Binding binding = new BasicHttpBinding();
            EndpointAddress address = new EndpointAddress("http://localhost:54580/service1.svc");
            ServiceReference.Service1Client proxy = new ServiceReference.Service1Client(binding, address);  
            proxy.CountUsersCompleted += new EventHandler<CustomerClient.ServiceReference.CountUsersCompletedEventArgs>(proxy_CountUsersCompleted);
            proxy.CountUsersAsync();
        }

        void proxy_CountUsersCompleted(object sender, CustomerClient.ServiceReference.CountUsersCompletedEventArgs e)
        {
            userCountResult.Text = "Number of users: " + e.Result;
        }

        
    }
}
