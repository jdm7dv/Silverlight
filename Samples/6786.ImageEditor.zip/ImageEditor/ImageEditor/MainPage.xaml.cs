﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.IO;
using System.Windows.Printing;
using C1.Silverlight;
using C1.Silverlight.Imaging;
using C1.Silverlight.Toolbar;
using ImageEditor.Dialogs;

namespace ImageEditor
{
    public partial class MainPage : UserControl
    {
        C1Bitmap bitmap = new C1Bitmap();
        C1Bitmap bitmap2 = new C1Bitmap(); //temp bitmap
        List<C1Bitmap> undoBitmaps = new List<C1Bitmap>();
        List<C1Bitmap> redoBitmaps = new List<C1Bitmap>();
        Rect cropBox;
        ResizeImage dlgResize;
        bool warping;
        bool cropping;
        Line warpLine;
        PrintDocument printDocument = new PrintDocument();

        public MainPage()
        {
            InitializeComponent();
            UpdateImage(true);
            warping = false;
            cropping = false;   
            var mouseHelper = new C1MouseHelper(image);
            mouseHelper.MouseDragStart += OnDragStart;
            mouseHelper.MouseDragMove += OnDragMove;
            mouseHelper.MouseDragEnd += OnDragEnd;
            printDocument.PrintPage += new EventHandler<PrintPageEventArgs>(printDocument_PrintPage);
            btnUndo.IsEnabled = false;
            btnRedo.IsEnabled = false;
            cropCanvas.Visibility = System.Windows.Visibility.Collapsed;
        }   

        private void UpdateImage(bool updateHistory)
        {
            image.Source = bitmap.ImageSource;
            imageGrid.Width = bitmap.Width;
            imageGrid.Height = bitmap.Height;
            if(updateHistory)
                UpdateHistory();
        }

        #region "Save Image"

        private void btnSave_Click(object sender, RoutedEventArgs e)
        {
            ExportImage();
        }

        private void ExportImage()
        {
            var dialog = new SaveFileDialog
            {
                DefaultExt = ".png",
                Filter = "PNG | *.png | JPG | *.jpg | GIF | *.gif"
            };
            var save = dialog.ShowDialog();
            if (save.HasValue && save.Value)
            {
                var saveStream = dialog.OpenFile();
                var readStream = bitmap.GetStream(ImageFormat.Png, true);
                var data = new byte[readStream.Length];
                readStream.Read(data, 0, (int)readStream.Length);
                saveStream.Write(data, 0, data.Length);
                saveStream.Close();
            }
        }
        #endregion

        #region "Open Image"

        private void btnOpen_Click(object sender, RoutedEventArgs e)
        {
            LoadImage();
        }

        private void LoadImage()
        {
            var dialog = new OpenFileDialog
            {
                Filter = "Image files (png, jpeg or gif)|*.png;*.jpg;*.gif;*.jpeg|All files|*.*"
            };

            dialog.ShowDialog();
            if (dialog.File != null)
            {
                using (var fileStream = dialog.File.OpenRead())
                {
                    try
                    {
                        LoadImageStream(fileStream);
                    }
                    catch (Exception ex)
                    {
                        C1MessageBox.Show("Image format not supported, error: \n" + ex.Message, "", C1MessageBoxIcon.Error);
                    }
                }
            }
        }

        void LoadImageStream(Stream stream)
        {
            bitmap.SetStream(stream);

            imageGrid.Width = bitmap.Width;
            imageGrid.Height = bitmap.Height;

            InitCropHandles();
            //UpdateMask();
            ClearHistory();
            UpdateImage(true);
            
        }
        #endregion

        #region "Print"

        private void btnPrint_Click(object sender, RoutedEventArgs e)
        {
            printDocument.Print("My Image");
        }

        void printDocument_PrintPage(object sender, PrintPageEventArgs e)
        {
            e.PageVisual = imageGrid;
            e.HasMorePages = false;

        }

        #endregion

        #region "Undo/Redo"
        private void btnUndo_Click(object sender, RoutedEventArgs e)
        {
            if (undoBitmaps.Count > 1)
            {
                bitmap = new C1Bitmap(undoBitmaps.ElementAt(undoBitmaps.Count - 2));
                redoBitmaps.Add(new C1Bitmap(undoBitmaps.ElementAt(undoBitmaps.Count - 1)));
                undoBitmaps.RemoveAt(undoBitmaps.Count - 1);
                UpdateImage(false);
            }
            UpdateEditButtons();
       
        }

        private void btnRedo_Click(object sender, RoutedEventArgs e)
        {
            if (redoBitmaps.Count > 0)
            {
                bitmap = new C1Bitmap(redoBitmaps.ElementAt(redoBitmaps.Count - 1));
                undoBitmaps.Add(new C1Bitmap(redoBitmaps.ElementAt(redoBitmaps.Count - 1)));
                redoBitmaps.RemoveAt(redoBitmaps.Count - 1);
                UpdateImage(false);
            }
            UpdateEditButtons();
        }
        
        void UpdateHistory()
        {
            //Add current bitmap to memory
            undoBitmaps.Add(new C1Bitmap(bitmap));
            redoBitmaps.Clear();
            
            //Restrict application to only hold up to 3 instances or changes made to C1Bitmap for undo/redo history
            if (undoBitmaps.Count > 4)
                undoBitmaps.RemoveAt(0);

            UpdateEditButtons();
        }

        private bool CanUndo()
        {
            if (undoBitmaps.Count > 1)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        private bool CanRedo()
        {
            if (redoBitmaps.Count > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        private void ClearHistory()
        {
            undoBitmaps.Clear();
            redoBitmaps.Clear();
        }

        private void UpdateEditButtons()
        {
            btnUndo.IsEnabled = CanUndo();
            btnRedo.IsEnabled = CanRedo();
        }
        #endregion

        #region "Cropping"


        private void btnCrop_Click(object sender, RoutedEventArgs e)
        {
            btnWarp.IsChecked = false;
            warping = false;
            
            if ((bool)btnCrop.IsChecked)
            {
                cropCanvas.Visibility = System.Windows.Visibility.Visible;
            }
            else
            {
                if (cropping)
                {
                    CropImage();
                    cropping = false;
                }
                cropCanvas.Visibility = System.Windows.Visibility.Collapsed;
            }
        }

        private void InitCropHandles()
        {
            if (bitmap != null)
            {
                cropBox = new Rect(0, 0, bitmap.Width, bitmap.Height);
                
                UpdateCropBox();
            }
            
        }


        

        private void UpdateCropBox()
        {
            if (cropBox.Width == 0)
            {
                cropBox.Width = 1;

            }

            if (cropBox.Height == 0)
            {
                cropBox.Height = 1;

            }
                

            Canvas.SetLeft(cropUL, cropBox.Left);
            Canvas.SetTop(cropUL, cropBox.Top);


            Canvas.SetLeft(cropUR, cropBox.Left + cropBox.Width);
            Canvas.SetTop(cropUR, cropBox.Top);

            Canvas.SetLeft(cropBL, cropBox.Left);
            Canvas.SetTop(cropBL, cropBox.Top + cropBox.Height);

            Canvas.SetLeft(cropBR, cropBox.Left + cropBox.Width);
            Canvas.SetTop(cropBR, cropBox.Top + cropBox.Height);

            UpdateMask();
            cropping = true;
        }

        void UpdateMask()
        {
            topMask.Height = cropBox.Top;
            topMask.Width = cropBox.Left + cropBox.Width;

            leftMask.Height = bitmap.Height - cropBox.Top;
            leftMask.Width = cropBox.Left;
            Canvas.SetTop(leftMask, cropBox.Top);

            rightMask.Height = cropBox.Height + cropBox.Top;
            rightMask.Width = bitmap.Width - cropBox.Left - cropBox.Width;
            Canvas.SetLeft(rightMask, cropBox.Left + cropBox.Width);

            bottomMask.Height = bitmap.Height - cropBox.Height - cropBox.Top;
            bottomMask.Width = bitmap.Width - cropBox.Left;
            Canvas.SetTop(bottomMask, cropBox.Height + cropBox.Top);
            Canvas.SetLeft(bottomMask, cropBox.Left);
        }
        
        private void cropUL_DragDelta(object sender, System.Windows.Controls.Primitives.DragDeltaEventArgs e)
        {

            
            double left = Canvas.GetLeft(cropUL) + e.HorizontalChange;
            double top = Canvas.GetTop(cropUL) + e.VerticalChange;

            if (left > 0 && left < bitmap.Width && cropBox.Width > e.HorizontalChange)
            {
                cropBox = new Rect(left, cropBox.Top, cropBox.Width - e.HorizontalChange, cropBox.Height);
            }
            if (top > 0 && top < bitmap.Height && cropBox.Height > e.VerticalChange)
            {
                cropBox = new Rect(cropBox.Left, top, cropBox.Width, cropBox.Height - e.VerticalChange);
            }

            UpdateCropBox();


            
        }

        private void cropUR_DragDelta(object sender, System.Windows.Controls.Primitives.DragDeltaEventArgs e)
        {
            
            
            double left = Canvas.GetLeft(cropUR) + e.HorizontalChange;
            double top = Canvas.GetTop(cropUR) + e.VerticalChange;
            
            if (left > 0 && left < bitmap.Width && left > cropBox.Left)
            {
                cropBox = new Rect(cropBox.Left, cropBox.Top, left - cropBox.Left, cropBox.Height);
            }
            if (top > 0 && top < bitmap.Height && cropBox.Height > e.VerticalChange)
            {
                cropBox = new Rect(cropBox.Left, top, cropBox.Width, cropBox.Height - e.VerticalChange);
            }

            UpdateCropBox();
        }

        private void cropBL_DragDelta(object sender, System.Windows.Controls.Primitives.DragDeltaEventArgs e)
        {
            
            double left = Canvas.GetLeft(cropBL) + e.HorizontalChange;
            double top = Canvas.GetTop(cropBL) + e.VerticalChange;
            
            if (left > 0 && left < bitmap.Width && cropBox.Width > e.HorizontalChange)
            {
                cropBox = new Rect(left, cropBox.Top, cropBox.Width - e.HorizontalChange, cropBox.Height);
            }
            if (top > 0 && top < bitmap.Height && top > cropBox.Top)
            {
                cropBox = new Rect(cropBox.Left, cropBox.Top, cropBox.Width, top - cropBox.Top);
            }

            UpdateCropBox();
        }

        private void cropBR_DragDelta(object sender, System.Windows.Controls.Primitives.DragDeltaEventArgs e)
        {
            

            double left = Canvas.GetLeft(cropBR) + e.HorizontalChange;
            double top = Canvas.GetTop(cropBR) + e.VerticalChange;
            
            if (left > 0 && left < bitmap.Width && left > cropBox.Left)
            {
                cropBox = new Rect(cropBox.Left, cropBox.Top, left - cropBox.Left, cropBox.Height);
            }
            if (top > 0 && top < bitmap.Height && cropBox.Height + e.VerticalChange > 0)
            {
                cropBox = new Rect(cropBox.Left, cropBox.Top, cropBox.Width, cropBox.Height + e.VerticalChange);
            }

            UpdateCropBox();
        }

        private void CropImage()
        {
            bitmap2 = new C1Bitmap((int)cropBox.Width, (int)cropBox.Height);
            bitmap2.BeginUpdate();
            for (int x = 0; x < cropBox.Width; ++x)
            {
                for (int y = 0; y < cropBox.Height; ++y)
                {
                    bitmap2.SetPixel(x, y, bitmap.GetPixel(x + (int)cropBox.X, y + (int)cropBox.Y));
                }
            }
            bitmap2.EndUpdate();
            bitmap.Copy(bitmap2, false);   
            UpdateImage(true);
            InitCropHandles();
        }

        

        #endregion

        #region "Resize Image"

        private void btnResize_Click(object sender, RoutedEventArgs e)
        {
            dlgResize = new ResizeImage(bitmap.Width, bitmap.Height);
            dlgResize.Show();
            dlgResize.OKButton.Click += new RoutedEventHandler(OnResizeButton_Click);
        }

        void OnResizeButton_Click(object sender, RoutedEventArgs e)
        {
            ResizeImage(dlgResize.ImageWidth, dlgResize.ImageHeight);
        }
        
        void ResizeImage(int w, int h)
        {
            bitmap = new C1Bitmap(bitmap, w, h);
            UpdateImage(true);
        }



        #endregion
   
        #region "Warp"
        
        private void btnWarp_Click(object sender, RoutedEventArgs e)
        {
            warping = (bool)btnWarp.IsChecked;
            cropping = false;
        }

        void OnDragStart(object sender, MouseDragEventArgs e)
        {
            if (warping)
            {
                var pos = e.GetPosition(image);
                warpLine = new Line
                {
                    X1 = pos.X,
                    Y1 = pos.Y,
                    X2 = pos.X,
                    Y2 = pos.Y,
                    Stroke = new SolidColorBrush(Colors.Blue),
                    StrokeThickness = 7,
                    StrokeEndLineCap = PenLineCap.Triangle,
                    StrokeStartLineCap = PenLineCap.Round
                };
                imageGrid.Children.Add(warpLine);
            }
        }

        void OnDragMove(object sender, MouseDragEventArgs e)
        {
            if (warping)
            {
                var pos = e.GetPosition(image);
                warpLine.X2 = pos.X;
                warpLine.Y2 = pos.Y;
            }
        }

        void OnDragEnd(object sender, MouseDragEventArgs e)
        {
            if (warping)
            {
                imageGrid.Children.Remove(warpLine);
                var transform = Application.Current.RootVisual.TransformToVisual(image);
                var start = transform.Transform(e.StartPosition);
                var end = transform.Transform(new Point(e.StartPosition.X + e.TotalDeltaX, e.StartPosition.Y + e.TotalDeltaY));

                bitmap2 = new C1Bitmap(bitmap);
                Warp(bitmap2, bitmap, start, end);
                UpdateImage(true);
            }
        }

        void Warp(C1Bitmap src, C1Bitmap dst, Point start, Point end)
        {
            dst.BeginUpdate();
            dst.Copy(src, false);

            var dist = Distance(start, end);
            var affectedDist = dist * 1.5;
            var affectedDistSquared = affectedDist * affectedDist;
            for (int row = 0; row < dst.Height; ++row)
            {
                for (int col = 0; col < dst.Width; ++col)
                {
                    var point = new Point(col, row);
                    if (DistanceSq(start, point) > affectedDistSquared)
                    {
                        continue;
                    }
                    if (DistanceSq(end, point) < 0.25)
                    {
                        dst.SetPixel(col, row, src.GetPixel((int)start.X, (int)start.Y));
                        continue;
                    }
                    var dir = new Point(point.X - end.X, point.Y - end.Y);
                    var t = IntersectRayCircle(end, dir, start, affectedDist);
                    TryT(-end.X / dir.X, ref t);
                    TryT(-end.Y / dir.Y, ref t);
                    TryT((dst.Width - end.X) / dir.X, ref t);
                    TryT((dst.Height - end.X) / dir.X, ref t);
                    var anchor = new Point(end.X + (point.X - end.X) * t, end.Y + (point.Y - end.Y));
                    var x = start.X + (anchor.X - start.X) / t;
                    var y = start.Y + (anchor.Y - start.Y) / t;
                    dst.SetPixel(col, row, src.GetInterpolatedPixel(x, y));
                }
            }
            dst.EndUpdate();
        }

        static double Distance(Point a, Point b)
        {
            return Math.Sqrt(DistanceSq(a, b));
        }

        static double DistanceSq(Point a, Point b)
        {
            var dx = a.X - b.X;
            var dy = a.Y - b.Y;
            return dx * dx + dy * dy;
        }

        static void TryT(double t2, ref double t)
        {
            if (t2 > 0 && t2 < t)
            {
                t = t2;
            }
        }

        static double IntersectRayCircle(Point rayOri, Point rayDir, Point center, double radius)
        {
            var a = rayDir.X;
            var b = rayOri.X;
            var c = center.X;
            var d = rayDir.Y;
            var e = rayOri.Y;
            var f = center.Y;
            var g = radius * radius;

            var num1 = Math.Sqrt(d * (2 * a * (b - c) * (e - f) - d * (b * b - 2 * b * c + c * c - g)) - a * a * (e * e - 2 * e * f + f * f - g));
            var num2 = a * (c - b) + d * (f - e);
            return (num1 + num2 > 0 ? num1 + num2 : num1 - num2) / (a * a + d * d);
        }

        #endregion

        #region "Drag/Drop"
        private bool IsImageFile(string extension)
        {

            return (extension.Equals(".png", StringComparison.InvariantCultureIgnoreCase)
                || extension.Equals(".jpg", StringComparison.InvariantCultureIgnoreCase)
                || extension.Equals(".jpeg", StringComparison.InvariantCultureIgnoreCase));
        }

        private void DropTarget_Drop(object sender, DragEventArgs e)
        {
            // Get FileInfo array from DragEventArgs
            IDataObject dataObject = e.Data;
            var files = (FileInfo[])dataObject.GetData(DataFormats.FileDrop);

            // Iterate through all files
            foreach (FileInfo file in files)
            {
                if (IsImageFile(file.Extension))
                {
                    Stream stream = file.OpenRead();
                    try
                    {
                        LoadImageStream(stream);
                    }
                    catch (Exception ex)
                    {
                        C1MessageBox.Show("Image format not supported, error: \n" + ex.Message, "", C1MessageBoxIcon.Error);
                    }
                }
            }
        }
        #endregion    

    }
}
