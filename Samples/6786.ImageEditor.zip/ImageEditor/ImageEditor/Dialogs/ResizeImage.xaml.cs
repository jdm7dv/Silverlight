﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace ImageEditor.Dialogs
{
    public partial class ResizeImage : ChildWindow
    {
        private int _imageWidth;
        private int _imageHeight;

        public int ImageWidth
        {

            get { return _imageWidth; }

            set { _imageWidth = value;
            textWidth.Value = value;

            }

        }

        public int ImageHeight
        {

            get { return _imageHeight; }

            set { _imageHeight = value;
            textHeight.Value = value;
            }

        } 

        public ResizeImage(int w, int h)
        {
            InitializeComponent();
            ImageWidth = w;
            ImageHeight = h;
        }

        private void OKButton_Click(object sender, RoutedEventArgs e)
        {
            _imageWidth = (int)textWidth.Value;
            _imageHeight = (int)textHeight.Value;
            this.DialogResult = true;
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            this.DialogResult = false;
        }
    }
}

