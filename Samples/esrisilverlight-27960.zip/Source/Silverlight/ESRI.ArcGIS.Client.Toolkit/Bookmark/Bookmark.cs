﻿// (c) Copyright ESRI.
// This source is subject to the Microsoft Public License (Ms-PL).
// Please see http://go.microsoft.com/fwlink/?LinkID=131993 for details.
// All other rights reserved.

using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Collections.Generic;
using System.ComponentModel;
#if !SILVERLIGHT
using Microsoft.Windows.Controls;
#endif

namespace ESRI.ArcGIS.Client.Toolkit
{
	/// <summary>
	/// Bookmark control
	/// </summary>
	[TemplatePart(Name = "AddBookmark", Type = typeof(Button))]
	[TemplatePart(Name = "ClearBookmarks", Type = typeof(Button))]
	[TemplatePart(Name = "BookmarkList", Type = typeof(DataGrid))]
	[TemplatePart(Name = "AddBookmarkName", Type = typeof(TextBox))]
	public class Bookmark : Control
	{
		/// <summary>
		/// Bookmark class for storing named extents
		/// </summary>
		public class MapBookmark
		{
			/// <summary>
			/// Gets or sets the name.
			/// </summary>
			/// <value>The name.</value>
			public string Name { get; set; }
			/// <summary>
			/// Gets or sets the extent.
			/// </summary>
			/// <value>The extent.</value>
			public ESRI.ArcGIS.Client.Geometry.Envelope Extent { get; set; }
			/// <summary>
			/// Returns a <see cref="T:System.String"/> that represents the current <see cref="T:System.Object"/>.
			/// </summary>
			/// <returns>
			/// A <see cref="T:System.String"/> that represents the current <see cref="T:System.Object"/>.
			/// </returns>
			public override string ToString()
			{
				return Name;
			}
		}

		private const string isolatedStorageKey = "ESRI.ArcGIS.Client.Toolkit.BookMarks";
		private string Key
		{
			get { return isolatedStorageKey + "_" + this.Name; }
		}

		/// <summary>
		/// Gets or sets the collection of <see cref="MapBookmark">map bookmarks</see>.
		/// </summary>
		/// <value>The bookmarks.</value>
		public System.Collections.ObjectModel.ObservableCollection<MapBookmark> Bookmarks { get; private set; }

		/// <summary>
		/// Initializes a new instance of the <see cref="Bookmark"/> class.
		/// </summary>
		public Bookmark()
		{
			DefaultStyleKey = typeof(Bookmark);
			Bookmarks = new System.Collections.ObjectModel.ObservableCollection<MapBookmark>();
#if SILVERLIGHT
			UseIsolatedStorage = true;		
			this.Loaded += new RoutedEventHandler(Bookmark_Loaded);
#endif
		}

#if SILVERLIGHT
		private void Bookmark_Loaded(object sender, RoutedEventArgs e)
		{
			LoadBookmarks();
		}

		private void SaveBookmarks()
		{
			if (DesignerProperties.GetIsInDesignMode(this))
				return;

			try
			{
				if (System.IO.IsolatedStorage.IsolatedStorageSettings.ApplicationSettings.Contains(Key))
					System.IO.IsolatedStorage.IsolatedStorageSettings.ApplicationSettings.Remove(Key);

				if (UseIsolatedStorage && Bookmarks != null && Bookmarks.Count > 0)
				{
					System.IO.IsolatedStorage.IsolatedStorageSettings.ApplicationSettings.Add(Key, Bookmarks);
				}
				System.IO.IsolatedStorage.IsolatedStorageSettings.ApplicationSettings.Save();
			}
			catch (System.Exception ex)
			{
				System.Diagnostics.Debug.WriteLine("Failed to save bookmarks: " + ex.Message);
			}
		}

		private void LoadBookmarks()
		{
			if (UseIsolatedStorage && !DesignerProperties.GetIsInDesignMode(this))
			{
				if (System.IO.IsolatedStorage.IsolatedStorageSettings.ApplicationSettings.Contains(Key))
				{
					System.Collections.ObjectModel.ObservableCollection<MapBookmark> storedMarks = 
						System.IO.IsolatedStorage.IsolatedStorageSettings.ApplicationSettings[Key] as System.Collections.ObjectModel.ObservableCollection<MapBookmark>;
					if (storedMarks != null)
						foreach (MapBookmark marks in storedMarks)
							Bookmarks.Add(marks);
				}
			}
		}
#endif

		TextBox AddBookmarkName;
		Button AddBookmarkButton;
		DataGrid BookmarkList;
		/// <summary>
		/// When overridden in a derived class, is invoked whenever application code
		/// or internal processes (such as a rebuilding layout pass) call 
		/// <see cref="M:System.Windows.Controls.Control.ApplyTemplate"/>.
		/// </summary>
		public override void OnApplyTemplate()
		{
			base.OnApplyTemplate();
			AddBookmarkName = GetTemplateChild("AddBookmarkName") as TextBox;
			AddBookmarkButton = GetTemplateChild("AddBookmark") as Button;
			BookmarkList = GetTemplateChild("BookmarkList") as DataGrid;
			
			if(AddBookmarkButton!=null)
				AddBookmarkButton.Click += AddBookmarkButton_Click;
			if (BookmarkList != null)
			{
				BookmarkList.ItemsSource = Bookmarks;
				BookmarkList.SelectionChanged += BookmarkList_SelectionChanged;
			}
			Button ClearBookmarksButton = GetTemplateChild("ClearBookmarks") as Button;
			if (ClearBookmarksButton != null)
			{
				ClearBookmarksButton.Click += (o, e) => { ClearBookmarks(); };
			}
		}

		private void BookmarkList_SelectionChanged(object sender, SelectionChangedEventArgs e)
		{
			MapBookmark bookmark = BookmarkList.SelectedItem as MapBookmark;
			if (bookmark!=null && Map != null && !Double.IsNaN(Map.Resolution))
			{
				Map.ZoomTo(bookmark.Extent);
			}
		}

		private void AddBookmarkButton_Click(object sender, RoutedEventArgs e)
		{
			if (Map == null) return;

			string name = null;
			if (AddBookmarkName != null)
				name = AddBookmarkName.Text;
			AddBookmark(name, Map.Extent);
		}

		/// <summary>
		/// Identifies the <see cref="Map"/> dependency property.
		/// </summary>
		public static readonly DependencyProperty MapProperty = DependencyProperty.Register("Map", typeof(Map), typeof(Bookmark), new PropertyMetadata(OnMapPropertyChanged));

		private static void OnMapPropertyChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
		{
			(d as Bookmark).Map = e.NewValue as Map;
		}

		/// <summary>
		/// Gets or sets the map that the <see cref="Bookmark"/> is buddied to.
		/// </summary>
		public Map Map
		{
			get
			{
				return GetValue(MapProperty) as Map;
			}
			set
			{
				if (value != Map)
				{
					if (Map != null)
						Map.ExtentChanged -= map_ExtentChanged;
					SetValue(MapProperty, value);
					if(value!=null)
						value.ExtentChanged += map_ExtentChanged;
				}
			}
		}

		private void map_ExtentChanged(object sender, ExtentEventArgs args)
		{
			if (BookmarkList != null)
				BookmarkList.SelectedIndex = -1;
		}

		/// <summary>
		/// Adds a bookmark.
		/// </summary>
		/// <param name="name">Display name.</param>
		/// <param name="extent">The extent.</param>
		public void AddBookmark(string name, ESRI.ArcGIS.Client.Geometry.Envelope extent)
		{
			name = name.Trim();
			if (string.IsNullOrEmpty(name))
			{
				name = "Bookmark " + (Bookmarks.Count + 1);
			}
			MapBookmark bookmark = new MapBookmark()
			{
				Name = name,
				Extent = extent
			};
			Bookmarks.Add(bookmark);
			if (BookmarkList != null && BookmarkList.Columns.Count>0)
				BookmarkList.ScrollIntoView(bookmark, BookmarkList.Columns[0]);
#if SILVERLIGHT
			SaveBookmarks();
#endif
		}
		/// <summary>
		/// Deletes the bookmark at the specified index.
		/// </summary>
		/// <param name="index">The index.</param>
		public void DeleteBookmarkAt(int index)
		{
			Bookmarks.RemoveAt(index);
#if SILVERLIGHT
			SaveBookmarks();
#endif
		}
		/// <summary>
		/// Clears the bookmarks.
		/// </summary>
		public void ClearBookmarks()
		{
			Bookmarks.Clear();
#if SILVERLIGHT
			SaveBookmarks();
#endif
		}

#if SILVERLIGHT

		/// <summary>
		/// Gets or sets a value indicating whether to store the booksmarks in the isolated storage.
		/// </summary>
		/// <value><c>true</c> if bookmarks will be stored between sessions.</value>
		public bool UseIsolatedStorage { get; set; }
#endif

		/// <summary>
		/// Gets or sets the title.
		/// </summary>
		/// <value>The title.</value>
		public string Title
		{
			get
			{
				return GetValue(TitleProperty) as string;
			}
			set
			{
				SetValue(TitleProperty, value);
			}
		}

		/// <summary>
		/// Identifies the <see cref="Title"/> dependency property.
		/// </summary>
		public static readonly DependencyProperty TitleProperty = DependencyProperty.Register("Title", typeof(string), typeof(Bookmark), null);

	}
}
