﻿// (c) Copyright ESRI.
// This source is subject to the Microsoft Public License (Ms-PL).
// Please see http://go.microsoft.com/fwlink/?LinkID=131993 for details.
// All other rights reserved.

using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using ESRI.ArcGIS.Client.Geometry;

namespace ESRI.ArcGIS.Client.Toolkit
{
	/// <summary>
	/// Map Magnifying glass
	/// </summary>
	public partial class Magnifier : UserControl
	{
		FrameworkElement rootElement;
		ESRI.ArcGIS.Client.Map map;
		bool isActive;
		/// <summary>
		/// Initializes a new instance of the <see cref="Magnifier"/> class.
		/// </summary>
		public Magnifier()
		{
			InitializeComponent();
			Layers = new ESRI.ArcGIS.Client.LayerCollection();
			ZoomFactor = 2;
			this.Cursor = Cursors.None;
			this.Visibility = Visibility.Collapsed;
			this.MouseLeftButtonUp += new MouseButtonEventHandler(Magnifier_MouseLeftButtonUp);
		}

		void Magnifier_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			this.Enabled = false;
		}
		/// <summary>
		/// Initializes using the specified map.
		/// </summary>
		/// <param name="map">The map.</param>
		public void Initialize(ESRI.ArcGIS.Client.Map map)
		{
			if (this.map != null)
			{
				return;
			}
			this.map = map;
			this.rootElement = map.Parent as FrameworkElement;
			foreach (ESRI.ArcGIS.Client.Layer layer in this.Layers)
			{
				bigMap.Layers.Add(layer);
			}
			this.rootElement.MouseMove += new MouseEventHandler(dragGlass);
			//this.Visibility = Visibility.Collapsed;
		}

		private void map_ExtentChanged(object sender, ESRI.ArcGIS.Client.ExtentEventArgs args)
		{
			Envelope e = args.NewExtent;
			updateExtent(e);
		}

		private void updateExtent(Envelope parentMapExtent)
		{
			bigMap.ZoomTo(parentMapExtent);
		}

		private void dragGlass(object sender, MouseEventArgs e)
		{
			double x = e.GetPosition(this.map).X;
            double y = e.GetPosition(this.map).Y;
			this.SetValue(Canvas.LeftProperty, x - 85.0);
			this.SetValue(Canvas.TopProperty, y - 85.0);

			bigMap.SetValue(Canvas.LeftProperty, -x * ZoomFactor + 110);
			bigMap.SetValue(Canvas.TopProperty, -y * ZoomFactor + 110);
		}

		/// <summary>
		/// Gets or sets a value indicating whether this <see cref="Magnifier"/> is enabled.
		/// </summary>
		/// <value><c>true</c> if enabled; otherwise, <c>false</c>.</value>
		public bool Enabled
		{
			get { return isActive; }
			set
			{
				if (value)
					StartDrag();
				else
				{
					StopDrag();
				}
			}
		}
		private void StopDrag()
		{
			isActive = false;
			this.Visibility = Visibility.Collapsed;
		}
        
#if !SILVERLIGHT
        delegate void updateExtentDelegate(Envelope env);
#endif

        private void StartDrag()
		{
			isActive = true;
			this.Visibility = Visibility.Visible;
			bigMap.Width = (map.Parent as FrameworkElement).ActualWidth * ZoomFactor;
			bigMap.Height = (map.Parent as FrameworkElement).ActualHeight * ZoomFactor;
			magGlass.Opacity = 1;
			bigScene.Opacity = 1;
#if SILVERLIGHT
			Dispatcher.BeginInvoke(() => { updateExtent(map.Extent); });
#else
            Dispatcher.BeginInvoke(new updateExtentDelegate(updateExtent), map.Extent);
#endif
		}
		
		/// <summary>
		/// Identifies the <see cref="Layers"/> dependency property.
		/// </summary>
		public static readonly DependencyProperty LayersProperty = DependencyProperty.RegisterAttached("Layers", typeof(ESRI.ArcGIS.Client.LayerCollection), typeof(Magnifier), null);
		/// <summary>
		/// Gets or sets the layers.
		/// </summary>
		public ESRI.ArcGIS.Client.LayerCollection Layers
		{
			get { return (ESRI.ArcGIS.Client.LayerCollection)GetValue(LayersProperty); }
			set { SetValue(LayersProperty, value); }
		}

		/// <summary>
		/// Gets or sets the zoom factor.
		/// </summary>
		public double ZoomFactor { get; set; }
	}
}
