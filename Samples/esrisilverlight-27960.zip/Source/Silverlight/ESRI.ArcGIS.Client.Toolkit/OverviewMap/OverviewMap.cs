﻿// (c) Copyright ESRI.
// This source is subject to the Microsoft Public License (Ms-PL).
// Please see http://go.microsoft.com/fwlink/?LinkID=131993 for details.
// All other rights reserved.

using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using ESRI.ArcGIS.Client.Geometry;

namespace ESRI.ArcGIS.Client.Toolkit
{
	/// <summary>
	/// OverviewMap Control
	/// </summary>
	[TemplatePart(Name = "OVMapImage", Type = typeof(Map))]
	[TemplatePart(Name = "AOI", Type = typeof(Grid))]
	[System.Windows.Markup.ContentProperty("Layer")]
	public partial class OverviewMap : Control
	{
		#region Private fields

		#region Template items
		Map OVMapImage;
		Grid AOI;
		#endregion

		private Envelope mapExtent;
		private Envelope fullExtent;
		private Envelope lastMapExtent = new Envelope();
		private Envelope lastOVExtent;
		private Point startPoint;
		double offsetLeft = 0;
		double offsetTop = 0;
		private bool dragOn = false;
		private double maxWidth = 0;
		private double maxHeight = 0;

		#endregion

		/// <summary>
		/// Initializes a new instance of the <see cref="OverviewMap"/> class.
		/// </summary>
		public OverviewMap()
		{
			DefaultStyleKey = typeof(OverviewMap);
		}

		/// <summary>
		/// When overridden in a derived class, is invoked whenever application code 
		/// or internal processes (such as a rebuilding layout pass) call
		/// <see cref="M:System.Windows.Controls.Control.ApplyTemplate"/>.
		/// </summary>
		public override void OnApplyTemplate()
		{
			base.OnApplyTemplate();
			OVMapImage = GetTemplateChild("OVMapImage") as Map;
			if (OVMapImage == null)
			{
				throw new ArgumentNullException("Template child 'OVMapImage' not found");
			}
			OVMapImage.Width = Width;
			OVMapImage.Height = Height;
			OVMapImage.ExtentChanged += (s,e) => { UpdateAOI(); };
			if (this.Layer != null)
				this.OVMapImage.Layers.Add(this.Layer);

			AOI = GetTemplateChild("AOI") as Grid;

			if (AOI != null)
				AOI.MouseLeftButtonDown += AOI_MouseLeftButtonDown;

			UpdateAOI();
		}

		#region Properties

		/// <summary>
		/// Identifies the <see cref="Map"/> dependency property.
		/// </summary>
		public static readonly DependencyProperty MapProperty = DependencyProperty.Register("Map", typeof(Map), typeof(OverviewMap), new PropertyMetadata(OnMapPropertyChanged));

		private static void OnMapPropertyChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
		{
			OverviewMap ovmap = d as OverviewMap;
			Map oldMap = e.OldValue as Map;
			if (oldMap != null) //clean up
			{
				if (ovmap.OVMapImage != null)
					ovmap.OVMapImage.Layers.Clear();
				oldMap.ExtentChanged -= ovmap.UpdateOVMap;
			}
			Map newMap = e.NewValue as Map;
			if (newMap != null)
			{
				newMap.ExtentChanged += ovmap.UpdateOVMap;
				if (ovmap.Layer != null && ovmap.OVMapImage != null)
					ovmap.OVMapImage.Layers.Add(ovmap.Layer);
			}
		}

		/// <summary>
		/// Sets or gets the Map control associated with the OverviewMap.
		/// </summary>
		public Map Map
		{
			get { return (Map)GetValue(MapProperty); }
			set { SetValue(MapProperty, value); }
		}

		/// <summary>
		/// Identifies the <see cref="MaximumExtent"/> dependency property.
		/// </summary>
		public static readonly DependencyProperty MaximumExtentProperty = DependencyProperty.Register("MaximumExtent", typeof(Envelope), typeof(OverviewMap), null);

		/// <summary>
		/// Gets or sets  the maximum map extent of the overview map. 
		/// If undefined, the maximum extent is derived from the layer.
		/// </summary>
		/// <value>The maximum extent.</value>
		public Envelope MaximumExtent
		{
			get { return (Envelope)GetValue(MaximumExtentProperty); }
			set { SetValue(MaximumExtentProperty, value); }
		}

		/// <summary>
		/// Identifies the <see cref="Layer"/> dependency property.
		/// </summary>
		public static readonly DependencyProperty LayerProperty = DependencyProperty.Register("Layer", typeof(Layer), typeof(OverviewMap), new PropertyMetadata(OnLayerPropertyChanged));

		private static void OnLayerPropertyChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
		{
			OverviewMap ovmap = d as OverviewMap;
			if (ovmap.OVMapImage != null)
			{
				ovmap.OVMapImage.Layers.Clear();
				if (ovmap.Layer != null)
					ovmap.OVMapImage.Layers.Add(ovmap.Layer);
			}
			if (ovmap.Layer != null)
			{
				bool isInit = ovmap.Layer.IsInitialized;
				if (isInit)
					ovmap.Layer_LayersInitialized(ovmap.Layer, null);
				else
					ovmap.Layer.Initialized += ovmap.Layer_LayersInitialized;
			}
		}

		/// <summary>
		/// Gets or sets the layer used in the overview map.
		/// </summary>
		/// <value>The layer.</value>
		public Layer Layer
		{
			get { return (Layer)GetValue(LayerProperty); }
			set { SetValue(LayerProperty, value); }
		}

		#endregion

		/// <summary>
		/// Provides the behavior for the "Arrange" pass of Silverlight layout.
		/// Classes can override this method to define their own arrange pass behavior.
		/// </summary>
		/// <param name="finalSize">The final area within the parent that this
		/// object should use to arrange itself and its children.</param>
		/// <returns>The actual size used.</returns>
		protected override Size ArrangeOverride(Size finalSize)
		{
			this.Clip = new RectangleGeometry() { Rect = new Rect(0, 0, ActualWidth, ActualHeight) };
			return base.ArrangeOverride(finalSize);
		}

		#region Private Methods

		/// <summary>
		/// Sets extents, limits, and events after layers have been initialized
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="args"></param>
		private void Layer_LayersInitialized(object sender, EventArgs args)
		{
			fullExtent = OVMapImage.Layers.GetFullExtent();
			if (MaximumExtent != null)
				fullExtent = MaximumExtent.Clone();
			maxWidth = fullExtent.Width;
			maxHeight = fullExtent.Height;
			OVMapImage.MinimumResolution = double.Epsilon;
			OVMapImage.MaximumResolution = double.MaxValue;
			OVMapImage.ZoomTo(fullExtent);
			UpdateOVMap();
		}

		#region Methods for setting extent of OverviewMap

		/// <summary>
		/// Determines if the OverviewMap extent should be changed. If so, set new 
		/// extent and call ZoomTo or PanTo. If not, send to UpdateAOI
		/// </summary>
		private void UpdateOVMap()
		{
			if (Map == null || OVMapImage == null || OVMapImage.Extent == null || Map.Extent == null)
			{
				if(AOI!=null)
					AOI.Visibility = Visibility.Collapsed;
				return;
			}
			// update ov extent if necessary
			double mapWidth = Map.Extent.Width;
			double mapHeight = Map.Extent.Height;
			double ovWidth = OVMapImage.Extent.Width;
			double ovHeight = OVMapImage.Extent.Height;
			double widthRatio = mapWidth / ovWidth;
			double heightRatio = mapHeight / ovHeight;
			double minRatio = 0.15;
			double maxRatio = 0.8;
			Envelope extent;
			bool sameWidthHeight = (mapWidth == lastMapExtent.Width && mapHeight == lastMapExtent.Height);
			if (sameWidthHeight)
			{
				double halfWidth = ovWidth / 2;
				double halfHeight = ovHeight / 2;
				MapPoint newCenter = Map.Extent.GetCenter();
				if (MaximumExtent != null)
				{
					if (newCenter.X - halfWidth < MaximumExtent.XMin) newCenter.X = MaximumExtent.XMin + halfWidth;
					if (newCenter.X + halfWidth > MaximumExtent.XMax) newCenter.X = MaximumExtent.XMax - halfWidth;
					if (newCenter.Y - halfHeight < MaximumExtent.YMin) newCenter.Y = MaximumExtent.YMin + halfHeight;
					if (newCenter.Y + halfHeight > MaximumExtent.YMax) newCenter.Y = MaximumExtent.YMax - halfHeight;
				}
				if (ovWidth >= maxWidth)
					UpdateAOI();
				else
				{
					if (AOI != null) 
						AOI.Visibility = Visibility.Collapsed;
					OVMapImage.PanTo(newCenter);
				}
			}
			else if (mapWidth >= maxWidth)
				ZoomFullExtent();

			else
			{
				if (widthRatio <= minRatio || heightRatio <= minRatio || widthRatio >= maxRatio || heightRatio >= maxRatio)
				{
					//set new size around new mapextent
					if (AOI != null) 
						AOI.Visibility = Visibility.Collapsed;
					if (maxWidth / 3 > mapWidth)
					{
						extent = new Envelope()
						{
							XMin = Map.Extent.XMin - mapWidth,
							XMax = Map.Extent.XMax + mapWidth,
							YMin = Map.Extent.YMin - mapHeight,
							YMax = Map.Extent.YMax + mapHeight
						};
						if (MaximumExtent != null)
						{
							if (extent.XMin < MaximumExtent.XMin) extent.XMin = MaximumExtent.XMin;
							if (extent.XMax > MaximumExtent.XMax) extent.XMax = MaximumExtent.XMax;
							if (extent.YMin < MaximumExtent.YMin) extent.YMin = MaximumExtent.YMin;
							if (extent.YMax > MaximumExtent.YMax) extent.YMax = MaximumExtent.YMax;
						}
						OVMapImage.ZoomTo(extent);
					}
					else
						ZoomFullExtent();
				}
				else
					UpdateAOI();
			}
		}

		/// <summary>
		/// Overload of UpdateOVMap - ExtentEventHandler version
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		private void UpdateOVMap(object sender, ESRI.ArcGIS.Client.ExtentEventArgs e)
		{
			UpdateOVMap();
		}

		private void ZoomFullExtent()
		{
			if (lastOVExtent == null)
				OVMapImage.ZoomTo(fullExtent);
			else if (lastOVExtent.Equals(fullExtent))
				UpdateAOI();
			else
				OVMapImage.ZoomTo(fullExtent);
		}

		#endregion

		#region Methods for setting size and position of AOI Box

		/// <summary>
		/// Sets size and position of AOI Box
		/// </summary>
		private void UpdateAOI()
		{
			if (Map == null || OVMapImage == null || OVMapImage.Extent == null || AOI == null) return;
			Envelope extent = Map.Extent;
			if (extent == null)
			{
				AOI.Visibility = Visibility.Collapsed;
				return;
			}
			MapPoint pt1 = new MapPoint(extent.XMin, extent.YMax);
			MapPoint pt2 = new MapPoint(extent.XMax, extent.YMin);
			Point topLeft = OVMapImage.MapToScreen(pt1);
			Point bottomRight = OVMapImage.MapToScreen(pt2);
			AOI.Margin = new Thickness(topLeft.X, topLeft.Y, 0, 0);
			AOI.Width = bottomRight.X - topLeft.X;
			AOI.Height = bottomRight.Y - topLeft.Y;
			lastMapExtent = extent;
			AOI.Visibility = Visibility.Visible;
			lastOVExtent = OVMapImage.Extent.Clone();
		}

		#endregion

		#region Method for setting extent of Map

		/// <summary>
		/// Set new map extent of main map control. Called after AOI
		/// Box has been repositioned by user
		/// </summary>
		private void UpdateMap()
		{
			if (AOI == null) return;
			mapExtent = Map.Extent;
			double aoiLeft = AOI.Margin.Left;
			double aoiTop = AOI.Margin.Top;
			MapPoint pt = OVMapImage.ScreenToMap(new Point(aoiLeft, aoiTop));
			double mapHalfWidth = mapExtent.Width / 2;
			double mapHalfHeight = mapExtent.Height / 2;
			MapPoint pnt = new MapPoint(pt.X + mapHalfWidth, pt.Y - mapHalfHeight);
			Map.PanTo(pnt);
		}

		#endregion

		#region AOI Box Mouse handlers
		private void AOI_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
		{
			dragOn = true;
			startPoint = e.GetPosition(this);
			offsetLeft = startPoint.X - AOI.Margin.Left;
			offsetTop = startPoint.Y - AOI.Margin.Top;
			AOI.MouseMove += AOI_MouseMove;
			AOI.MouseLeftButtonUp += AOI_MouseLeftButtonUp;
			AOI.CaptureMouse();
		}

		private void AOI_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			if (dragOn)
			{
				AOI.MouseMove -= AOI_MouseMove;
				AOI.MouseLeftButtonUp -= AOI_MouseLeftButtonUp;
				UpdateMap();
				dragOn = false;
				AOI.ReleaseMouseCapture();
			}
		}

		private void AOI_MouseMove(object sender, MouseEventArgs e)
		{
			if (dragOn)
			{
				Point pos = e.GetPosition(this);
				AOI.Margin = new Thickness(pos.X - offsetLeft, pos.Y - offsetTop, 0, 0);
			}
		}

		#endregion

		#endregion
	}
}
