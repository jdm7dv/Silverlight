﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace SilverlightAuthentication
{
    public partial class Page : UserControl
    {
        public Page()
        {
            InitializeComponent();
            ButtonLogin.Click += new RoutedEventHandler(ButtonLogin_Click);
            ButtonGetMyBalance.Click += new RoutedEventHandler(ButtonGetMyBalance_Click);
            ButtonGetXmlFile.Click += new RoutedEventHandler(ButtonGetXmlFile_Click);
        }

        private void ButtonGetXmlFile_Click(object sender, RoutedEventArgs e)
        {
            WebClient webclient = new WebClient();
            webclient.DownloadStringCompleted += new DownloadStringCompletedEventHandler(webclient_DownloadStringCompleted);
            webclient.DownloadStringAsync(new Uri("../Secure/TestFile.xml", UriKind.Relative));
        }

        private void webclient_DownloadStringCompleted(object sender, DownloadStringCompletedEventArgs e)
        {
            if (e.Error == null && !string.IsNullOrEmpty(e.Result))
            {
                TextBlockResult.Text = e.Result;
            }
            else
            {
                if (e.Error != null)
                    TextBlockResult.Text = e.Error.Message;
                else
                    TextBlockResult.Text = "Please login first";
            }
        }        

        private void ButtonLogin_Click(object sender, RoutedEventArgs e)
        {
            AuthenticationService.AuthenticationServiceClient authService = new AuthenticationService.AuthenticationServiceClient();
            authService.AuthenticateCompleted += new EventHandler<SilverlightAuthentication.AuthenticationService.AuthenticateCompletedEventArgs>(authService_AuthenticateCompleted);
            authService.AuthenticateAsync(TextBoxUsername.Text, TextBoxPassword.Text);
        }

        private void authService_AuthenticateCompleted(object sender, SilverlightAuthentication.AuthenticationService.AuthenticateCompletedEventArgs e)
        {
            if (e.Result)
            {
                LoginForm.Visibility = Visibility.Collapsed;
                ResultForm.Visibility = Visibility.Visible;
                TextBlockResult.Text = "";
            }
            else
            {
                TextBlockResult.Text = "Unable to log you in. Invalid username or password.";
            }
        }

        private void ButtonGetMyBalance_Click(object sender, RoutedEventArgs e)
        {
            BalanceService.BalanceServiceClient balanceService = new SilverlightAuthentication.BalanceService.BalanceServiceClient();
            balanceService.GetMyBalanceCompleted += new EventHandler<SilverlightAuthentication.BalanceService.GetMyBalanceCompletedEventArgs>(balanceService_GetMyBalanceCompleted);
            balanceService.GetMyBalanceAsync();
        }

        private void balanceService_GetMyBalanceCompleted(object sender, SilverlightAuthentication.BalanceService.GetMyBalanceCompletedEventArgs e)
        {
            if (e.Result == true)
            {
                TextBlockResult.Text = string.Format("Your balance: {0}", e.Balance.ToString());
            }
            else
            {
                TextBlockResult.Text = "Please login first";
            }
        }
    }
}
