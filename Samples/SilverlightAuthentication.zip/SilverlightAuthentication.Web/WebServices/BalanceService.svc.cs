﻿using System;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Activation;
using System.Web.Security;
using System.Web;

namespace SilverlightAuthentication.Web.WebServices
{
    [ServiceContract(Namespace = "")]
    [AspNetCompatibilityRequirements(RequirementsMode = AspNetCompatibilityRequirementsMode.Allowed)]
    public class BalanceService
    {
        // Add more operations here and mark them with [OperationContract]
        [OperationContract]
        public bool GetMyBalance(out decimal Balance)
        {
            if (HttpContext.Current.User.Identity.IsAuthenticated)
            {
                Balance = 1000.00M;

                return true;
            }
            else
            {
                Balance = decimal.MinValue;
                return false;
            }
        }

        // Add more operations here and mark them with [OperationContract]
    }
}
