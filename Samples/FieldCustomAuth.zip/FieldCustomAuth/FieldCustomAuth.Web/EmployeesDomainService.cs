﻿
namespace FieldCustomAuth.Web
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.ComponentModel.DataAnnotations;
    using System.Data;
    using System.Linq;
    using System.Web.DomainServices;
    using System.Web.DomainServices.Providers;
    using System.Web.Ria;
    using System.Web.Ria.Services;


    [RequiresAuthentication]
    [EnableClientAccess()]
    public class EmployeesDomainService : LinqToEntitiesDomainService<NORTHWNDEntities>
    {

        public IQueryable<Employee> GetEmployees()
        {
            foreach (var e in this.ObjectContext.Employees)
            {
                if (!this.ServiceContext.User.IsInRole("HRManagers"))
                {
                    e.SSN = null;
                }
                else if (e.Title.Contains("Vice President"))
                {
                    e.SSN = null;
                }
            }
            return this.ObjectContext.Employees;
        }

        public void InsertEmployee(Employee employee)
        {
            if ((employee.EntityState != EntityState.Added))
            {
                if ((employee.EntityState != EntityState.Detached))
                {
                    this.ObjectContext.ObjectStateManager.ChangeObjectState(employee, EntityState.Added);
                }
                else
                {
                    this.ObjectContext.AddToEmployees(employee);
                }
            }
        }

        public void UpdateEmployee(Employee currentEmployee)
        {
            if ((currentEmployee.EntityState == EntityState.Detached))
            {
                this.ObjectContext.AttachAsModified(currentEmployee, this.ChangeSet.GetOriginal(currentEmployee));
            }
        }

        public void DeleteEmployee(Employee employee)
        {
            if ((employee.EntityState == EntityState.Detached))
            {
                this.ObjectContext.Attach(employee);
            }
            this.ObjectContext.DeleteObject(employee);
        }
    }
}


