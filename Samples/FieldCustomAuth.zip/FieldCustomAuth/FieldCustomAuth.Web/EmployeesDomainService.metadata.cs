﻿#pragma warning disable 649    // disable compiler warnings about unassigned fields

namespace FieldCustomAuth.Web
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.ComponentModel.DataAnnotations;
    using System.Data.Objects.DataClasses;
    using System.Linq;
    using System.Web.DomainServices;
    using System.Web.Ria;
    using System.Web.Ria.Services;


    // The MetadataTypeAttribute identifies EmployeeMetadata as the class
    // that carries additional metadata for the Employee class.
    [MetadataTypeAttribute(typeof(Employee.EmployeeMetadata))]
    public partial class Employee
    {

        // This class allows you to attach custom attributes to properties
        // of the Employee class.
        //
        // For example, the following marks the Xyz property as a
        // required field and specifies the format for valid values:
        //    [Required]
        //    [RegularExpression("[A-Z][A-Za-z0-9]*")]
        //    [StringLength(32)]
        //    public string Xyz;
        internal sealed class EmployeeMetadata
        {

            // Metadata classes are not meant to be instantiated.
            private EmployeeMetadata()
            {
            }

            public string Address;

            public Nullable<DateTime> BirthDate;

            public string City;

            public string Country;

            public Employee Employee1;

            public int EmployeeID;

            public EntityCollection<Employee> Employees1;

            public string Extension;

            public string FirstName;

            public Nullable<DateTime> HireDate;

            public string HomePhone;

            public string LastName;

            public string Notes;

            public string PhotoPath;

            public string PostalCode;

            public string Region;

            public Nullable<int> ReportsTo;

            public string SSN;

            public string Title;

            public string TitleOfCourtesy;
        }
    }
}

#pragma warning restore 649    // re-enable compiler warnings about unassigned fields
