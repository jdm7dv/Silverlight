﻿// (c) Copyright Microsoft Corporation.
// This source is subject to the Microsoft Public License (Ms-PL).
// Please see http://go.microsoft.com/fwlink/?LinkID=131993 for details.
// All other rights reserved.

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ToolkitThemeAssistant;
using System.IO;

namespace ToolkitTheme
{
    class Program
    {
        static void Main(string[] args)
        {
            ConsoleColor color = Console.ForegroundColor;
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine("Theme Converter Proof-of-concept");
            Console.WriteLine("Microsoft Silverlight Toolkit");
            Console.ForegroundColor = color;

            Console.WriteLine();
            Console.WriteLine("WARNING: Save your source XAML. This is an unsupported prototype..");
            Console.WriteLine();

            Console.WriteLine("ThemeCoverter.exe <input XAML> direction <output XAML>");
            Console.WriteLine("direction is one of");
            Console.WriteLine("\t/t:blend\t\t(Convert resource dictionary to application resources)");
            Console.WriteLine("\t/t:ism\t\t\t(Convert user control or app resources to resource dictionary)");
            Console.WriteLine();
            Console.WriteLine("This tool makes a few assumptions that [should] be documented.");
            Console.WriteLine();

            if (args.Length < 3)
            {
                Console.Error.WriteLine("3 parameters required.");
                return;
            }

            string input = args[0];
            string output = args[2];
            string mode = args[1];
            if (mode != "/t:ism" && mode != "/t:blend")
            {
                Console.WriteLine("Invalid mode: must be /t:ism or /t:blend.");
                return;
            }

            string inXaml = File.ReadAllText(input, Encoding.UTF8);

            Console.WriteLine("Processing " + input);
            string outXaml = mode == "/t:ism" ? 
                DesignerXamlConverter.ConvertToIsmXaml(inXaml) : 
                DesignerXamlConverter.ConvertToDesignerXaml(inXaml);
            File.WriteAllText(output, outXaml, Encoding.UTF8);
            Console.WriteLine("Wrote out converted XAML file " + output);
        }
    }
}