﻿// (c) Copyright Microsoft Corporation.
// This source is subject to the Microsoft Public License (Ms-PL).
// Please see http://go.microsoft.com/fwlink/?LinkID=131993 for details.
// All other rights reserved.

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ToolkitThemeAssistant
{
    /// <summary>
    /// A simple utility static class for managing temporary console colors.
    /// </summary>
    internal class ConsoleColoring : IDisposable
    {
        /// <summary>
        /// The color to revert to upon disposal.
        /// </summary>
        private ConsoleColor _revert;

        /// <summary>
        /// Initializes a new instance of the ConsoleColoring type.
        /// </summary>
        public ConsoleColoring()
        {
            _revert = Console.ForegroundColor;
        }

        /// <summary>
        /// Initializes a new instance of the ConsoleColoring type.
        /// </summary>
        /// <param name="color">The color to use temporarily.</param>
        public ConsoleColoring(ConsoleColor color)
            : this()
        {
            Console.ForegroundColor = color;
        }

        /// <summary>
        /// Dispose the console color and revert.
        /// </summary>
        public void Dispose()
        {
            Console.ForegroundColor = _revert;
        }
    }
}