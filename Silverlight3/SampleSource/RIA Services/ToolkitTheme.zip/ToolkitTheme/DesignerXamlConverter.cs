﻿// (c) Copyright Microsoft Corporation.
// This source is subject to the Microsoft Public License (Ms-PL).
// Please see http://go.microsoft.com/fwlink/?LinkID=131993 for details.
// All other rights reserved.

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Xml.Linq;

namespace ToolkitThemeAssistant
{
    /// <summary>
    /// The DesignerXamlConverter class provides static methods for converting 
    /// between conformant designer XAML and ISM-compatible Silverlight XAML.
    /// </summary>
    public static class DesignerXamlConverter
    {
        #region XAML namespaces, XNames, and constant strings
        /// <summary>
        /// The extended XAML XML namespace (x:).
        /// </summary>
        private static readonly XNamespace XamlXNamespace = "http://schemas.microsoft.com/winfx/2006/xaml";
        
        /// <summary>
        /// The primary XAML XML namespace.
        /// </summary>
        private static readonly XNamespace XamlNamespace = "http://schemas.microsoft.com/winfx/2006/xaml/presentation";

        /// <summary>
        /// Constant 'Key' string.
        /// </summary>
        private const string Key = "Key";

        /// <summary>
        /// Constant 'Name' string.
        /// </summary>
        private const string Name = "Name";

        /// <summary>
        /// Constant 'Style' string.
        /// </summary>
        private const string Style = "Style";

        /// <summary>
        /// Constant 'Class' string.
        /// </summary>
        private const string Class = "Class";

        /// <summary>
        /// Constant 'StaticResource' string.
        /// </summary>
        private const string StaticResource = "StaticResource";

        /// <summary>
        /// Constant 'ResourceDictionary' string.
        /// </summary>
        private const string ResourceDictionary = "ResourceDictionary";

        /// <summary>
        /// Constant 'Application' string.
        /// </summary>
        private const string Application = "Application";

        /// <summary>
        /// Constant 'ApplicationResources' string.
        /// </summary>
        private const string ApplicationResources = "Application.Resources";

        /// <summary>
        /// Constant 'UserControl' string.
        /// </summary>
        private const string UserControl = "UserControl";

        /// <summary>
        /// Constant 'UserControl.Resources' string.
        /// </summary>
        private const string UserControlResources = "UserControl.Resources";

        /// <summary>
        /// Constant 'TargetType' string.
        /// </summary>
        private const string TargetType = "TargetType";

        /// <summary>
        /// Constant 'x:Key' string.
        /// </summary>
        private const string XKeyString = "x:Key";

        /// <summary>
        /// Constant quote string.
        /// </summary>
        private const string Quote = "\"";

        /// <summary>
        /// Constant equals quote string.
        /// </summary>
        private const string EqualsQuote = "=" + Quote;

        /// <summary>
        /// Constant ' ' string.
        /// </summary>
        private const string Space = " ";

        /// <summary>
        /// The string 'Controls'.
        /// </summary>
        private const string Controls = "Controls";

        /// <summary>
        /// The string 'namespace'.
        /// </summary>
        private const string SimpleNamespaceAttribute = "namespace";

        /// <summary>
        /// Single readonly instance of the Key name.
        /// </summary>
        private static readonly XName XKeyName = XamlXNamespace + Key;

        /// <summary>
        /// Single readonly instance of the Style name.
        /// </summary>
        private static readonly XName XamlStyleName = XamlNamespace+ Style;

        /// <summary>
        /// Single readonly instance of the UserControl name.
        /// </summary>
        private static readonly XName XamlUserControl = XamlNamespace + UserControl;

        /// <summary>
        /// Single readonly instance of the x:Class name.
        /// </summary>
        private static readonly XName XamlClassAttribute = XamlXNamespace + Class;

        /// <summary>
        /// Single readonly instance of the x:Name name.
        /// </summary>
        private static readonly XName XamlNameAttribute = XamlXNamespace + Name;

        /// <summary>
        /// Single readonly instance of the Application name.
        /// </summary>
        private static readonly XName XamlApplication = XamlNamespace + Application;

        /// <summary>
        /// Single readonly instance of the ApplicationResources name.
        /// </summary>
        private static readonly XName XamlApplicationResources = XamlNamespace + ApplicationResources;

        /// <summary>
        /// Single readonly instance of the ResourceDictionary name.
        /// </summary>
        private static readonly XName XamlResourceDictionary = XamlNamespace + ResourceDictionary;
        
        /// <summary>
        /// Single readonly instance of the UserControl.Resources name.
        /// </summary>
        private static readonly XName XamlUserControlResources = XamlNamespace + UserControlResources;

        #endregion

        /// <summary>
        /// A single known-controls data file instance.
        /// </summary>
        private static XDocument KnownDesignerXamlInformation;

        /// <summary>
        /// Initializes the static instance of DesignerXamlConverter.
        /// </summary>
        static DesignerXamlConverter()
        {
            string designerXamlDataFile = File.ReadAllText(@"DesignerXaml.xml");
            KnownDesignerXamlInformation = XDocument.Parse(designerXamlDataFile);
        }

        /// <summary>
        /// Gets a list of known controls.
        /// </summary>
        private static Dictionary<string, string> KnownControls
        {
            get
            {
                Dictionary<string, string> kc = new Dictionary<string, string>();
                XElement controls = KnownDesignerXamlInformation.Descendants(Controls).First();
                foreach (var control in controls.Elements().
                    Where(element => element.Attribute(SimpleNamespaceAttribute) != null)
                )
                {
                    kc.Add(control.Name.LocalName, control.Attribute(SimpleNamespaceAttribute).Value);
                }
                return kc;
            }
        }

        /// <summary>
        /// Converts specifically-conformant designer XAML (contained in a page
        /// and its resources) into an ImplicitStyleManager-compatible file. 
        /// Only the UserControl.Resources are preserved.
        /// </summary>
        /// <param name="designerXaml">The designer XAML.</param>
        /// <returns>Returns the ISM-compatible resource dictionary.</returns>
        public static string ConvertToIsmXaml(string designerXaml)
        {
            XDocument doc = XDocument.Parse(designerXaml);

            // Validate that it is a UserControl or Application
            if (doc.Root.Name != XamlUserControl)
            {
                throw new InvalidOperationException();
            }

            // Get the resource dictionary
            XElement dictionary = doc.Root.Descendants(XamlUserControlResources).First();

            // Rewrite static resources that point to controls by pointing to 
            // the full namespace name
            var knownControls = KnownControls;

            Dictionary<string, string> knownStyleNames = new Dictionary<string, string>();

            // Figure out what target types and associated names there are. 
            // Assumption: The FIRST TargetType is ALWAYS the theme style.
            foreach (var item in dictionary.Descendants(XamlStyleName).
                Where(
                node => node.Attribute(TargetType) != null
                    &&
                    (
                    node.Attribute(XamlNameAttribute) != null
                    ||
                    node.Attribute(XKeyName) != null
                    )
                )
                )
            {
                string tt = item.Attribute(TargetType).Value;
                if (knownControls.ContainsKey(tt))
                {
                    XAttribute namingAttribute = item.Attribute(XKeyName) ?? item.Attribute(XamlNameAttribute);
                    string styleName = namingAttribute.Value;
                    if (knownStyleNames.Values.Contains(tt))
                    {
                        using (new ConsoleColoring(ConsoleColor.Yellow))
                        {
                            Console.WriteLine("Another TargetType " + tt + " is already defined (processing Style \"" + styleName + "\")");
                        }
                    }
                    else
                    {
                        knownStyleNames[styleName] = tt;
                        using (new ConsoleColoring(ConsoleColor.Green))
                        {
                            Console.WriteLine("The theme's " + tt + " style is " + styleName);
                        }
                    }
                }
                else
                {
                    Console.WriteLine("Unknown target type, skipping processing for " + tt);
                }
            }

            // From Keys to Comments
            foreach (var item in dictionary.Descendants(XamlStyleName).
                Where(
                (node => 
                    node.Attribute(XamlNameAttribute) != null || 
                    node.Attribute(XKeyName) != null))
                )
            {
                XAttribute namedAttribute = item.Attribute(XKeyName) ?? item.Attribute(XamlNameAttribute);
                string keyValue = namedAttribute.Value;
                item.AddBeforeSelf(new XComment(Space + XKeyString + EqualsQuote + keyValue + Quote + Space));
                namedAttribute.Remove();
                // item.Attribute(XKeyName).Remove();
            }

            var controlList = knownControls.Keys.ToList();
            
            // The names folks have come up with
            foreach (string s in knownStyleNames.Keys)
            {
                controlList.Add(s);
            }

            foreach (var attr in doc.Root.
                Descendants().
                Attributes()
                .Where(av => av.Value.Contains("{" + StaticResource + Space)
                    && av.Value.ContainsAny(controlList))
                    )
            {
                string value = attr.Value;
                int i = value.IndexOf(StaticResource + Space);
                if (i > 0)
                {
                    value = value.Substring(i + StaticResource.Length + 1, value.IndexOf('}') - i - StaticResource.Length - 1);
                    string valueWithoutStyle = value.EndsWith("Style") ? value.Substring(0, value.Length - 5) : value;
                    valueWithoutStyle = valueWithoutStyle.EndsWith("Style1") ? valueWithoutStyle.Substring(valueWithoutStyle.Length - 6) : valueWithoutStyle;

                    // This is an alias/they provided their own name/key
                    if (knownStyleNames.ContainsKey(value))
                    {
                        valueWithoutStyle = knownStyleNames[value];
                        Console.WriteLine("Static resource reference for designer-named style called \"" + value + "\" is a known " + valueWithoutStyle);
                    }

                    bool found = false;
                    foreach (var item in knownControls)
                    {
                        if (valueWithoutStyle == item.Key)
                        {
                            string newValue = item.Value + "." + item.Key;
                            attr.Value = attr.Value.Replace(value, newValue);
                            found = true;
                            using (new ConsoleColoring(ConsoleColor.Gray))
                            {
                                Console.WriteLine("Converted static resource attribute {0} -> {1}", value, attr.Value);
                            }

                            break;
                        }
                    }
                    if (!found)
                    {
                        // Not modified
                        ConsoleColor color = ConsoleColor.DarkGray;
                        string message = "StaticResource {0} was left unmodified.";

                        if (!value.ContainsAny(new string[] { "Brush", "Color", "Template" }))
                        {
                            color = ConsoleColor.Yellow;
                            message = "Warning: StaticResource {0} is not a known control and will not be modified.";
                        }

                        using (new ConsoleColoring(color))
                        {

                            Console.WriteLine(message, value);
                        }
                    }
                }
            }

            List<XAttribute> oldNamespaceAttributes = new List<XAttribute>();
            foreach (var attribute in doc.Root.Attributes().
                Where(attr => attr.Name.ToString().Contains("xmlns"))
                )
            {
                dictionary.SetAttributeValue(attribute.Name, attribute.Value);
                oldNamespaceAttributes.Add(attribute);
            }

            // Store the x:Class, if present, as a special comment
            var classAttribute = doc.Root.Attributes(XamlClassAttribute).FirstOrDefault();
            if (classAttribute!= null)
            {
                string name = classAttribute.Value;
                int i = name.LastIndexOf('.');
                string ns = name.Substring(0, i);

                // Store the name as a comment
                dictionary.AddFirst(new XComment(" namespace=\"" + ns + "\" "));
            }

            // Convert from UserControl to ResourceDictionary
            dictionary.Name = XamlResourceDictionary;

            return dictionary.ToString();
        }

        /// <summary>
        /// Converts an ImplicitStyleManager resource dictionary into a 
        /// designable XAML UserControl. The resource dictionary will be loaded
        /// into the UserControl.Resources element and key names inferred and/or
        /// retrieved from properly formatted comments.
        /// </summary>
        /// <param name="ismXaml">The ISM-compatible XAML.</param>
        /// <returns>Returns a new UserControl XAML page.</returns>
        public static string ConvertToDesignerXaml(string ismXaml)
        {
            XDocument doc = XDocument.Parse(ismXaml);

            // Validate that it's a ResourceDictionary now
            if (doc.Root.Name != XamlResourceDictionary)
            {
                throw new InvalidOperationException();
            }

            List<XComment> oldComments = new List<XComment>();
            // From Comments to Keys
            foreach (var node in doc.Root.DescendantNodes()
                .OfType<XComment>()
                .Where(comment => comment.Value.Contains(XKeyString))
                )
            {
                string raw = node.Value;
                int i = raw.IndexOf(XKeyString + EqualsQuote) + 7;
                string key = raw.Substring(i, raw.IndexOf(Quote, i) - i);

                var next = node.ElementsAfterSelf().First();
                next.SetAttributeValue(XKeyName, key);
                oldComments.Add(node);
            }
            foreach (XComment comment in oldComments)
            {
                comment.Remove();
            }

            // From Style without anything to styles with keys
            foreach (var element in doc.Root.Descendants(XamlStyleName)
                .Where(e => e.Attribute(XKeyName) == null
                    && e.Parent.Name == XamlResourceDictionary
                    && e.Attribute(TargetType) != null)
                )
            {
                string targetType = element.Attribute(TargetType).Value;

                int idx = targetType.IndexOf(':');
                if (idx >= 0)
                {
                    targetType = targetType.Substring(idx + 1);
                }

                if (!targetType.Contains(Style))
                {
                    targetType += Style;
                }

                element.SetAttributeValue(XKeyName, targetType);
            }

            // Rewrite static resources that might point to controls
            // Q: does this go to the THEME or the DEFAULT?
            var knownControls = KnownControls;
            foreach (var attr in doc.Root.Descendants().Attributes()
                .Where(av => av.Value.Contains("{" + StaticResource + Space)
                    && av.Value.ContainsAny(FullNamespaceList(knownControls))
                    ))
            {
                string value = attr.Value;
                int i = value.IndexOf(StaticResource + Space);
                if (i > 0)
                {
                    value = value.Substring(i + StaticResource.Length + 1, value.IndexOf('}') - i - StaticResource.Length - 1);
                    bool found = false;
                    foreach (var item in knownControls)
                    {
                        if (value == item.Value + "." + item.Key)
                        {
                            string newValue = item.Key + Style; // Style1 ? Blend ?
                            attr.Value = attr.Value.Replace(value, newValue);
                            using (new ConsoleColoring(ConsoleColor.Gray))
                            {
                                Console.WriteLine("Converted static resource {0} to {1}", value, newValue);
                            }
                            found = true;
                            break;
                        }
                    }
                    if (!found)
                    {
                        using (new ConsoleColoring(ConsoleColor.DarkGray))
                        {
                            Console.WriteLine("Static resource {0} was left unmodified.", value);
                        }
                    }
                }
            }

            // Convert ResourceDictionary to UserControl
            XElement root = doc.Root;
            // root.Name = XamlUserControlResources;
            // Change: Always converting to app resources
            root.Name = XamlApplicationResources;

            // Root Application now
            // XElement control = new XElement(XamlUserControl);
            XElement control = new XElement(XamlApplication);
            
            // Set the application's x:Class, if the namespace is known
            var nsComment = root.
                Nodes().
                OfType<XComment>().
                Where(
                comment => comment.Value.Contains("namespace=\""))
                .FirstOrDefault();
            string applicationClassName = null;
            if (nsComment != null)
            {
                string ns = nsComment.Value;
                int i = ns.IndexOf("namespace=\"");
                ns = ns.Substring(i + "namespace=\"".Length);
                i = ns.IndexOf("\"");
                ns = ns.Substring(0, i);

                string appName = ns + "." + "App";
                applicationClassName = appName;
                nsComment.Remove();
            }
            control.Add(root);

            List<XAttribute> oldNamespaceAttributes = new List<XAttribute>();
            foreach (var attribute in root.Attributes().
                Where(attr => attr.Name.ToString().Contains("xmlns"))
                )
            {
                control.SetAttributeValue(attribute.Name, attribute.Value);
                oldNamespaceAttributes.Add(attribute);
            }
            
            // Set the app class name
            if (applicationClassName != null)
            {
                control.SetAttributeValue(XamlClassAttribute, applicationClassName);
            }

            string cx = control.ToString();
            foreach (XAttribute attr in oldNamespaceAttributes)
            {
                // Cannot remove attributes that are xmlns declarations from a former root
                // root.SetAttributeValue(attr.Name, null);
                cx = RemoveDuplicateNamespace(cx, attr);
            }

            return cx;
        }

        /// <summary>
        /// Creates a list with both keys and values combined in the pattern 
        /// Value + . + Key.
        /// </summary>
        /// <param name="input">The input string dictionary.</param>
        /// <returns>Returns the list of new strings.</returns>
        private static List<string> FullNamespaceList(Dictionary<string, string> input)
        {
            List<string> l = new List<string>();
            foreach (var item in input)
            {
                l.Add(item.Value + "." + item.Key);
            }
            return l;
        }

        /// <summary>
        /// String function to remove the 2nd instance of the attribute from the
        /// XML source code.
        /// </summary>
        /// <param name="xaml">The XML source code.</param>
        /// <param name="attribute">The XAttribute instance.</param>
        /// <returns>Returns the XML source with the first duplicate (2nd 
        /// instance) 
        /// of the attribute's content.</returns>
        private static string RemoveDuplicateNamespace(string xaml, XAttribute attribute)
        {
            string nsLine = attribute.ToString();
            int index = xaml.IndexOf(nsLine);
            if (index > 0)
            {
                index = xaml.IndexOf(nsLine, index + 1);
                if (index >= 0)
                {
                    string newXaml = xaml.Substring(0, index - 1) + xaml.Substring(index + nsLine.Length);
                    return newXaml;
                }
            }

            return xaml;
        }
    }
}