﻿// (c) Copyright Microsoft Corporation.
// This source is subject to the Microsoft Public License (Ms-PL).
// Please see http://go.microsoft.com/fwlink/?LinkID=131993 for details.
// All other rights reserved.

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ToolkitThemeAssistant
{
    /// <summary>
    /// Internal extension methods.
    /// </summary>
    internal static class Extensions
    {
        /// <summary>
        /// Check for the string containing any string from an enumeration.
        /// </summary>
        /// <param name="value">The string to search through.</param>
        /// <param name="list">A list of strings to check.</param>
        /// <returns>Returns true if any of the strings are found.</returns>
        public static bool ContainsAny(this string value, IEnumerable<string> list)
        {
            foreach (string item in list)
            {
                if (value.Contains(item))
                {
                    return true;
                }
            }

            return false;
        }
    }
}