using System;
using System.Collections.Generic;
using System.IO;
using System.Collections.ObjectModel;
using System.Windows;
using System.ComponentModel;
using WpfTests.BestPractices.MyPlugIn.UILogicLayer;

#if DEBUG
using WpfTests.BestPractices.MyPlugIn.UITestLogicLayer;
#endif

namespace WpfTests.BestPractices.MyPlugIn.UIDataLayer
{
  public class FileDataProvider : IDisposable
  {
    // Note: This is a simple implementation, so I use two collections. In fact, it would be
    // better to implement an ObservableDictionary or something.
    private ObservableCollection<FileItem> _items = new ObservableCollection<FileItem>();
    private Dictionary<string, FileItem> _itemsByName = new Dictionary<string, FileItem>();

    private UIBusinessObject _businessObject;
    private DirectoryInfo _startDirectory;
    private bool _isInTestMode;

#if DEBUG
    private TestObject _testObject;
#endif

    public ObservableCollection<FileItem> Files
    {
      get { return _items; }
    }

    /// <summary>
    /// That's the trick: Use a temporary DependencyObject to check
    /// if the control is in design mode.
    /// Note: If the provider itself is a DependencyObject, you can use
    /// return DesignerProperties.GetIsInDesignMode(this);
    /// </summary>
    public bool IsInDesignMode
    {
      get
      {
        return DesignerProperties.GetIsInDesignMode(new DependencyObject());
      }
    }
    public bool IsInTestMode
    {
      set
      {
        if (_isInTestMode == value)
        {
          return;
        }

        _isInTestMode = value;

        if (IsInDesignMode)
        {
          // No test mode in design mode
          _isInTestMode = false;
          return;
        }

        MakeObjects();
      }
    }

    public string StartDirectory
    {
      set
      {
        if (!Directory.Exists(value))
        {
          MessageBox.Show("Non existing directory: " + value);
        }
        _startDirectory = new DirectoryInfo(value);

        if (!_isInTestMode
            && !IsInDesignMode)
        {
          MakeObjects();
        }
      }
    }

    public FileDataProvider()
    {
      if (IsInDesignMode)
      {
        MakeTestObject();
      }
    }

    private void MakeObjects()
    {
      if (_items.Count > 0)
      {
        _items.Clear();
        _itemsByName.Clear();
      }
      if (_isInTestMode)
      {
        if (_businessObject != null)
        {
          _businessObject.Dispose();
          _businessObject = null;
        }
        MakeTestObject();
      }
      else
      {
#if DEBUG
        if (_testObject != null)
        {
          _testObject.Dispose();
          _testObject = null;
        }
#endif
        MakeBusinessObject();
      }
    }

    private void MakeTestObject()
    {
#if DEBUG
      if (_testObject != null)
      {
        _testObject.Dispose();
      }
      _testObject = new TestObject(this);
      _testObject.RegisterForChanges(Notify);
#endif
    }
    private void MakeBusinessObject()
    {
      if (_businessObject != null)
      {
        _businessObject.Dispose();
      }
      _businessObject = new UIBusinessObject(_startDirectory);
      _businessObject.RegisterForChanges(Notify);
    }

    private void Notify(FileItem added, string deleted, FileItem changed, string oldName, string newName)
    {
      if (deleted != null)
      {
        this.RemoveFileItem(deleted);
      }
      if (added != null)
      {
        this.AddFileItem(added);
      }
      if (changed != null)
      {
        ChangeFileItem(changed);
      }
      if (oldName != null && newName != null)
      {
        RenameItem(oldName, newName);
      }
    }

    private void AddFileItem(FileItem item)
    {
      _items.Add(item);
      _itemsByName.Add(item.Name, item);
    }
    private FileItem RemoveFileItem(string name)
    {
      if (!_itemsByName.ContainsKey(name))
      {
        return null;
      }
      FileItem original = _itemsByName[name];
      _itemsByName.Remove(name);
      _items.Remove(original);
      return original;
    }
    private void ChangeFileItem(FileItem changedItem)
    {
      FileItem original = _itemsByName[changedItem.Name];
      original.Update(changedItem);
    }
    private void RenameItem(string oldName, string newName)
    {
      FileItem item = RemoveFileItem(oldName);
      if (item != null)
      {
        item.Name = newName;
        AddFileItem(item);
      }
    }

    #region IDisposable Members

    public void Dispose()
    {
      if (_businessObject != null)
      {
        _businessObject.Dispose();
      }
#if DEBUG
      if (_testObject != null)
      {
        _testObject.Dispose();
      }
#endif
    }

    #endregion
  }
}
