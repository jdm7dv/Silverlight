using System;
using System.Windows;

namespace WpfTests.BestPractices.MyPlugIn.UIDataLayer
{
  public class FileItem : DependencyObject
  {
    // DependencyProperty best practice: Declare CLR accessors for the DP.
    // Note: This can be done using Snippets in Visual Studio (Ctrl-K, Ctrl-X)
    public string Name
    {
      get { return (string) GetValue(NameProperty); }
      set { SetValue(NameProperty, value); }
    }

    // Using a DependencyProperty as the backing store for Name.  This enables animation, styling, binding, etc...
    public static readonly DependencyProperty NameProperty =
        DependencyProperty.Register("Name", typeof(string), typeof(FileItem), new UIPropertyMetadata(""));

    public string FullPath
    {
      get { return (string) GetValue(FullPathProperty); }
      set { SetValue(FullPathProperty, value); }
    }

    // Using a DependencyProperty as the backing store for FullPath.  This enables animation, styling, binding, etc...
    public static readonly DependencyProperty FullPathProperty =
        DependencyProperty.Register("FullPath", typeof(string), typeof(FileItem), new UIPropertyMetadata(""));

    public DateTime DateChanged
    {
      get { return (DateTime) GetValue(DateChangedProperty); }
      set { SetValue(DateChangedProperty, value); }
    }

    // Using a DependencyProperty as the backing store for DateChanged.  This enables animation, styling, binding, etc...
    public static readonly DependencyProperty DateChangedProperty =
        DependencyProperty.Register("DateChanged",
            typeof(DateTime),
            typeof(FileItem),
            new UIPropertyMetadata(DateTime.MinValue));

    public long Size
    {
      get { return (long) GetValue(SizeProperty); }
      set { SetValue(SizeProperty, value); }
    }

    // Using a DependencyProperty as the backing store for Size.  This enables animation, styling, binding, etc...
    public static readonly DependencyProperty SizeProperty =
        DependencyProperty.Register("Size", typeof(long), typeof(FileItem), new UIPropertyMetadata(0L));

    internal void Update(FileItem model)
    {
      this.Name = model.Name;
      this.FullPath = model.FullPath;
      this.DateChanged = model.DateChanged;
      this.Size = model.Size;
    }
  }
}
