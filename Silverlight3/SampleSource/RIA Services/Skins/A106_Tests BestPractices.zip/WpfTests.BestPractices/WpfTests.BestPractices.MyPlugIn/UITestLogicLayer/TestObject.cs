// This object is only available in the Debug version of the Plug-In,
// it is completely removed in the Release version.

#if DEBUG

using System;
using System.Collections.Generic;
using System.IO;
using WpfTests.BestPractices.MyPlugIn.UIDataLayer;
using WpfTests.BestPractices.MyPlugIn.UILogicLayer;

namespace WpfTests.BestPractices.MyPlugIn.UITestLogicLayer
{
  /// <summary>
  /// This object provides data in design mode (in Blend or Cider) and in test mode.
  /// In test mode, it also provides methods to add or remove items, in order to see how
  /// the UI reacts.
  /// Note that the modifications of existing items are made through binding only,
  /// so this test object is not used to modify existing items!
  /// Note also that the object provides a static method allowing to retrieve
  /// an existing instance. This provides an entry point for the test window,
  /// without letting the Plug-In know about it (this is important so that
  /// we can remove this code in Release versions).
  /// </summary>
  public class TestObject : IDisposable
  {
    // Keep track of the created objects in order to provide data to the test window
    private static Dictionary<FileDataProvider, TestObject> _instances = null;

    /// <summary>
    /// The object provides a static method allowing to retrieve
    /// an existing instance. This provides an entry point for the test window,
    /// without letting the Plug-In know about it (this is important so that
    /// we can remove this code in Release versions).
    /// </summary>
    public static TestObject Get(FileDataProvider provider)
    {
      if (_instances == null
          || !_instances.ContainsKey(provider))
      {
        return null;
      }
      return _instances[provider];
    }

    List<UIBusinessObject.NotifyFileItemDelegate> _callbacks = new List<UIBusinessObject.NotifyFileItemDelegate>();
    List<FileItem> _fileItems = new List<FileItem>();
    FileDataProvider _provider;

    internal TestObject(FileDataProvider provider)
    {
      // Create initial files (for Blend and Cider)
      string path = @"c:\temp\";
      FileItem item1 = new FileItem();
      item1.Name = "TestFile1.txt";
      item1.FullPath = Path.Combine(path, item1.Name);
      item1.Size = 100;
      item1.DateChanged = DateTime.Now;
      _fileItems.Add(item1);
      FileItem item2 = new FileItem();
      item2.Name = "TestFile2.doc";
      item2.FullPath = Path.Combine(path, item2.Name);
      item2.Size = 200;
      item2.DateChanged = DateTime.Now;
      _fileItems.Add(item2);
      FileItem item3 = new FileItem();
      item3.Name = "TestFile3.gif";
      item3.FullPath = Path.Combine(path, item3.Name);
      item3.Size = 300;
      item3.DateChanged = DateTime.Now;
      _fileItems.Add(item3);
      
      // Store reference to this object for the Test Window
      if (_instances == null)
      {
        _instances = new Dictionary<FileDataProvider, TestObject>();
      }
      _instances.Add(provider, this);
      _provider = provider;
    }

    /// <summary>
    /// This method replicates the BusinessObject method.
    /// </summary>
    public void RegisterForChanges(UIBusinessObject.NotifyFileItemDelegate callback)
    {
      _callbacks.Add(callback);
      foreach (FileItem item in _fileItems)
      {
        callback(item, null, null, null, null);
      }
    }

    #region IDisposable Members

    /// <summary>
    /// Clean up
    /// </summary>
    public void Dispose()
    {
      _instances.Remove(_provider);
      if (_instances.Count == 0)
      {
        _instances = null;
      }
    }

    #endregion

    // Test methods -------------------------------------------------------

    // These methods can be used from the Test window, in order to check
    // how the UI reacts. In real applications, we could use these methods
    // to simulate very big number of data, alarm bursts, etc...

    public void AddFileItems(int numberOfFileItems)
    {
      for (int index = 0; index < numberOfFileItems; index++)
      {
        FileItem newItem = new FileItem();
        newItem.Name = "TestFile" + _fileItems.Count + ".abc";
        newItem.Size = index;
        newItem.DateChanged = DateTime.Now - new TimeSpan(index, index, index, index);
        _fileItems.Add(newItem);

        foreach (UIBusinessObject.NotifyFileItemDelegate callback in _callbacks)
        {
          callback(newItem, null, null, null, null);
        }
      }
    }
    public void RemoveFileItems(int numberOfFileItems)
    {
      int toRemove = numberOfFileItems;
      int totalItems = _fileItems.Count;
      if (numberOfFileItems > totalItems)
      {
        toRemove = _fileItems.Count;
      }

      // Not the most efficient way to do that, a real application would
      // plan a dedicated method for this...
      foreach (UIBusinessObject.NotifyFileItemDelegate callback in _callbacks)
      {
        for (int index = 0; index < toRemove; index++)
        {
          FileItem item = _fileItems[_fileItems.Count - 1];
          callback(null, item.Name, null, null, null);
          _fileItems.Remove(item);
        }
      }
    }
  }
}
#endif