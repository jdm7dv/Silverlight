using System;
using System.Collections.Generic;
using System.IO;
using System.Windows;
using System.Windows.Threading;
using WpfTests.BestPractices.MyPlugIn.UIDataLayer;
using WpfTests.BestPractices.SomeService;

namespace WpfTests.BestPractices.MyPlugIn.UILogicLayer
{
  // This particular case is so simple that there is no real need for a Business Logic Layer.
  // In this example, the Business Object transforms FileInfo objects into FileItem objects,
  // so that the UI data layer does not need to use System.IO. In a real life
  // example, of course, the Business Object's abstraction task is more complex.
  public class UIBusinessObject : IDisposable
  {
    public delegate void NotifyFileItemDelegate(FileItem added,
        string deleted,
        FileItem changed,
        string oldName,
        string newName);

    List<NotifyFileItemDelegate> _callbacks = new List<NotifyFileItemDelegate>();
    private DataSource _networkObject;

    internal UIBusinessObject(DirectoryInfo start)
    {
      if (start == null
          || !start.Exists)
      {
        return;
      }

      _networkObject = new DataSource(start);
      _networkObject.RegisterForChanges(NotifyFile);
    }

    public void RegisterForChanges(NotifyFileItemDelegate callback)
    {
      if (_networkObject == null)
      {
        return;
      }

      _callbacks.Add(callback);
      _networkObject.GetInitialDataNotifications(NotifyFile);
    }

    private void NotifyFile(FileInfo fileAdded,
        string fileDeleted,
        FileInfo fileChanged,
        string fileOldName,
        string fileNewName)
    {
      if (fileAdded != null)
      {
        foreach (NotifyFileItemDelegate callback in _callbacks)
        {
          // The file system watcher runs in another thread --> Dispatch to the main UI thread
          Application.Current.Dispatcher.Invoke(DispatcherPriority.Background,
              new DispatcherOperationCallback(delegate
              {
                callback(GetFileItem(fileAdded), null, null, null, null);
                return null;
              }), null);
        }
      }
      if (fileDeleted != null)
      {
        foreach (NotifyFileItemDelegate callback in _callbacks)
        {
          // The file system watcher runs in another thread --> Dispatch to the main UI thread
          Application.Current.Dispatcher.Invoke(DispatcherPriority.Background,
              new DispatcherOperationCallback(delegate
              {
                callback(null, fileDeleted, null, null, null);
                return null;
              }), null);
        }
      }
      if (fileChanged != null)
      {
        foreach (NotifyFileItemDelegate callback in _callbacks)
        {
          // The file system watcher runs in another thread --> Dispatch to the main UI thread
          Application.Current.Dispatcher.Invoke(DispatcherPriority.Background,
              new DispatcherOperationCallback(delegate
              {
                callback(null, null, GetFileItem(fileChanged), null, null);
                return null;
              }), null);
        }
      }
      if (fileOldName != null && fileNewName != null)
      {
        foreach (NotifyFileItemDelegate callback in _callbacks)
        {
          // The file system watcher runs in another thread --> Dispatch to the main UI thread
          Application.Current.Dispatcher.Invoke(DispatcherPriority.Background,
              new DispatcherOperationCallback(delegate
              {
                callback(null, null, null, fileOldName, fileNewName);
                return null;
              }), null);
        }
      }
    }

    private FileItem GetFileItem(FileInfo file)
    {
      // This is just a utility method
      FileItem item = new FileItem();
      item.Name = file.Name;
      item.FullPath = file.FullName;
      item.DateChanged = file.LastWriteTime;
      item.Size = file.Length / 1000;
      return item;
    }

    #region IDisposable Members

    public void Dispose()
    {
      // Clean up
      if (_networkObject != null)
      {
        _networkObject.Dispose();
      }
    }

    #endregion
  }
}
