using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Input;
using WpfTests.BestPractices.Interfaces;
using WpfTests.BestPractices.MyPlugIn.UIDataLayer;

namespace WpfTests.BestPractices.MyPlugIn
{
  /// <summary>
  /// This is our Plug-In implementation.
  /// It is deriving from PlugInBase, which offers some shared functionality.
  /// It also implements IPlugIn and IDisposable, which is a requirement for the ApplicationFramework.
  /// Note that this will be checked during runtime, and an exception will be thrown
  /// if the Plug-In doesn't implement these two interfaces.
  /// 
  /// The Plug-In doesn't know anything about design mode, test mode or runtime mode. This
  /// is all handled by the FileDataProvider in the UIDataLayer.
  /// </summary>
  public partial class MyPlugIn : PlugInBase
  {
    /// <summary>
    /// This is the path to the directory which will be watched. Setting this value will cause
    /// the current watcher to be disposed and a new watcher to be set up.
    /// Note: In design mode and in test mode, setting this value has no effect.
    /// </summary>
    public string StartDirectoryPath
    {
      set
      {
        ObjectDataProvider dataProvider = TryFindResource("MyObjectDataProvider") as ObjectDataProvider;
        FileDataProvider fileProvider = dataProvider.ObjectInstance as FileDataProvider;
        fileProvider.StartDirectory = value;
      }
    }

    public MyPlugIn()
    {
      InitializeComponent();
      StartDirectoryPath = DirectoryNameTextBox.Text;
    }

    private void GoButton_Click(object sender, RoutedEventArgs e)
    {
      StatusBar.Text = "";
      StartDirectoryPath = DirectoryNameTextBox.Text;
    }

    private void DirectoryNameTextBox_KeyUp(object sender, KeyEventArgs e)
    {
      // Detect Enter key in textbox, loads the new directory
      if (e.Key == Key.Enter)
      {
        GoButton_Click(sender, null);
      }
    }

    private void ListBox_ButtonClick(object sender, RoutedEventArgs e)
    {
      if (!(e.OriginalSource is Button))
      {
        // Don't handle events coming from other controls
        return;
      }
      try
      {
        FileItem item = (e.OriginalSource as Button).DataContext as FileItem;
        StatusBar.Text = string.Format("You selected {0}", item.Name);
        e.Handled = true;
      }
      catch (InvalidCastException)
      {
        // Shouldn't happen but better safe than sorry...
      }
      catch (NullReferenceException)
      {
        // This is thrown if the DataContext is null --> wrong button
        // (for example, the scrollbars' buttons
      }
    }

    private void CloseButton_Click(object sender, RoutedEventArgs e)
    {
      OnCloseRequested(this, new CloseRequestedEventArgs(CloseRequestedEventArgs.ClosingReason.OhMyGodWeAreGoingToCrash));
    }

    #region IPlugIn Members

    public override string Title
    {
      get { return "My FileWatcher Plug-In"; }
    }

    public override void Initialize()
    {
      StatusBar.Text = string.Format("Plug-In was initialized at {0}", DateTime.Now.ToLongTimeString());
    }

    public override void OnClosing()
    {
      this.Dispose();
    }

    #endregion

    #region IDisposable Members

    public override void Dispose()
    {
      ObjectDataProvider dataProvider = TryFindResource("MyObjectDataProvider") as ObjectDataProvider;
      FileDataProvider fileProvider = dataProvider.ObjectInstance as FileDataProvider;
      fileProvider.Dispose();
    }

    #endregion
  }
}