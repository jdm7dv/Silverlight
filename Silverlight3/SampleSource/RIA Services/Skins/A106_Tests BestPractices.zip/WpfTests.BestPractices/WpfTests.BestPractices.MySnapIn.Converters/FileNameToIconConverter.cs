using System;
using System.IO;
using System.Windows;
using System.Windows.Data;
using System.Windows.Media;

namespace WpfTests.BestPractices.MyPlugIn.Converters
{
  /// <summary>
  /// Converts an extension to an icon.
  /// </summary>
  public class FileNameToIconConverter : IMultiValueConverter
  {
    #region IMultiValueConverter Members

    /// <summary>
    /// We use a multibinding for this particular conversion, because the converter needs to use
    /// the TryFindResource method to localize the brush in the Skins' resource dictionary.
    /// TryFindResource requires a FrameworkElement as the starting point, and then will walk
    /// up the Visual Tree to find the desired resource.
    /// When using this converter, use a MultiBinding, and pass a reference to any FrameworkElement
    /// in the Plug-In as the first value.
    /// </summary>
    /// <param name="values">An array of values used for the conversion. The first value must be
    /// a reference to any FrameworkElement in the Plug-In, typically the element in which the
    /// binding is applied. For example:
    /// <code>
    /// &lt;MultiBinding Converter="{StaticResource FileNameToIconConverter}"&gt;
    ///     &lt;Binding RelativeSource="{RelativeSource Self}"/&gt;
    ///     &lt;Binding Path="Name"/&gt;
    /// &lt;/MultiBinding&gt;
    /// </code>
    /// The second value is the filename to convert.
    /// </summary>
    /// <returns>An icon corresponding to the extension of the file name.</returns>
    public object Convert(object[] values, Type targetType, object parameter, System.Globalization.CultureInfo culture)
    {
      FrameworkElement owner = values[0] as FrameworkElement;
      string fileName = values[1] as string;

      // Get extension and remove leading '.'
      string extension = Path.GetExtension(fileName);
      if (extension.Length > 1)
      {
        extension = extension.Substring(1);
      }
      DrawingImage icon = owner.TryFindResource(extension) as DrawingImage;
      if (icon != null)
      {
        return icon;
      }

      icon = owner.TryFindResource("unknown") as DrawingImage;
      return icon;
    }

    public object[] ConvertBack(object value, Type[] targetTypes, object parameter, System.Globalization.CultureInfo culture)
    {
      throw new Exception("The method or operation is not implemented.");
    }

    #endregion
  }
}
