using System;
using System.Windows.Data;

namespace WpfTests.BestPractices.MyPlugIn.Converters
{
  public class DateTimeToStringConverter : IValueConverter
  {
    #region IValueConverter Members

    public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
    {
      DateTime dateTime = (DateTime) value;
      return dateTime.ToShortDateString() + " " + dateTime.ToShortTimeString();
    }

    public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
    {
      throw new Exception("The method or operation is not implemented.");
    }

    #endregion
  }
}
