using System;
using System.Collections.Generic;
using System.IO;

namespace WpfTests.BestPractices.SomeService
{
  /// <summary>
  /// This simulates a network object with callbacks.
  /// Watches a directoy and sends notifications if a file is added, deleted, changed or renamed.
  /// Note: The notifications sent by this object come from a background thread!
  /// </summary>
  public class DataSource : IDisposable
  {
    public delegate void NotifyDelegate(FileInfo fileAdded,
        string fileDeleted,
        FileInfo fileChanged,
        string fileOldName,
        string fileNewName);

    List<NotifyDelegate> _callbacks = new List<NotifyDelegate>();

    FileSystemWatcher _watcher;
    DirectoryInfo _startDirectory;

    public DataSource(DirectoryInfo directory)
    {
      _watcher = new FileSystemWatcher();
      _watcher.Path = directory.FullName;
      _watcher.Filter = "*.*";
      _watcher.NotifyFilter = (NotifyFilters.LastWrite | NotifyFilters.FileName);

      _watcher.Created += new FileSystemEventHandler(watcher_Created);
      _watcher.Deleted += new FileSystemEventHandler(watcher_Deleted);
      _watcher.Renamed += new RenamedEventHandler(watcher_Renamed);
      _watcher.Changed += new FileSystemEventHandler(_watcher_Changed);
      _startDirectory = directory;

      _watcher.EnableRaisingEvents = true;
    }

    void _watcher_Changed(object sender, FileSystemEventArgs e)
    {
      FileInfo changed = new FileInfo(e.FullPath);
      foreach (NotifyDelegate callback in _callbacks)
      {
        callback(null, null, changed, null, null);
      }
    }

    void watcher_Renamed(object sender, RenamedEventArgs e)
    {
      foreach (NotifyDelegate callback in _callbacks)
      {
        callback(null, null, null, e.OldName, e.Name);
      }
    }

    void watcher_Deleted(object sender, FileSystemEventArgs e)
    {
      foreach (NotifyDelegate callback in _callbacks)
      {
        callback(null, e.Name, null, null, null);
      }
    }

    void watcher_Created(object sender, FileSystemEventArgs e)
    {
      FileInfo created = new FileInfo(e.FullPath);
      foreach (NotifyDelegate callback in _callbacks)
      {
        callback(created, null, null, null, null);
      }
    }

    public void RegisterForChanges(NotifyDelegate callback)
    {
      _callbacks.Add(callback);
    }

    public void GetInitialDataNotifications(NotifyDelegate callback)
    {
      FileInfo[] files = _startDirectory.GetFiles();
      foreach (FileInfo file in files)
      {
        callback(file, null, null, null, null);
      }
    }

    #region IDisposable Members

    public void Dispose()
    {
      // Clean up
      if (_watcher != null)
      {
        _watcher.Dispose();
      }
    }

    #endregion
  }
}
