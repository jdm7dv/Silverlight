namespace WpfTests.BestPractices.Interfaces
{
  /// <summary>
  /// Simulates a Plug-In interface.
  /// </summary>
  public interface IPlugIn
  {
    /// <summary>
    /// The Plug-In's title.
    /// </summary>
    string Title
    {
      get;
    }

    /// <summary>
    /// Called by the framework when the Plug-In is loaded.
    /// </summary>
    void Initialize();
    /// <summary>
    /// Called by the framework when the Plug-In must be closed,
    /// for example when the application is shutting down.
    /// Use this method for cleaning up.
    /// </summary>
    void OnClosing();
  }
}
