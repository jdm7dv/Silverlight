using System;
using System.ComponentModel;
using System.Windows;
using System.Windows.Controls;

namespace WpfTests.BestPractices.Interfaces
{
  /// <summary>
  /// This is the basis class for the Plug-Ins which the Application Framework can
  /// load. For simplicity's sake, this simulation application does not use IPlugInManifest.
  /// </summary>
  public class PlugInBase : UserControl, IPlugIn, IDisposable
  {
    // This section shows best practice to declare RoutedEvents in WPF.

    // 1. Make the RoutedEvent static readonly
    // 2. Register the routed event.
    // Declare bubbling event,
    // If wanted, declare a corresponding tunneling event with prefix "Preview".
    public static readonly RoutedEvent CloseRequestedEvent = EventManager.RegisterRoutedEvent("CloseRequested",
        RoutingStrategy.Bubble,
        typeof(CloseRequestedEventHandler),
        typeof(PlugInBase));

    public delegate void CloseRequestedEventHandler(PlugInBase sender, CloseRequestedEventArgs e);

    // 3. Provide CLR accessors add and remove for the RoutedEvent. This allows using "+=" and "-=" as shortcuts
    public event CloseRequestedEventHandler CloseRequested
    {
      add
      {
        AddHandler(CloseRequestedEvent, value);
      }
      remove
      {
        RemoveHandler(CloseRequestedEvent, value);
      }
    }

    // 4. Provide a "On<EventName>" method, which can be overriden.
    // 5. Raise the Tunneling event first (if available), then the Buibbling event.
    protected virtual void OnCloseRequested(PlugInBase sender, CloseRequestedEventArgs e)
    {
      e.RoutedEvent = CloseRequestedEvent;
      RaiseEvent(e);
    }

    // Make sure that Plug-Ins implement the needed interfaces
    public PlugInBase()
    {
      if (!DesignerProperties.GetIsInDesignMode(this))
      {
        // Blend attempts to create an instance of PlugInBase, which shouldn't be allowed
        if (!(this is IPlugIn)
            || !(this is IDisposable))
        {
          throw new ApplicationException(string.Format("The Plug-In {0} does not implement IPlugIn or IDisposable", this.GetType().Name));
        }
      }
    }

    // Not a DependencyProperty, because this doesn't change during runtime
    public bool IsInDesignMode
    {
      get
      {
        return DesignerProperties.GetIsInDesignMode(this);
      }
    }
    public bool IsInRuntimeMode
    {
      get
      {
        return !IsInDesignMode;
      }
    }

    #region IPlugIn Members

    public virtual string Title
    {
      get { throw new Exception("The method or operation is not implemented."); }
    }

    public virtual void Initialize()
    {
      throw new Exception("The method or operation is not implemented.");
    }

    public virtual void OnClosing()
    {
      throw new Exception("The method or operation is not implemented.");
    }

    #endregion

    #region IDisposable Members

    public virtual void Dispose()
    {
      throw new Exception("The method or operation is not implemented.");
    }

    #endregion
  }

  // 6. Declare an EventArgs for the RoutedEvent
  public class CloseRequestedEventArgs : RoutedEventArgs
  {
    public enum ClosingReason
    {
      NoReason = 0,
      OhMyGodWeAreGoingToCrash = 1,
    }

    private ClosingReason _reason = ClosingReason.NoReason;

    public ClosingReason Reason
    {
      get { return _reason; }
      set { _reason = value; }
    }

    public CloseRequestedEventArgs(ClosingReason reason)
    {
      _reason = reason;
    }
  }
}
