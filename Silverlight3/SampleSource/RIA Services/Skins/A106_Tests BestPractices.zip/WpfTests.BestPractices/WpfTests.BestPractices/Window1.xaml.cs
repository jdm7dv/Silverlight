using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using WpfTests.BestPractices.Interfaces;
using WpfTests.BestPractices.MyPlugIn.UIDataLayer;

#if DEBUG
using WpfTests.BestPractices.MyPlugIn.UITestLogicLayer;
#endif

namespace WpfTests.BestPractices
{
  /// <summary>
  /// This is a test window only.
  /// It loads and initializes the Plug-In, but not dynamically 
  /// like the ApplicationFramework does.
  /// It also provides a test UI (on the bottom) to check how the UI reacts in
  /// various conditions.
  /// </summary>
  public partial class Window1 : System.Windows.Window
  {
    FileDataProvider _fileProvider;

#if DEBUG
    private TestObject _testObject;
#endif

    // We bind to these 2 CLR properties to enable/disable the test UI.
    public bool IsReleaseVersion
    {
      get
      {
#if DEBUG
        return false;
#else
                return true;
#endif
      }
    }
    public bool IsDebugVersion
    {
      get { return !IsReleaseVersion; }
    }

    public Window1()
    {
      InitializeComponent();

      // Make sure that the Plug-In is notified when the application closes.
      this.Closing += new System.ComponentModel.CancelEventHandler(Window1_Closing);

      // In the GMS application, the Plug-Ins are loaded dynamically.
      // In this simple test application, this is not the case.
      IPlugIn plugIn = MyPlugIn as IPlugIn;
      this.Title = plugIn.Title + " [TEST VERSION]";
      plugIn.Initialize();

      PlugInBase plugInAsBase = MyPlugIn;
      plugInAsBase.CloseRequested += new PlugInBase.CloseRequestedEventHandler(plugInAsBase_CloseRequested);

      // Save file provider for later.
      ObjectDataProvider dataProvider = MyPlugIn.TryFindResource("MyObjectDataProvider") as ObjectDataProvider;
      _fileProvider = dataProvider.ObjectInstance as FileDataProvider;

      CheckTestMode();
    }

    void plugInAsBase_CloseRequested(PlugInBase sender, CloseRequestedEventArgs e)
    {
      // The event comes from one of the hosted Plug-Ins --> shutdown application but ask user first
      MessageBoxResult result = MessageBox.Show(string.Format("One Plug-In of type {0} requested shutdown; reason: {1}",
          sender.GetType().Name, e.Reason.ToString()),
          "Shutdown?",
          MessageBoxButton.OKCancel);

      if (result == MessageBoxResult.OK)
      {
        Application.Current.Shutdown();
      }
    }

    void Window1_Closing(object sender, System.ComponentModel.CancelEventArgs e)
    {
      // Make sure that the Plug-In is notified when the application closes.
      IPlugIn plugIn = MyPlugIn as IPlugIn;
      plugIn.OnClosing();
    }

    private void TestModeCheckBox_Click(object sender, RoutedEventArgs e)
    {
      // Put Plug-In in test mode or in runtime mode.
      CheckTestMode();
    }

    private void CheckTestMode()
    {
      bool isInTestMode = TestModeCheckBox.IsChecked == true;

      // First add or remove bindings to avoid unecessary display of items.
      // Bind ListBox in Test UI to FileDataProvider running in the UserControl
      if (isInTestMode)
      {
        Binding testFilesBinding = new Binding();
        testFilesBinding.Source = _fileProvider;
        testFilesBinding.Path = new PropertyPath("Files");
        TestFilesListBox.SetBinding(ListBox.ItemsSourceProperty, testFilesBinding);
      }
      else
      {
        BindingOperations.ClearBinding(TestFilesListBox, ListBox.ItemsSourceProperty);
      }

      // Then set the provider in the desired mode, which will "hook" to the BusinessObject or
      // to the TestObject, depending on test mode or runtime mode.
      _fileProvider.IsInTestMode = isInTestMode;

#if DEBUG
      // Finally, get an instance of the Test Object to store locally.
      // The TestDataObject gets destroyed when the application is not in test mode
      // --> must get a new instance when mode changes.
      // Use the static method provided by the TestDataObject class.
      _testObject = TestObject.Get(_fileProvider);
#endif
    }

    private void AddItemsButton_Click(object sender, RoutedEventArgs e)
    {
#if DEBUG
      // Test UI in special conditions.
      // In this simple application, no check is done for format error
      _testObject.AddFileItems(Int32.Parse(AddDeleteItemTextBox.Text));
#endif
    }

    private void RemoveItemsButton_Click(object sender, RoutedEventArgs e)
    {
#if DEBUG
      // Test UI in special conditions.
      // In this simple application, no check is done for format error
      _testObject.RemoveFileItems(Int32.Parse(AddDeleteItemTextBox.Text));
#endif
    }
  }
}