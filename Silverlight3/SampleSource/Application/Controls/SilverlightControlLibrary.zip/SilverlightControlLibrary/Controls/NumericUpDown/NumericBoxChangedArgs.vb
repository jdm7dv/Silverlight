﻿Namespace NumericUpDown
    Public Delegate Sub NumericBoxChangedHandler(ByVal sender As Object, ByVal e As NumericBoxChangedArgs)

    Public Class NumericBoxChangedArgs
        Inherits EventArgs

        Private ReadOnly _val As Integer

        Public Sub New(ByVal val As Integer)
            _val = val
        End Sub

        Public ReadOnly Property Value() As Integer
            Get
                Return _val
            End Get
        End Property

    End Class
End Namespace
