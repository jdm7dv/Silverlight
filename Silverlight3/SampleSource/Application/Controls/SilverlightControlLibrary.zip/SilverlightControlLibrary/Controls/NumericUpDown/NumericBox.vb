﻿Namespace NumericUpDown
    Public Class NumericBox
        Inherits Control

        Private _ValueUpdated As Boolean = False

        Public Sub New()
            DefaultStyleKey = GetType(NumericBox)
        End Sub

        Private TBxNum As TextBox
        Private ButUp As Button
        Private ButDw As Button


        Public Overloads Overrides Sub OnApplyTemplate()
            MyBase.OnApplyTemplate()

            TBxNum = CType(MyBase.GetTemplateChild("NumericTextBox"), TextBox)
            ButUp = CType(MyBase.GetTemplateChild("ValUp"), Button)
            ButDw = CType(MyBase.GetTemplateChild("ValDown"), Button)

            If TBxNum Is Nothing Then Return

            If ButUp Is Nothing Then Return

            If ButDw Is Nothing Then Return

            AddHandler TBxNum.TextChanged, AddressOf TBxNum_TextChanged
            AddHandler TBxNum.KeyDown, AddressOf TBxNum_KeyDown
            AddHandler ButUp.Click, AddressOf ButUp_Click
            AddHandler ButDw.Click, AddressOf ButDw_Click
        End Sub


        Private Sub TBxNum_TextChanged(ByVal sender As Object, ByVal e As TextChangedEventArgs)
            If (Single.IsNaN(System.Convert.ToSingle(TBxNum.Text))) Then
                Throw New NotFiniteNumberException(TBxNum.Text)
            Else
                UpdateValue(CType(TBxNum.Text, Integer))
            End If
        End Sub

        Private Sub TBxNum_KeyDown(ByVal sender As Object, ByVal e As KeyEventArgs)
            If ((e.Key >= Key.D0 And e.Key <= Key.D9) OrElse (e.Key >= Key.NumPad0 And e.Key <= Key.NumPad9) _
                OrElse e.Key = Key.Back) Then e.Handled = False Else e.Handled = True
        End Sub

        Private Sub ButUp_Click(ByVal sender As Object, ByVal e As RoutedEventArgs)
            UpdateValue(Value + 1)
        End Sub

        Private Sub ButDw_Click(ByVal sender As Object, ByVal e As RoutedEventArgs)
            UpdateValue(Value - 1)
        End Sub

        Public Event NumericBoxChanged As NumericBoxChangedHandler

        Private Sub UpdateValue(ByVal val As Integer)
            _ValueUpdated = False
            Value = val
            If _ValueUpdated Then
                TBxNum.Text = val
                Dim NArgs As New NumericBoxChangedArgs(Value)
                RaiseEvent NumericBoxChanged(Me, NArgs)
            End If
        End Sub


#Region "Dependency Properties"

        Public Property Minimum()
            Get
                Return GetValue(MinimumProperty)
            End Get
            Set(ByVal value)
                SetValue(MinimumProperty, value)
            End Set
        End Property

        Public Shared MinimumProperty As DependencyProperty = _
        DependencyProperty.Register("Minimum", GetType(Integer), GetType(NumericBox), _
                                New PropertyMetadata(0, New PropertyChangedCallback(AddressOf MinimumValueChanged)))



        Public Property Maximum()
            Get
                Return GetValue(MaximumProperty)
            End Get
            Set(ByVal value)
                SetValue(MaximumProperty, value)
            End Set
        End Property

        Public Shared MaximumProperty As DependencyProperty = _
        DependencyProperty.Register("Maximum", GetType(Integer), GetType(NumericBox), _
                                    New PropertyMetadata(10, New PropertyChangedCallback(AddressOf MaximumValueChanged)))


        Public Property Value()
            Get
                Return GetValue(ValueProperty)
            End Get
            Set(ByVal value)
                SetValue(ValueProperty, value)
            End Set
        End Property

        Public Shared ValueProperty As DependencyProperty = _
        DependencyProperty.Register("Value", GetType(Integer), GetType(NumericBox), _
                                    New PropertyMetadata(0, New PropertyChangedCallback(AddressOf ValueChanged)))
        Private Shared Sub MinimumValueChanged(ByVal sender As DependencyObject, ByVal e As DependencyPropertyChangedEventArgs)

            Dim NB As NumericBox = CType(sender, NumericBox)
            Dim Val As Integer = CType(e.NewValue, Integer)

            If NB Is Nothing Then Return

            If Val >= NB.Maximum Then NB.Minimum = CType(e.OldValue, Integer)

            If Val > NB.Value Then NB.Value = Val

        End Sub

        Private Shared Sub MaximumValueChanged(ByVal sender As DependencyObject, ByVal e As DependencyPropertyChangedEventArgs)

            Dim NB As NumericBox = CType(sender, NumericBox)
            Dim Val As Integer = CType(e.NewValue, Integer)

            If NB Is Nothing Then Return

            If Val <= NB.Minimum Then NB.Maximum = CType(e.OldValue, Integer)

            If Val < NB.Value Then NB.Value = Val

        End Sub

        Private Shared Sub ValueChanged(ByVal sender As DependencyObject, ByVal e As DependencyPropertyChangedEventArgs)

            Dim NB As NumericBox = CType(sender, NumericBox)
            Dim Val As Integer = CType(e.NewValue, Integer)

            If NB Is Nothing Then Return

            If Val < NB.Minimum Then
                NB.Value = NB.Minimum
                NB._ValueUpdated = False
                Return
            End If

            If Val > NB.Maximum Then
                NB.Value = NB.Maximum
                NB._ValueUpdated = False
                Return
            End If

            NB._ValueUpdated = True
        End Sub

#End Region
    End Class
End Namespace