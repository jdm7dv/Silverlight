﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace CS_Controls.NumericUpDown
{
    public delegate void NumericBoxChangedHandler(object sender, NumericBoxChangedArgs e);

    public class NumericBoxChangedArgs : EventArgs
    {
        private readonly int _Value;

        public NumericBoxChangedArgs(int val)
        {
            _Value = val;
        }

        public int Value
        {
            get
            {
                return _Value;
            }
        }
    }
}
