﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace CS_Controls.NumericUpDown
{

    public class NumericBox: Control
    {
        
        private bool _ValueChanged= false;
        
        public NumericBox()
        {
            DefaultStyleKey = typeof(NumericBox);
        }

        private TextBox TBxNum;
        private Button ButUp;
        private Button ButDw;

        public override void OnApplyTemplate()
        {
            base.OnApplyTemplate();

            TBxNum = base.GetTemplateChild("NumericTextBox") as TextBox;
            ButUp = base.GetTemplateChild("ValUp") as Button;
            ButDw = base.GetTemplateChild("ValDown") as Button;

            if (TBxNum == null)
                return;

            if (ButUp == null)
                return;

            if (ButDw == null)
                return;

            TBxNum.TextChanged += new TextChangedEventHandler(TBxNum_TextChanged);
            TBxNum.KeyDown += new KeyEventHandler(TBxNum_KeyDown);
            ButUp.Click += new RoutedEventHandler(ButUp_Click);
            ButDw.Click += new RoutedEventHandler(ButDw_Click);
        }

        void TBxNum_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (Single.IsNaN(System.Convert.ToSingle(TBxNum.Text)))
                throw new NotFiniteNumberException(TBxNum.Text);
            else
               UpdateValue((int)System.Convert.ToInt64(TBxNum.Text));
        }

        void TBxNum_KeyDown(object sender, KeyEventArgs e)
        {
            if (((e.Key >= Key.D0 && e.Key <= Key.D9) || (e.Key >= Key.NumPad0 && e.Key <= Key.NumPad9) || e.Key == Key.Back))
                e.Handled = false;
            else
            {
                e.Handled = true;
            }
        }

        void ButUp_Click(object sender, RoutedEventArgs e)
        {
            UpdateValue(Value + 1);
        }

        void ButDw_Click(object sender, RoutedEventArgs e)
        {
            UpdateValue(Value - 1);
        }

        public event NumericBoxChangedHandler NumericBoxChanged;

        void UpdateValue(int val)
        {
            _ValueChanged  = false;
            Value = val;
            if(_ValueChanged) 
            {
                TBxNum.Text = Value.ToString();
                NumericBoxChangedArgs NArgs = new NumericBoxChangedArgs(Value);
                NumericBoxChanged(this, NArgs);
            }
        }


 #region Dependency Properties
        public int Minimum
        {
            get { return (int)GetValue(MinimumProperty); }
            set { SetValue(MinimumProperty, value); }
        }

        public static readonly DependencyProperty MinimumProperty =
            DependencyProperty.Register("Minimum", typeof(int), typeof(NumericBox), 
            new PropertyMetadata(0, new PropertyChangedCallback(MinimumChanged)));

        public int Maximum
        {
            get { return (int)GetValue(MaximumProperty); }
            set { SetValue(MaximumProperty, value); }
        }

        public static readonly DependencyProperty MaximumProperty =
            DependencyProperty.Register("Maximum", typeof(int), typeof(NumericBox), 
            new PropertyMetadata(10, new PropertyChangedCallback(MaximumChanged)));

        public int Value
        {
            get { return (int)GetValue(ValueProperty); }
            set { SetValue(ValueProperty, value); }
        }

        public static readonly DependencyProperty ValueProperty =
            DependencyProperty.Register("Value", typeof(int), typeof(NumericBox),
            new PropertyMetadata(0, new PropertyChangedCallback(ValueChanged)));

        private static void MinimumChanged(DependencyObject sender, DependencyPropertyChangedEventArgs e)
        {
            NumericBox NB = sender as NumericBox;

            int val = (int)e.NewValue;

            if (NB == null)
                return;

            if (val > NB.Maximum)
                NB.Minimum = (int)e.OldValue;

            if (NB.Value < val)
                NB.Value = val;
        }

        private static void MaximumChanged(DependencyObject sender, DependencyPropertyChangedEventArgs e)
        {
            NumericBox NB = sender as NumericBox;

            int val = (int)e.NewValue;

            if (NB == null)
                return;

            if (val < NB.Minimum)
                NB.Maximum = (int)e.OldValue;
        }

        private static void ValueChanged(DependencyObject sender, DependencyPropertyChangedEventArgs e)
        {
            NumericBox NB = sender as NumericBox;
            int val = (int)e.NewValue;
            NB._ValueChanged = false;
            if (NB == null)
                return;

            if (val < NB.Minimum)
            {
                NB.Value = NB.Minimum;
                NB._ValueChanged = false;
                return;
            }

            if (val > NB.Maximum)
            {
                NB.Value = NB.Maximum;
                NB._ValueChanged = false;
                return;
            }
            NB._ValueChanged = true;    
        }

 #endregion


    }
}
