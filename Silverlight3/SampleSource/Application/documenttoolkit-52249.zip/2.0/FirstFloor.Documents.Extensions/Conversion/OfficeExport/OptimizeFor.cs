﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace OfficeExport
{
    /// <summary>
    /// Specifies whether to optimize for screen or print.
    /// </summary>
    public enum OptimizeFor
    {
        /// <summary>
        /// Export for screen, which is a lower quality and results in a smaller file size.
        /// </summary>
        Screen,
        /// <summary>
        /// Export for print, which is higher quality and results in a larger file size.
        /// </summary>
        Print
    }
}
