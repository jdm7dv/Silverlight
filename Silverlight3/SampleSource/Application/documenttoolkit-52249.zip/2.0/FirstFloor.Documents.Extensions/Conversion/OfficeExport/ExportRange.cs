﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace OfficeExport
{
    /// <summary>
    /// Specifies the export range of the document.
    /// </summary>
    public enum ExportRange
    {
        /// <summary>
        /// Exports the entire document.
        /// </summary>
        AllDocument,
        /// <summary>
        /// Exports the contents of a range using the starting and ending positions.
        /// </summary>
        FromTo
    }
}
