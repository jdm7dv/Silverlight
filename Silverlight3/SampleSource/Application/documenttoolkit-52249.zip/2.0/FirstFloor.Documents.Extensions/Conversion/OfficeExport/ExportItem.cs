﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace OfficeExport
{
    /// <summary>
    /// Specifies whether the export process includes text only or includes text with markup.
    /// </summary>
    public enum ExportItem
    {
        /// <summary>
        /// Exports the document without markup.
        /// </summary>
        DocumentContent,
        /// <summary>
        /// Exports the document with markup.
        /// </summary>
        DocumentWithMarkup
    }
}
