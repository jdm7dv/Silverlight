﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace OfficeExport
{
    /// <summary>
    /// Provides the generic base class for office exporters.
    /// </summary>
    public abstract class Exporter<T>
        : ExporterBase where T : ExportSettings
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="Exporter&lt;T&gt;"/> class.
        /// </summary>
        protected Exporter()
        {
            this.Settings = CreateSettings();
        }

        /// <summary>
        /// Creates an instance of the export settings.
        /// </summary>
        /// <returns></returns>
        protected abstract T CreateSettings();

        /// <summary>
        /// Gets the export settings.
        /// </summary>
        /// <value>The settings.</value>
        public T Settings { get; private set; }

        /// <summary>
        /// Gets the preferred file extension for the current export format.
        /// </summary>
        /// <value>The preferred file extension.</value>
        public override string PreferredFileExtension
        {
            get
            {
                if (this.Settings.Format == ExportFormat.Pdf) {
                    return ".pdf";
                }
                if (this.Settings.Format == ExportFormat.Xps) {
                    return ".xps";
                }

                throw new NotSupportedException();
            }
        }
    }
}
