﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace OfficeExport
{
    /// <summary>
    /// Identifies the export format.
    /// </summary>
    public enum ExportFormat
    {
        /// <summary>
        /// PDF
        /// </summary>
        Pdf,
        /// <summary>
        /// XPS
        /// </summary>
        Xps
    }
}
