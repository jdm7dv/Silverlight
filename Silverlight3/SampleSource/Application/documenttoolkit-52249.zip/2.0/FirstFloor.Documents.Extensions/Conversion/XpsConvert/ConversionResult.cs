﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace XpsConvert
{
    /// <summary>
    /// Represents the result of the conversion.
    /// </summary>
    public class ConversionResult
    {
        /// <summary>
        /// Gets the list of converted images.
        /// </summary>
        public IEnumerable<Uri> ConvertedImageUris { get; set; }
    }
}
