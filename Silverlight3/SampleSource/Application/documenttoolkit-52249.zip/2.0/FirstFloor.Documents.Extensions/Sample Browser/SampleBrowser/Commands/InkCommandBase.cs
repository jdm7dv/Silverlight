﻿using System;
using System.Windows.Markup;
using System.Windows.Media;

using FirstFloor.Documents.Annotations;
using FirstFloor.Documents.Controls;
using FirstFloor.Documents.Controls.Commands;
using SampleBrowser.Annotations;
using System.Windows;
using System.ComponentModel;

namespace SampleBrowser.Commands
{
    /// <summary>
    /// Represents the base command for ink operations.
    /// </summary>
    public abstract class InkCommandBase
        : CommandBase
    {
        /// <summary>
        /// Identifies the InkEditorSettings dependency property.
        /// </summary>
        public static readonly DependencyProperty InkEditorSettingsProperty = DependencyProperty.Register("InkEditorSettings", typeof(InkEditorSettings), typeof(InkCommandBase), new PropertyMetadata(new PropertyChangedCallback(OnInkEditorSettingsChanged)));

        private static void OnInkEditorSettingsChanged(DependencyObject o, DependencyPropertyChangedEventArgs e)
        {
            ((InkCommandBase)o).OnInkEditorSettingsChanged((InkEditorSettings)e.OldValue, (InkEditorSettings)e.NewValue);
        }

        private void OnInkEditorSettingsChanged(InkEditorSettings oldValue, InkEditorSettings newValue)
        {
            if (oldValue != null) {
                oldValue.PropertyChanged -= OnInkEditorSettingsPropertyChanged;
            }
            if (newValue != null){
                newValue.PropertyChanged += OnInkEditorSettingsPropertyChanged;
            }

            OnCanExecuteChanged();
        }

        private void OnInkEditorSettingsPropertyChanged(object sender, PropertyChangedEventArgs e)
        {
            OnCanExecuteChanged();
        }

        /// <summary>
        /// Gets or sets the Ink editor settings.
        /// </summary>
        /// <value>The editor settings.</value>
        public InkEditorSettings InkEditorSettings
        {
            get { return (InkEditorSettings)GetValue(InkEditorSettingsProperty); }
            set { SetValue(InkEditorSettingsProperty, value); }
        }

        /// <summary>
        /// Defines the method that determines whether the command can execute in its current state.
        /// </summary>
        /// <param name="parameter">Data used by the command. If the command does not require data to be passed, this object can be set to null.</param>
        /// <returns>
        /// true if this command can be executed; otherwise, false.
        /// </returns>
        public override bool CanExecute(object parameter)
        {
            return this.InkEditorSettings != null;
        }
    }
}
