﻿using System;
using System.Windows.Markup;
using System.Windows.Media;

using FirstFloor.Documents.Annotations;
using FirstFloor.Documents.Controls;
using FirstFloor.Documents.Controls.Commands;
using SampleBrowser.Annotations;

namespace SampleBrowser.Commands
{
    /// <summary>
    /// The command that underlines the current text selection.
    /// </summary>
    public class UnderlineCommand
        : SelectionCommand
    {
        /// <summary>
        /// Gets a value indicating whether this command requires text to be selected.
        /// </summary>
        /// <value>
        /// 	<c>true</c> if this command requires selected text; otherwise, <c>false</c>.
        /// </value>
        protected override bool RequiresSelectedText
        {
            get { return true; }
        }
        /// <summary>
        /// Implements the actual command execution.
        /// </summary>
        /// <param name="parameter">The parameter.</param>
        protected override void OnExecute(object parameter)
        {
            Color? color = parameter as Color?;
            if (color == null) {
                color = ColorHelper.ColorFromString(parameter as string);
            }

            var service = AnnotationService.GetService(this.Selection.TextContainer);
            if (service != null && service.IsEnabled) {
                Underline.CreateUnderlineForSelection(service, color);
                this.Selection.Unselect();
            }
        }
    }
}
