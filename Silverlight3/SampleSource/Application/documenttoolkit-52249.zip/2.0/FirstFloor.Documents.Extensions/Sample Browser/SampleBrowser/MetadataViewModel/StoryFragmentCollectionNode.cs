﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Windows.Media;

using FirstFloor.Documents;
using FirstFloor.Documents.DocumentStructures;

namespace SampleBrowser.MetadataViewModel
{
    /// <summary>
    /// Represents the storyfragment collection node.
    /// </summary>
    public class StoryFragmentCollectionNode
        : Node
    {
        private PageContent page;

        /// <summary>
        /// Initializes a new instance of the <see cref="StoryFragmentCollectionNode"/> class.
        /// </summary>
        /// <param name="page">The page.</param>
        /// <param name="options">The options.</param>
        public StoryFragmentCollectionNode(PageContent page, ViewModelOptions options)
            : base(options)
        {
            this.page = page;
            this.page.PropertyChanged += page_PropertyChanged;
        }

        private void page_PropertyChanged(object sender, PropertyChangedEventArgs e)
        {
            if (e.PropertyName == "StoryFragments") {
                //ensure UI gets updated
                OnPropertyChanged("Text");
                OnPropertyChanged("Children");      
            }
        }

        /// <summary>
        /// Gets the page that is associated with this node instace.
        /// </summary>
        /// <value>The page.</value>
        public override PageContent Page
        {
            get { return this.page; }
        }

        /// <summary>
        /// Gets the text.
        /// </summary>
        /// <value>The text.</value>
        public override string Text
        {
            get
            {
                if (this.page.StoryFragments == null) {
                    return string.Format("Story fragments ({0})", '?');
                }
                return string.Format("Story fragments ({0})", this.page.StoryFragments.Count());
            }
        }

        /// <summary>
        /// Gets the icon.
        /// </summary>
        /// <value>The icon uri.</value>
        public override string Icon
        {
            get { return "/SampleBrowser;component/Assets/Icons/script.png"; }
        }
        /// <summary>
        /// Gets the child nodes.
        /// </summary>
        /// <value>The nodes.</value>
        public override IEnumerable<Node> Children
        {
            get
            {
                if (this.page.StoryFragments != null) {
                    foreach (StoryFragment fragment in this.page.StoryFragments) {
                        yield return new StoryFragmentNode(this.page, fragment, this.Options);
                    }
                }
            }
        }
    }
}
