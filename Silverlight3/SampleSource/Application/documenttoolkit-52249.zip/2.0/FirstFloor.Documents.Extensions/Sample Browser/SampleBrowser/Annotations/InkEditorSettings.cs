﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.ComponentModel;

namespace SampleBrowser.Annotations
{
    /// <summary>
    /// Defines the ink editor settings.
    /// </summary>
    public class InkEditorSettings
        : INotifyPropertyChanged
    {
        /// <summary>
        /// Occurs when a property value changes.
        /// </summary>
        public event PropertyChangedEventHandler PropertyChanged;

        private bool isEnabled = false;
        private Color? strokeColor = Colors.Black;
        private double strokeHeight = 3;
        private double strokeWidth = 3;

        private void OnPropertyChanged(string propertyName)
        {
            if (PropertyChanged != null) {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }

        /// <summary>
        /// Gets or sets a value indicating whether this instance is enabled.
        /// </summary>
        /// <value>
        /// 	<c>true</c> if this instance is enabled; otherwise, <c>false</c>.
        /// </value>
        public bool IsEnabled
        {
            get { return this.isEnabled; }
            set
            {
                if (this.isEnabled != value){
                    this.isEnabled = value;
                    OnPropertyChanged("IsEnabled");
                }
            }
        }

        /// <summary>
        /// Gets or sets the Stroke color.
        /// </summary>
        /// <value>The current stroke.</value>
        public Color? StrokeColor
        {
            get { return this.strokeColor; }
            set
            {
                if (this.strokeColor != value) {
                    this.strokeColor = value;
                    OnPropertyChanged("StrokeColor");
                }
            }
        }

        /// <summary>
        /// Gets or sets the width of the stroke.
        /// </summary>
        /// <value>The width of the stroke.</value>
        public double StrokeWidth
        {
            get { return this.strokeWidth; }
            set
            {
                if (this.strokeWidth != value) {
                    this.strokeWidth = value;
                    OnPropertyChanged("StrokeWidth");
                }
            }
        }

        /// <summary>
        /// Gets or sets the height of the stroke.
        /// </summary>
        /// <value>The height of the stroke.</value>
        public double StrokeHeight
        {
            get { return this.strokeHeight; }
            set
            {
                if (this.strokeHeight != value) {
                    this.strokeHeight = value;
                    OnPropertyChanged("StrokeHeight");
                }
            }
        }
    }
}
