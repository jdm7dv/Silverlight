﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Media;

using FirstFloor.Documents;

namespace SampleBrowser.MetadataViewModel
{
    /// <summary>
    /// Represents an fixed document node.
    /// </summary>
    public class FixedDocumentNode
        : Node
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="FixedDocument"/> class.
        /// </summary>
        /// <param name="document">The document.</param>
        /// <param name="options">The options.</param>
        public FixedDocumentNode(FixedDocument document, ViewModelOptions options)
            : base(options)
        {
            this.Document = document;
        }

        /// <summary>
        /// Gets the text.
        /// </summary>
        /// <value>The text.</value>
        public override string Text
        {
            get { return string.Format("Document #{0}", this.Document.DocumentNumber); }
        }

        /// <summary>
        /// Gets the icon.
        /// </summary>
        /// <value>The icon uri.</value>
        public override string Icon
        {
            get { return "/SampleBrowser;component/Assets/Icons/book_open.png"; }
        }

        /// <summary>
        /// Gets a reference to the document.
        /// </summary>
        /// <value>The document.</value>
        public FixedDocument Document { get; private set; }

        /// <summary>
        /// Gets the child nodes.
        /// </summary>
        /// <value>The nodes.</value>
        public override IEnumerable<Node> Children
        {
            get
            {
                var structure = this.Document.DocumentStructure;
                if ((this.Options & ViewModelOptions.IncludeDocumentContent) > 0 && structure != null && structure.DocumentContent != null) {
                    yield return new DocumentContentNode(this.Document, this.Options);
                }
                if ((this.Options & ViewModelOptions.IncludeDocumentOutline) > 0 && structure != null && structure.DocumentOutline != null) {
                    yield return new OutlineNode(this.Document, this.Options);
                }
                if ((this.Options & ViewModelOptions.IncludeRelationships) > 0 && this.Document != null) {
                    yield return new RelationshipsCollectionNode(this.Page, this.Document, this.Options);
                }
                if ((this.Options & ViewModelOptions.IncludePages) > 0 && this.Document.Pages != null) {
                    yield return new PageCollectionNode(this.Document, this.Options);
                }
            }
        }

        /// <summary>
        /// Gets the page that is associated with this node instace.
        /// </summary>
        /// <value>The page.</value>
        public override PageContent Page
        {
            get
            {
                // first page;
                return this.Document.Pages.FirstOrDefault();
            }
        }
    }
}
