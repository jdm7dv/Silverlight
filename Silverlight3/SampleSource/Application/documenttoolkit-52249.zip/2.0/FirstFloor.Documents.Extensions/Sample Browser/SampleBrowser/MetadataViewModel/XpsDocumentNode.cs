﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Media;

using FirstFloor.Documents;

namespace SampleBrowser.MetadataViewModel
{
    /// <summary>
    /// Represents an XPS document node.
    /// </summary>
    public class XpsDocumentNode
        : Node
    {
        private string name;

        /// <summary>
        /// Initializes a new instance of the <see cref="XpsDocumentNode"/> class.
        /// </summary>
        /// <param name="document">The document.</param>
        /// <param name="name">The name.</param>
        /// <param name="options">The options.</param>
        public XpsDocumentNode(XpsDocument document, string name, ViewModelOptions options)
            : base(options)
        {
            this.Document = document;
            this.name = name;
        }

        /// <summary>
        /// Gets the document.
        /// </summary>
        /// <value>The document.</value>
        public XpsDocument Document { get; private set; }

        /// <summary>
        /// Gets the text.
        /// </summary>
        /// <value>The text.</value>
        public override string Text
        {
            get { return this.name; }
        }

        /// <summary>
        /// Gets the icon.
        /// </summary>
        /// <value>The icon uri.</value>
        public override string Icon
        {
            get { return "/SampleBrowser;component/Assets/Icons/package.png"; }
        }

        /// <summary>
        /// Gets the page that is associated with this node instace.
        /// </summary>
        /// <value>The page.</value>
        public override PageContent Page
        {
            get
            {
                // the first page of the first fixed document
                FixedDocument fixedDoc = this.Document.FixedDocumentSequence.FixedDocuments.FirstOrDefault();
                if (fixedDoc != null) {
                    return fixedDoc.Pages.FirstOrDefault();
                }
                return null;
            }
        }

        /// <summary>
        /// Gets the child nodes.
        /// </summary>
        /// <value>The nodes.</value>
        public override IEnumerable<Node> Children
        {
            get
            {
                if ((this.Options & ViewModelOptions.IncludeProperties) > 0) {
                    yield return new PropertyCollectionNode(this.Document.CoreDocumentProperties, this.Options);
                }

                if ((this.Options & ViewModelOptions.IncludeContentTypes) > 0) {
                    yield return new ContentTypeCollectionNode(this.Document, this.Options);
                }

                if ((this.Options & ViewModelOptions.IncludeRelationships) > 0 && this.Document.Relationships != null) {
                    yield return new RelationshipsCollectionNode(this.Page, this.Document, this.Options);
                }

                foreach (FixedDocument fixedDoc in this.Document.FixedDocumentSequence.FixedDocuments) {
                    yield return new FixedDocumentNode(fixedDoc, this.Options);
                }
            }
        }
    }
}
