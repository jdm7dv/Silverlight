﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

using FirstFloor.Documents;

namespace SampleBrowser.MetadataViewModel
{
    /// <summary>
    /// Represents a generic text node.
    /// </summary>
    public class TextNode
        : Node
    {
        private string text;

        /// <summary>
        /// Initializes a new instance of the <see cref="TextNode"/> class.
        /// </summary>
        /// <param name="text">The text.</param>
        public TextNode(string text)
            : base(ViewModelOptions.All)
        {
            this.text = text;
        }

        /// <summary>
        /// Gets the text.
        /// </summary>
        /// <value>The text.</value>
        public override string Text
        {
            get { return this.text; }
        }
    }
}
