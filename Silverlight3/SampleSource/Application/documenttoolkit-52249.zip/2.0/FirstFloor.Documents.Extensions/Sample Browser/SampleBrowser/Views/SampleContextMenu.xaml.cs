﻿using System;
using System.Windows.Controls;
using System.Windows.Navigation;
using FirstFloor.Documents.Annotations;
using FirstFloor.Documents.Annotations.Storage;
using FirstFloor.Documents.Controls;
using SharpZipLib;

namespace SampleBrowser.Views
{
    public partial class SampleContextMenu : Page
    {
        public SampleContextMenu()
        {
            InitializeComponent();

            // note: annotation service is required for highlight annotations to work properly

            // create an empty annotation store
            var annotations = new AnnotationStore();

            // enable annotation service
            var service = new AnnotationService(this.Viewer);
            service.Enable(annotations);


            this.Loaded += (o, e) => {
                this.DataSource.PackageReader = new SharpZipPackageReader(new Uri("Assets/Documents/WhitePaper.xps", UriKind.Relative));
            };
        }

        protected override void OnNavigatedFrom(NavigationEventArgs e)
        {
            base.OnNavigatedFrom(e);

            // properly clears the datasource and closes the package reader
            this.DataSource.PackageReader = null;
        }

        private void DataSource_LoadError(object sender, ErrorEventArgs e)
        {
            new ErrorWindow(e.Error).Show();
        }

    }
}
