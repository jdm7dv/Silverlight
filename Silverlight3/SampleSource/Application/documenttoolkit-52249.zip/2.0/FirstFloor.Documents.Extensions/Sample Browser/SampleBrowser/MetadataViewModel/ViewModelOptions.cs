﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace SampleBrowser.MetadataViewModel
{
    /// <summary>
    /// Defines a set of options that influence the behavior and visibility of nodes in the view model.
    /// </summary>
    [Flags]
    public enum ViewModelOptions
    {
        /// <summary>
        /// No options
        /// </summary>
        None = 0,
        /// <summary>
        /// Include the document properties.
        /// </summary>
        IncludeProperties = 1,
        /// <summary>
        /// Include the content types
        /// </summary>
        IncludeContentTypes = 2,
        /// <summary>
        /// Include the part relationships.
        /// </summary>
        IncludeRelationships = 4,
        /// <summary>
        /// Include the fixed document outline (aka table of contents).
        /// </summary>
        IncludeDocumentOutline = 8,
        /// <summary>
        /// Include the fixed document story nodes.
        /// </summary>
        IncludeDocumentContent = 16,
        /// <summary>
        /// Include page nodes.
        /// </summary>
        IncludePages = 32,
        /// <summary>
        /// Include page resource nodes (only visible when pages are included).
        /// </summary>
        IncludePageResources = 64,
        /// <summary>
        /// Include page link target nodes (only visible when pages are included).
        /// </summary>
        IncludePageLinkTargets = 128,
        /// <summary>
        /// Include page story fragment nodes (only visible when pages are included).
        /// </summary>
        IncludePageStoryFragments = 256,
        /// <summary>
        /// Enables all options.
        /// </summary>
        All = 511,
    }
}
