﻿using System;
using System.Collections.ObjectModel;
using System.Collections.Specialized;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Xml.Linq;

using FirstFloor.Documents.Annotations;
using FirstFloor.Documents.Annotations.Storage;

namespace SampleBrowser.Annotations
{
    /// <summary>
    /// Represents a freeform Ink annotation.
    /// </summary>
    /// <remarks>
    /// By definition only a single ink annotation exists per page. The annotation renders an InkPresenter containing all strokes that have been drawn on the page.
    /// The InkEditor behavior is used to modify the strokes of an InkPresenter.
    /// </remarks>
    public class Ink
        : Annotation
    {
        /// <summary>
        /// Identifies the ink annotation type.
        /// </summary>
        public static readonly XName TypeInk = XName.Get("Ink", AnnotationStore.NamespaceAnnotations);

        /// <summary>
        /// Initializes a new instance of the <see cref="Ink"/> class.
        /// </summary>
        public Ink()
            : base(TypeInk)
        {
            this.Strokes = new ObservableCollection<Stroke>();
            this.Strokes.CollectionChanged += OnStrokesChanged;
        }

        private void OnStrokesChanged(object sender, NotifyCollectionChangedEventArgs e)
        {
            OnPropertyChanged("Strokes");
        }

        /// <summary>
        /// Gets or sets the page number.
        /// </summary>
        /// <value>The page number.</value>
        public int PageNumber { get; set; }
        /// <summary>
        /// Gets the strokes.
        /// </summary>
        /// <value>The strokes.</value>
        public ObservableCollection<Stroke> Strokes { get; private set; }

        /// <summary>
        /// Determines whether the current annotation instance includes specified page.
        /// </summary>
        /// <param name="pageNumber">The page number.</param>
        /// <returns>
        /// 	<c>true</c> if the specified page is included; otherwise, <c>false</c>.
        /// </returns>
        public override bool ContainsPage(int pageNumber)
        {
            return this.PageNumber == pageNumber;
        }

        /// <summary>
        /// Renders the annotation.
        /// </summary>
        /// <param name="context">The context.</param>
        public override void RenderAnnotation(AnnotationRenderContext context)
        {
            // In this scenario the annotation is rendered by the InkEditor behavior; the
            // ink annotation is always editable.
            // In case you want to render read-only Ink annotations you
            // should enable rendering here as is showed below.


            //var presenter = new InkPresenter();
            //foreach (var stroke in this.Strokes) {
            //    presenter.Strokes.Add(stroke);
            //}

            //context.AnnotationLayer.Children.Add(presenter);
        }
    }
}
