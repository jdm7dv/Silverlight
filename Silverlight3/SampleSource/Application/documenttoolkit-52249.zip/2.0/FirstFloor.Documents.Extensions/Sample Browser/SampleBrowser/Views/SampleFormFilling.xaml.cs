﻿using System;
using System.Windows.Controls;
using System.Windows.Navigation;
using FirstFloor.Documents.Controls;
using SharpZipLib;

namespace SampleBrowser.Views
{
    public partial class SampleFormFilling : Page
    {
        public SampleFormFilling()
        {
            InitializeComponent();

            this.Loaded += (o, e) => {
                this.DataSource.PackageReader = new SharpZipPackageReader(new Uri("Assets/Documents/Change Request Form.xps", UriKind.Relative));
            };
        }

        protected override void OnNavigatedFrom(NavigationEventArgs e)
        {
            base.OnNavigatedFrom(e);

            // properly clears the datasource and closes the package reader
            this.DataSource.PackageReader = null;
        }

        private void DataSource_LoadError(object sender, ErrorEventArgs e)
        {
            new ErrorWindow(e.Error).Show();
        }

    }
}
