﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Media;

using FirstFloor.Documents;
using FirstFloor.Documents.DocumentStructures;

namespace SampleBrowser.MetadataViewModel
{
    /// <summary>
    /// Represents a document content node.
    /// </summary>
    public class DocumentContentNode
        : Node
    {
        private FixedDocument owner;

        /// <summary>
        /// Initializes a new instance of the <see cref="DocumentContentNode"/> class.
        /// </summary>
        /// <param name="owner">The owner.</param>
        /// <param name="options">The options.</param>
        public DocumentContentNode(FixedDocument owner, ViewModelOptions options)
            : base(options)
        {
            this.owner = owner;
        }

        /// <summary>
        /// Gets the text.
        /// </summary>
        /// <value>The text.</value>
        public override string Text
        {
            get { return "Content"; }
        }

        /// <summary>
        /// Gets the icon.
        /// </summary>
        /// <value>The icon uri.</value>
        public override string Icon
        {
            get { return "/SampleBrowser;component/Assets/Icons/folder_page.png"; }
        }

        /// <summary>
        /// Gets a reference to the document content.
        /// </summary>
        /// <value>The content.</value>
        public IEnumerable<Story> DocumentContent
        {
            get { return this.owner.DocumentStructure.DocumentContent; }
        }

        /// <summary>
        /// Gets the child nodes.
        /// </summary>
        /// <value>The nodes.</value>
        public override IEnumerable<Node> Children
        {
            get
            {
                foreach (Story story in this.DocumentContent) {
                    yield return new StoryNode(this.owner, story, this.Options);
                }
            }
        }
    }
}
