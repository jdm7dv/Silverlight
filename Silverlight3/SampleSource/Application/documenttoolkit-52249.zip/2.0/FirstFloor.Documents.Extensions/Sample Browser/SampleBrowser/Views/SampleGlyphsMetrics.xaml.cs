﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Windows.Navigation;
using FirstFloor.Documents.Fonts;

namespace SampleBrowser.Views
{
    public partial class SampleGlyphsMetrics : Page
    {
        public SampleGlyphsMetrics()
        {
            InitializeComponent();

            var fonts = Fonts.AllFonts().ToArray();
            this.cmbFont.ItemsSource = fonts;
            this.cmbFont.SelectedItem = fonts.First();
        }

        private void cmbFont_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            var font = (Fonts.FontInfo)this.cmbFont.SelectedItem;
            if (font != null) {
                this.metrics.Children.Clear();

                RenderGlyphMetrics(this.sampleText, font.FontUri);
                RenderGlyphMetrics(this.sampleText2, font.FontUri);
                RenderGlyphMetrics(this.sampleText3, font.FontUri);
                RenderGlyphMetrics(this.sampleText4, font.FontUri);
            }
        }

        private void RenderGlyphMetrics(Glyphs glyphs, Uri fontUri)
        {
            glyphs.FontUri = fontUri;

            var glyphRun = GlyphHelper.CreateGlyphRun(glyphs);

            // render base line
            var baseLine = new Line() {
                X1 = glyphRun.Bounds.Left,
                X2 = glyphRun.Bounds.Right,
                Y1 = (int)glyphs.OriginY + .5,
                Y2 = (int)glyphs.OriginY + .5,
                Stroke = new SolidColorBrush(Colors.Red),
            };
            this.metrics.Children.Add(baseLine);

            // render ascent
            DrawLine(glyphRun.Bounds.Left,
                     glyphs.OriginY - glyphRun.GlyphTypeface.Ascender * glyphRun.FontRenderingEmSize,
                     glyphRun.Bounds.Right,
                     glyphs.OriginY - glyphRun.GlyphTypeface.Ascender * glyphRun.FontRenderingEmSize,
                     new SolidColorBrush(Colors.Blue));

            // render descent
            DrawLine(glyphRun.Bounds.Left,
                     glyphs.OriginY - glyphRun.GlyphTypeface.Descender * glyphRun.FontRenderingEmSize,
                     glyphRun.Bounds.Right,
                     glyphs.OriginY - glyphRun.GlyphTypeface.Descender * glyphRun.FontRenderingEmSize,
                     new SolidColorBrush(Colors.Green));

            // render advance widths for each individual glyph
            var offset = glyphRun.Bounds.Left;

            DrawLine(offset,
                     glyphRun.Bounds.Top,
                     offset,
                     glyphRun.Bounds.Bottom,
                     new SolidColorBrush(Colors.Gray));

            foreach (var width in glyphRun.AdvanceWidths) {
                offset += (width * glyphRun.FontRenderingEmSize);

                DrawLine(offset,
                         glyphRun.Bounds.Top,
                         offset,
                         glyphRun.Bounds.Bottom,
                         new SolidColorBrush(Colors.Gray));
            }
        }

        private void DrawLine(double x1, double y1, double x2, double y2, Brush brush)
        {
            var line = new Line() {
                X1 = (int)x1 + .5,
                X2 = (int)x2 + .5,
                Y1 = (int)y1 + .5,
                Y2 = (int)y2 + .5,
                Stroke = brush
            };
            this.metrics.Children.Add(line);
        }
    }
}
