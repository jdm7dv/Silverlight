﻿using System;
using System.Collections.Generic;
using System.IO;

namespace DocumentServices.Storage
{
    /// <summary>
    /// Defines the contract of the document store.
    /// </summary>
    public interface IDocumentStore
    {
        /// <summary>
        /// Adds specified document to the store.
        /// </summary>
        /// <param name="document">The document.</param>
        /// <param name="name">The name.</param>
        void AddDocument(string name, Stream document);
        /// <summary>
        /// Determines whether the specified document exists.
        /// </summary>
        /// <param name="name">The name.</param>
        /// <returns>
        /// 	<c>true</c> if the specified document exists; otherwise, <c>false</c>.
        /// </returns>
        bool ContainsDocument(string name);
        /// <summary>
        /// Gets the document's last modification date.
        /// </summary>
        /// <param name="name">The name.</param>
        /// <returns></returns>
        DateTime GetDocumentLastModified(string name);
        /// <summary>
        /// Retrieves the part from specified document stream.
        /// </summary>
        /// <param name="document">The document.</param>
        /// <param name="partName">Name of the part.</param>
        /// <returns></returns>
        /// <remarks>
        /// Note: it is the responsibility of the caller to properly close the returned part stream.
        /// </remarks>
        DocumentPartInfo GetDocumentPart(Stream document, string partName);
        /// <summary>
        /// Gets all documents contained in this store.
        /// </summary>
        /// <returns></returns>
        IEnumerable<DocumentInfo> GetDocuments();
        /// <summary>
        /// Opens the specified document for reading.
        /// </summary>
        /// <param name="name">The name.</param>
        /// <returns></returns>
        Stream OpenDocument(string name);
        /// <summary>
        /// Removes specified document from the store.
        /// </summary>
        /// <param name="name">The name.</param>
        void RemoveDocument(string name);
    }
}
