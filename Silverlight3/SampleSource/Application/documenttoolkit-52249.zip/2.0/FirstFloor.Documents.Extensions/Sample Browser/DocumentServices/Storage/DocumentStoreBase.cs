﻿using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Packaging;
using System.Linq;
using System.Text;
using System.Windows.Xps.Packaging;

using Ionic.Zip;

namespace DocumentServices.Storage
{
    /// <summary>
    /// Provides the shared implementation of a document store.
    /// </summary>
    public abstract class DocumentStoreBase
        : IDocumentStore
    {
        /// <summary>
        /// Adds specified document to the store.
        /// </summary>
        /// <param name="document">The document.</param>
        /// <param name="name">The name.</param>
        public abstract void AddDocument(string name, Stream document);

        /// <summary>
        /// Determines whether the specified document exists.
        /// </summary>
        /// <param name="name">The name.</param>
        /// <returns>
        /// 	<c>true</c> if the specified document exists; otherwise, <c>false</c>.
        /// </returns>
        public abstract bool ContainsDocument(string name);

        /// <summary>
        /// Gets the document's last modification date.
        /// </summary>
        /// <param name="name">The name.</param>
        /// <returns></returns>
        public abstract DateTime GetDocumentLastModified(string name);

        /// <summary>
        /// Reads the document info from given document stream.
        /// </summary>
        /// <param name="name">The name.</param>
        /// <param name="stream">The stream.</param>
        /// <returns></returns>
        public DocumentInfo ReadDocumentInfo(string name, Stream stream)
        {
            using (var package = Package.Open(stream)) {
                var document = new XpsDocument(package);

                var info = new DocumentInfo(name);
                info.Title = document.CoreDocumentProperties.Title;
                info.Author = document.CoreDocumentProperties.Creator;
                info.PageCount = (from fixedDoc in document.FixedDocumentSequenceReader.FixedDocuments
                                  select fixedDoc.FixedPages.Count).Sum();
                if (document.Thumbnail != null) {
                    info.ThumbnailUri = document.Thumbnail.Uri;
                }

                return info;
            }
        }

        /// <summary>
        /// Retrieves the part from specified document stream.
        /// </summary>
        /// <param name="document">The document.</param>
        /// <param name="partName">Name of the part.</param>
        /// <returns></returns>
        /// <remarks>
        /// Note: it is the responsibility of the caller to properly close the returned part stream.
        /// </remarks>
        public DocumentPartInfo GetDocumentPart(Stream document, string partName)
        {
            DocumentPartInfo result = null;

            if (partName == "/[Content_Types].xml") {
                // according to Open Package Conventions specification, /[Content_Types].xml is not a package part,
                // read this part using 3rd party ZIP reader and use the contenttype 'text/xml'
                using (var file = ZipFile.Read(document)) {
                    var entry = file[partName];
                    if (entry != null) {
                        result = new DocumentPartInfo();
                        result.ContentType = "text/xml";
                        result.Stream = new MemoryStream();

                        entry.Extract(result.Stream);
                        result.Stream.Seek(0, SeekOrigin.Begin); // reset position
                    }
                }
            }
            else {
                // use the Open Packaging API to retrieve package parts
                var package = Package.Open(document);
                var partUri = PackUriHelper.CreatePartUri(new Uri(partName, UriKind.Relative));
                if (package.PartExists(partUri)) {
                    var part = package.GetPart(partUri);

                    result = new DocumentPartInfo();
                    result.ContentType = part.ContentType;
                    result.Stream = part.GetStream(FileMode.Open);
                }
            }

            return result;
        }

        /// <summary>
        /// Gets all documents contained in this store.
        /// </summary>
        /// <returns></returns>
        public abstract IEnumerable<DocumentInfo> GetDocuments();

        /// <summary>
        /// Opens the specified document for reading.
        /// </summary>
        /// <param name="name">The name.</param>
        /// <returns></returns>
        public abstract Stream OpenDocument(string name);

        /// <summary>
        /// Removes specified document from the store.
        /// </summary>
        /// <param name="name">The name.</param>
        public abstract void RemoveDocument(string name);
    }
}
