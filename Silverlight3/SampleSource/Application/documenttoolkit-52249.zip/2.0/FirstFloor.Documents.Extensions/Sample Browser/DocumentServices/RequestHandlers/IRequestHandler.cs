﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;

using DocumentServices.Storage;

namespace DocumentServices.RequestHandlers
{
    /// <summary>
    /// The contract for handling HTTP requests
    /// </summary>
    public interface IRequestHandler
    {
        /// <summary>
        /// Handles the request.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="store">The store.</param>
        void HandleRequest(HttpContext context, IDocumentStore store);
    }
}
