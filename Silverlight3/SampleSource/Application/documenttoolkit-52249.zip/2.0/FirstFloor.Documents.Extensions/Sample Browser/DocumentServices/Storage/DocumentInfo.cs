﻿using System;
using System.Collections.Generic;
using System.Web;

namespace DocumentServices.Storage
{
    /// <summary>
    /// Identifies a single document in the document store.
    /// </summary>
    public class DocumentInfo
    {
        private string name;
        private string title;
        private string author;
        private int pageCount;
        private Uri thumbnailUri;

        /// <summary>
        /// Initializes a new instance of the <see cref="DocumentInfo"/> class.
        /// </summary>
        /// <param name="name">The name.</param>
        public DocumentInfo(string name)
        {
            this.name = name;
        }

        /// <summary>
        /// Uniquely identifies a document in the document store.
        /// </summary>
        /// <value>The name.</value>
        public string Name
        {
            get { return this.name; }
        }

        /// <summary>
        /// Gets or sets the title.
        /// </summary>
        /// <value>The title.</value>
        public string Title
        {
            get { return this.title ?? this.name; }
            set { this.title = value; }
        }

        /// <summary>
        /// Gets or sets the author.
        /// </summary>
        /// <value>The author.</value>
        public string Author
        {
            get { return this.author ?? ""; }
            set { this.author = value; }
        }

        /// <summary>
        /// Gets or sets the page count.
        /// </summary>
        /// <value>The page count.</value>
        public int PageCount
        {
            get { return this.pageCount; }
            set { this.pageCount = value; }
        }

        /// <summary>
        /// Gets or sets the part uri of the document's thumbnail.
        /// </summary>
        /// <value>The thumbnail.</value>
        public Uri ThumbnailUri
        {
            get { return this.thumbnailUri; }
            set { this.thumbnailUri = value; }
        }
    }
}