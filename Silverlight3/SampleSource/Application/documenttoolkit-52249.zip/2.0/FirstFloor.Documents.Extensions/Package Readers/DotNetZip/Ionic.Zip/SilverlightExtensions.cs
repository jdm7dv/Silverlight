﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Linq;
using System.Collections.Generic;

namespace DotNetZip.SilverlightExtensions
{
    /// <summary>
    /// Silverlight helper
    /// </summary>
  public static class SilverlightExtensions
  {
      /// <summary>
      /// Converts all.
      /// </summary>
      /// <typeparam name="TInput">The type of the input.</typeparam>
      /// <typeparam name="TOutput">The type of the output.</typeparam>
      /// <param name="list">The list.</param>
      /// <param name="converter">The converter.</param>
      /// <returns></returns>
    public static List<TOutput> ConvertAll<TInput, TOutput>(
      this List<TInput> list, Converter<TInput, TOutput> converter)
    {
      if (list == null)
        throw new ArgumentException();

      return (from item in list select converter(item)).ToList();
    }
  }
}
