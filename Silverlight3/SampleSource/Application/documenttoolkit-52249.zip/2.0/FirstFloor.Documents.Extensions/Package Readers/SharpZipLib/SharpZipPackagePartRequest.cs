﻿using System;
using System.IO;
using System.Threading;
using System.Windows;
using System.Windows.Resources;

using ICSharpCode.SharpZipLib;
using FirstFloor.Documents.IO;

namespace SharpZipLib
{
    /// <summary>
    /// Encapsulates a zip package part request.
    /// </summary>
    public class SharpZipPackagePartRequest
        : SyncPackagePartRequest
    {
        private ZipFile zipFile;
        private Uri partUri;
        /// <summary>
        /// Initializes a new instance of the <see cref="SharpZipPackagePartRequest"/> class.
        /// </summary>
        /// <param name="zipFile">The zip file.</param>
        /// <param name="partUri">The part URI.</param>
        internal SharpZipPackagePartRequest(ZipFile zipFile, Uri partUri)
        {
            this.zipFile = zipFile;
            this.partUri = partUri;
        }

        /// <summary>
        /// Loads the requested part synchronously.
        /// </summary>
        /// <returns>The part content stream.</returns>
        protected override Stream LoadPart()
        {
            ZipEntry part = this.zipFile.GetEntry(this.partUri.OriginalString);
            if (part != null) {
                return this.zipFile.GetInputStream(part);
            }
            return null;
        }
    }
}
