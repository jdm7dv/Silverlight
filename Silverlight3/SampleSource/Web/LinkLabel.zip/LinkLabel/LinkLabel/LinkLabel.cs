﻿namespace CompletIT.Windows.Controls
{
    using System;
    using System.Diagnostics;
    using System.Text.RegularExpressions;
    using System.Windows;
    using System.Windows.Controls;
    using CompletIT.Windows.Controls.LinkLabelElements;
    using System.Windows.Markup;

    public delegate void LinkClickEventHandler( object sender, LinkClickEventArgs e );

    public class LinkLabel : Control
    {
        public const string DefaultUriPattern = "((((ht|f)tp(s?))\\://){1}\\S+)";
        public const string DefaultLinkPattern = "\\[link=\"(?<link>(.|\n)*?)\"\\s*(target=\"(?<target>(.|\n)*?)\")?](?<text>(.|\n)*?)\\[\\/link\\]";
        public const string DefaultLinkPatternUriGroupName = "link";
        public const string DefaultLinkPatternTextGroupName = "text";
        public const string DefaultLinkPatternTargetGroupName = "target";
        public static readonly DependencyProperty LinkStyleProperty = DependencyProperty.Register( "LinkStyle", typeof( Style ), typeof( LinkLabel ), null );
        public static readonly DependencyProperty TextStyleProperty = DependencyProperty.Register( "TextStyle", typeof( Style ), typeof( LinkLabel ), null );
        public static readonly DependencyProperty TextProperty = DependencyProperty.Register( "Text", typeof( string ), typeof( LinkLabel ), new PropertyMetadata( new PropertyChangedCallback( OnTextChanged ) ) );
        private WrapPanel.WrapPanel layoutRoot;
        private LinkMatchMethod linkMatchMethod = LinkMatchMethod.ByUriAndLinkPattern;
        private string linkPattern;
        private string linkPatternLinkGroupName;
        private string linkPatternTextGroupName;
        private string linkPatternTargetGroupName;
        private string uriPattern;

        public LinkLabel()
            : base()
        {
            DefaultStyleKey = typeof( LinkLabel );

        }

        public event LinkClickEventHandler LinkClick;

        /// <summary>
        /// Gets or sets the method of how the links are matched
        /// </summary>
        public LinkMatchMethod LinkMatchMethod
        {
            get
            {
                return this.linkMatchMethod;
            }

            set
            {
                this.linkMatchMethod = value;
            }
        }

        /// <summary>
        /// Gets or sets the style of the added Hyperlink controls
        /// </summary>
        public Style LinkStyle
        {
            get
            {
                return ( Style )this.GetValue( LinkStyleProperty );
            }

            set
            {
                base.SetValue( LinkStyleProperty, ( DependencyObject )value );
            }
        }

        /// <summary>
        /// Gets or sets the style of the added TextBlock controls
        /// </summary>
        public Style TextStyle
        {
            get
            {
                return ( Style )this.GetValue( TextStyleProperty );
            }

            set
            {
                base.SetValue( TextStyleProperty, ( DependencyObject )value );
            }
        }

        /// <summary>
        /// Gets or sets the text of the LinkLabel control
        /// </summary>
        public string Text
        {
            get
            {
                return ( string )this.GetValue( TextProperty );
            }

            set
            {
                base.SetValue( TextProperty, value );
            }
        }

        /// <summary>
        /// Gets or sets the regular expression pattern used to match URIs
        /// </summary>
        public string UriPattern
        {
            get
            {
                if ( string.IsNullOrEmpty( this.uriPattern ) )
                {
                    return DefaultUriPattern;
                }

                return this.uriPattern;
            }

            set
            {
                this.uriPattern = value;
            }
        }

        /// <summary>
        /// Gets or sets the regular expression pattern used to match links
        /// </summary>
        public string LinkPattern
        {
            get
            {
                if ( string.IsNullOrEmpty( this.linkPattern ) )
                {
                    return DefaultLinkPattern;
                }

                return this.linkPattern;
            }

            set
            {
                this.linkPattern = value;
            }
        }

        /// <summary>
        /// Gets or sets the GroupName of the link in the RegularExpression.Match
        /// </summary>
        public string LinkPatternUriGroupName
        {
            get
            {
                if ( this.LinkPattern.Equals( DefaultLinkPattern, StringComparison.OrdinalIgnoreCase ) )
                {
                    return DefaultLinkPatternUriGroupName;
                }

                return this.linkPatternLinkGroupName;
            }

            set
            {
                this.linkPatternLinkGroupName = value;
            }
        }

        /// <summary>
        /// Gets or sets the GroupName of the text in the RegularExpression.Match
        /// </summary>
        public string LinkPatternTextGroupName
        {
            get
            {
                if ( this.LinkPattern.Equals( DefaultLinkPattern, StringComparison.OrdinalIgnoreCase ) )
                {
                    return DefaultLinkPatternTextGroupName;
                }

                return this.linkPatternTextGroupName;
            }

            set
            {
                this.linkPatternTextGroupName = value;
            }
        }

        /// <summary>
        /// Gets or sets the GroupName of the target in the RegularExpression.Match
        /// </summary>
        public string LinkPatternTargetGroupName
        {
            get
            {
                if ( this.LinkPattern.Equals( DefaultLinkPattern, StringComparison.OrdinalIgnoreCase ) )
                {
                    return DefaultLinkPatternTargetGroupName;
                }

                return this.linkPatternTargetGroupName;
            }
            set
            {
                this.linkPatternTargetGroupName = value;
            }
        }

        public override void OnApplyTemplate()
        {
            this.layoutRoot = this.GetTemplateChild( "LayoutRoot" ) as WrapPanel.WrapPanel;
            Debug.Assert( this.layoutRoot != null, "LayoutRoot is null" );
            this.ProcessText();

            base.OnApplyTemplate();
        }

        private static void OnTextChanged( DependencyObject d, DependencyPropertyChangedEventArgs e )
        {
            LinkLabel linkLabel = d as LinkLabel;
            Debug.Assert( linkLabel != null, "LaytouRoot is null" );

            linkLabel.ProcessText();
        }

        private void ClickLink( object sender, RoutedEventArgs e )
        {
            LinkClickEventHandler click = this.LinkClick;
            if ( click != null )
            {
                LinkClickEventArgs args = new LinkClickEventArgs( ( sender as HyperlinkButton ).NavigateUri );
                args.Source = this;
                click( this, args );
            }
        }

        private void AddLinks( LinkCollection links )
        {
            string linkLabelText = this.Text;
            string preUri = string.Empty;
            string[] preUriWords = null;
            string postUri = string.Empty;
            string[] postUriWords = null;
            int startIndexOfUri = 0;
            char[] delimiter = { ' ' };

            // no uris found
            if ( links == null || links.Count == 0 )
            {
                this.layoutRoot.Children.Add( new TextBlock()
                {
                    Text = this.Text,
                    Style = this.TextStyle
                } );
                return;
            }

            foreach ( Link link in links )
            {
                startIndexOfUri = linkLabelText.IndexOf( link.Key, StringComparison.OrdinalIgnoreCase );
                preUri = linkLabelText.Substring( 0, startIndexOfUri );
                postUri = linkLabelText.Substring( preUri.Length + link.Key.Length );
                linkLabelText = postUri;

                // put all the words before the current Uri
                preUriWords = preUri.Split( delimiter, StringSplitOptions.RemoveEmptyEntries );
                foreach ( string preWord in preUriWords )
                {
                    this.layoutRoot.Children.Add( new TextBlock()
                    {
                        Text = preWord + " ",
                        Style = this.TextStyle
                    } );
                }

                // insert the Uri
                HyperlinkButton hyperlink = new HyperlinkButton()
                {
                    Content = link.Text + " ",
                    NavigateUri = link.NavigateUri,
                    TargetName = link.TargetName,
                    Style = this.LinkStyle
                };
                hyperlink.Click += new RoutedEventHandler( this.ClickLink );
                this.layoutRoot.Children.Add( hyperlink );
            }

            // append the text after the last uri found
            if ( !string.IsNullOrEmpty( linkLabelText ) )
            {
                postUriWords = postUri.Split( delimiter, StringSplitOptions.RemoveEmptyEntries );
                foreach ( string postWord in postUriWords )
                {
                    this.layoutRoot.Children.Add( new TextBlock()
                    {
                        Text = postWord + " ",
                        Style = this.TextStyle
                    } );
                }
            }
        }

        private LinkCollection GetLinkMatches()
        {
            LinkCollection uriCollection = null;
            Uri currentUri = null;

            Regex uriLocator = new Regex( this.LinkPattern );
            MatchCollection uriMatches = uriLocator.Matches( this.Text );

            // no uris found
            if ( uriMatches == null || uriMatches.Count == 0 )
            {
                return null;
            }

            foreach ( Match uri in uriMatches )
            {
                // not valid uri - continue with next match
                if ( !Uri.TryCreate(
                    uri.Groups[ LinkPatternUriGroupName ].Value,
                    UriKind.RelativeOrAbsolute, out currentUri ) )
                {
                    continue;
                }

                if ( uriCollection == null )
                {
                    uriCollection = new LinkCollection();
                }

                uriCollection.Add( new Link( uri.Value, currentUri )
                {
                    Text = uri.Groups[ LinkPatternTextGroupName ].Value,
                    TargetName = ( uri.Groups[ LinkPatternTargetGroupName ].Value == String.Empty ? "_self" : uri.Groups[ LinkPatternTargetGroupName ].Value )
                } );
            }

            return uriCollection;
        }

        private LinkCollection GetUriMatches()
        {
            LinkCollection uriCollection = null;
            Uri currentUri = null;

            Regex uriLocator = new Regex( this.UriPattern );
            MatchCollection uriMatches = uriLocator.Matches( this.Text );

            // no uris found
            if ( uriMatches == null || uriMatches.Count == 0 )
            {
                return null;
            }

            foreach ( Match uri in uriMatches )
            {
                // not valid uri - continue with next match
                if ( !Uri.TryCreate( uri.Value, UriKind.RelativeOrAbsolute, out currentUri ) )
                {
                    continue;
                }

                if ( uriCollection == null )
                {
                    uriCollection = new LinkCollection();
                }

                uriCollection.Add( new Link( uri.Value, currentUri ) );
            }

            return uriCollection;
        }

        private void OrderLinksByAppearenceInTheText( LinkCollection links )
        {
            int i, j;
            Link l;

            for ( i = links.Count - 1; i > 0; i-- )
            {
                for ( j = 0; j < i; j++ )
                {
                    if ( this.Text.IndexOf( links[ j ].Key, StringComparison.Ordinal ) > this.Text.IndexOf( links[ j + 1 ].Key, StringComparison.Ordinal ) )
                    {
                        l = links[ j ];
                        links[ j ] = links[ j + 1 ];
                        links[ j + 1 ] = l;
                    }
                }
            }
        }

        private void ProcessText()
        {
            if ( this.layoutRoot == null || string.IsNullOrEmpty( this.Text ) )
            {
                return;
            }

            // clear current text
            this.layoutRoot.Children.Clear();

            if ( this.LinkMatchMethod == LinkMatchMethod.ByUriPattern )
            {
                this.AddLinks( this.GetUriMatches() );
            }
            else if ( this.LinkMatchMethod == LinkMatchMethod.ByLinkPattern )
            {
                this.AddLinks( this.GetLinkMatches() );
            }
            else if ( this.LinkMatchMethod == LinkMatchMethod.ByUriAndLinkPattern )
            {
                LinkCollection allLinks = new LinkCollection();

                LinkCollection linkMatchesCollection = this.GetLinkMatches();

                if ( linkMatchesCollection != null )
                {
                    foreach ( Link link in linkMatchesCollection )
                    {
                        allLinks.Add( link );
                    }
                }

                LinkCollection uriMatchesCollection = this.GetUriMatches();

                if ( uriMatchesCollection != null )
                {
                    foreach ( Link link in uriMatchesCollection )
                    {
                        allLinks.Add( link );
                    }
                }

                this.OrderLinksByAppearenceInTheText( allLinks );
                this.AddLinks( allLinks );
            }
        }
    }
}