﻿namespace CompletIT.Windows.Controls.LinkLabelElements
{
    using System.Collections.ObjectModel;

    internal class LinkCollection : Collection<Link>
    {
    }
}
