﻿namespace CompletIT.Windows.Controls.LinkLabelElements
{
    using System;

    /// <summary>
    /// Represents a link within a LinkLabel control
    /// </summary>
    internal class Link
    {
        private string targetName = "_self";
        private string text;

        public Link( string key, Uri navigateUri )
        {
            this.Key = key;
            this.NavigateUri = navigateUri;
        }

        /// <summary>
        /// Gets or sets the text to be replaced with a link
        /// </summary>
        public string Key
        {
            get;
            set;
        }

        /// <summary>
        /// Gets or sets the URI to navigate to when the link is clicked
        /// </summary>
        public Uri NavigateUri
        {
            get;
            set;
        }

        /// <summary>
        /// Gets or sets the name of a target window or frame to navigate to within the Web page specified by the NavigateUri property
        /// </summary>
        public string TargetName
        {
            get
            {
                return this.targetName;
            }

            set
            {
                this.targetName = value;
            }
        }

        /// <summary>
        /// Gets or sets the text of the link. If not specified the Key property is used.
        /// </summary>
        public string Text
        {
            get
            {
                if ( string.IsNullOrEmpty( this.text ) )
                {
                    return this.Key;
                }

                return this.text;
            }

            set
            {
                this.text = value;
            }
        }
    }
}
