﻿namespace CompletIT.Windows.Controls.LinkLabelElements
{
    using System.Windows.Controls;

    public class LinkButton : Button
    {
        private ActionType actionType = ActionType.Navigate;

        public string Action
        {
            get;
            set;
        }

        public ActionType ActionType
        {
            get
            {
                return this.actionType;
            }
            set
            {
                this.actionType = value;
            }
        }

    }

    public enum ActionType
    {
        Navigate,
        UserHandeled
    }
}
