﻿namespace CompletIT.Windows
{
    using System;
    using System.Windows;

    public class LinkClickEventArgs : RoutedEventArgs
    {
        public LinkClickEventArgs( Uri navigateUri )
        {
            this.NavigateUri = navigateUri;
        }

        public Uri NavigateUri
        {
            get;
            set;
        }
    }
}