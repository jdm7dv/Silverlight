﻿namespace LinkLabelTest
{
    using System.Windows;
    using System.Windows.Controls;

    public partial class Page : UserControl
    {
        public Page()
        {
            InitializeComponent();
            this.TextToProccess.Text = "LinkLabel control represents a Silverlight TextBlock control that can contain [link=\"http://www.silverlightshow.net\" target=\"_blank\"]links[/link] defined either by a user defined pattern or with their URI like http://www.silverlightshow.net";
            this.MyLinkLabel.Text = TextToProccess.Text;
        }

        private void Button_Click( object sender, RoutedEventArgs e )
        {
            this.MyLinkLabel.Text = this.TextToProccess.Text;
        }
    }
}
