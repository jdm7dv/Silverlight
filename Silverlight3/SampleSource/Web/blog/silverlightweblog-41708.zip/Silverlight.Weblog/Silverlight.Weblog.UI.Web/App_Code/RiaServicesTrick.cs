﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Silverlight.Weblog.Server.DAL;

namespace Silverlight.Weblog.UI.Web.App_Code
{
#if DEBUG
    ///// <summary>
    ///// This class is here to trick RIA Services
    ///// to think there's an EF Context in this project.
    ///// RIA Services new domain wizard only looks in the 
    ///// current web project. 
    ///// </summary>
    //public class RiaServicesTrick : EfContext
    //{
    //}
#endif 
}
