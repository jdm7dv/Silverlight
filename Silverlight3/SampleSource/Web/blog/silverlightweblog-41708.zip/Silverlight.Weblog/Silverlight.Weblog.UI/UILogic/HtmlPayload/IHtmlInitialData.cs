namespace Silverlight.Weblog.UI.UILogic
{
    public interface IHtmlInitialData
    {
        void Initialize();
    }
}