namespace Silverlight.Weblog.Client.DAL.RiaServices
{
    public interface IInitialPaylodService
    {
        void Load();
    }
}