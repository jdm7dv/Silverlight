﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Practices.Unity;
using Silverlight.Weblog.Client.DAL.Services.Interfaces;
using Silverlight.Weblog.Server.DAL;

namespace Silverlight.Weblog.Client.DAL.Services
{
    //public class CommentService : ICreate<Comment>
    //{
    //    [Dependency]
    //    public IDBContextContainer DBContextContainer { get; set; }

    //    public void Create(Comment comment)
    //    {
    //        //DBContextContainer.Current.InsertComment(comment);
    //    }
    //}
}
