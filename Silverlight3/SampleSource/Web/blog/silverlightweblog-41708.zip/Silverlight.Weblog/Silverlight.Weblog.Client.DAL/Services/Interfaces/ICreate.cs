namespace Silverlight.Weblog.Client.DAL.Services
{
    public interface ICreate<T>
    {
        void Create(T t);
    }
}