using Silverlight.Weblog.Server.DAL;

namespace Silverlight.Weblog.Client.Default.Widgets
{
    public interface ICommentWidgetViewModel
    {
    }
}