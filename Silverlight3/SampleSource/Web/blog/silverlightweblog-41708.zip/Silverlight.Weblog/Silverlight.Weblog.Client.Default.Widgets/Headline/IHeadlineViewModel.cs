namespace Silverlight.Weblog.Client.Default.Widgets
{
    public interface IHeadlineViewModel
    {
        string BlogName { get; set; }
        string BlogSubtitle { get; set; }
    }
}