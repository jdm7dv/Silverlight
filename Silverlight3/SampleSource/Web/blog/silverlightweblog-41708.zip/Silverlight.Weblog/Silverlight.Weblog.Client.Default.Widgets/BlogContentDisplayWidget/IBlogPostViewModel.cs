namespace Silverlight.Weblog.Client.Default.Widgets.ViewModels
{
    public interface IBlogPostViewModel
    {
    }
}