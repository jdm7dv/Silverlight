﻿using System;
using System.Collections.Generic;
using System.Data.Objects;
using System.Linq;
using System.Text;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Silverlight.Weblog.Common.IoC;
using Silverlight.Weblog.Server.DAL;
using Silverlight.Weblog.Server.DAL.Services;
using Silverlight.Weblog.Server.DAL.Services.Interfaces;
using Silverlight.Weblog.UI.Web;
using Silverlight.Weblog.UI.Web.MetaWeblog;

namespace Silverlight.Weblog.Server.UI.Web.Testing
{
    //[TestClass]
    //public class Initializer_Test : UnitTestBase<Initializer>
    //{
    //    [TestMethod]
    //    public void Initialized_Registered_AllClassesRegisters()
    //    {
    //        // setup
    //        // action
    //        Initializer.RegisterIoC();

    //        // assert
    //        IoC.Get<IUserService>().AssertIsOfType<UserService>();
    //        IoC.Get<IRepository<User>>().AssertIsOfType<EntityFrameworkRepository<User>>();
    //    }
    //}
}
