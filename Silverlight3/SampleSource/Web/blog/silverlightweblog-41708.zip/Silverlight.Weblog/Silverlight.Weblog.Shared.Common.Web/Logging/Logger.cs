﻿using System;
using System.Net;


namespace Silverlight.Weblog.Shared.Common.Logging
{
    public static class Logger
    {
        public static void Log(Exception exception)
        {
            // TODO: Implement Logger    
        }
    }
}
