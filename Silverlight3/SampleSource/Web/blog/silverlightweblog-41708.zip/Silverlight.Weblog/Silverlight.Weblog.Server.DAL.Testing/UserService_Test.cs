﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Silverlight.Weblog.Server.DAL.Testing
{
    [TestClass]
    public class UserService_Test
    {
        [TestMethod]
        public void IsValidUser_MockRepository_MockIsCalled()
        {
            // setup
            

            // action

            // assert
            //Assert.IsTrue();
        }
    }
}
