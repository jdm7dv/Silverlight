﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.ServiceModel;
using System.ServiceModel.Channels;

namespace UseWebService
{
    public partial class Page : UserControl
    {
        public Page()
        {
            InitializeComponent();
        }

        private void btnCallWebService_Click(object sender, RoutedEventArgs e)
        {
            Binding myBinding = new BasicHttpBinding(BasicHttpSecurityMode.None);
            EndpointAddress myEndpoint = new EndpointAddress("http://localhost/UseWebService/Service1.asmx");  //for when I depoly to my web server, it is in a folder off the root called UseWebService and I run the silverlight app with http://localhost/UseWebService/UseWebServiceTestPage.aspx
            //EndpointAddress myEndpoint = new EndpointAddress("http://localhost:43654/Service1.asmx");  // for debugging in VS, see UseWebService.Web->Properties->Web->Servers
            Service1Reference.Service1SoapClient proxy = new Service1Reference.Service1SoapClient(myBinding, myEndpoint);

            proxy.HelloWorldCompleted += new EventHandler<UseWebService.Service1Reference.HelloWorldCompletedEventArgs>(proxy_HelloWorldCompleted);
            proxy.HelloWorldAsync("Jack");
        }

        void proxy_HelloWorldCompleted(object sender, UseWebService.Service1Reference.HelloWorldCompletedEventArgs e)
        {
            btnCallWebService.Content = "Call Webservice return data = " + e.Result.ToString();

            (sender as Service1Reference.Service1SoapClient).CloseAsync();

        }
    }
}
