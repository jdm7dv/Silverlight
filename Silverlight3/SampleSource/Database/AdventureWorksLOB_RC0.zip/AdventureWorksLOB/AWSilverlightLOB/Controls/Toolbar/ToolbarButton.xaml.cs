﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace SilverlightLOBFramework.Controls.Toolbar
{
    public partial class ToolbarButton : UserControl
    {
        #region Member Variables
        private bool m_enabled = true; 
        #endregion

        #region Events/Delegates
        public event EventHandler ButtonClick; 
        #endregion

        #region Constructor
        public ToolbarButton()
        {
            InitializeComponent();
        } 
        #endregion

        #region Event Handlers
        private void ToolbarButton_MouseEnter(object sender, MouseEventArgs e)
        {
            if (m_enabled)
                selectedIndicator.Opacity = 0.4;
        }

        private void ToolbarButton_MouseLeave(object sender, MouseEventArgs e)
        {
            selectedIndicator.Opacity = 0;
        } 

        private void ToolbarButton_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            if (m_enabled)
            {
                selectedIndicator.Opacity = 1;
                OnButtonClick();
            }
        }

        private void ToolbarButton_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            if (m_enabled)
            {
                selectedIndicator.Opacity = 0.4;
            }
        }
        #endregion

        #region Private Functions
        protected void OnButtonClick()
        {
            if (ButtonClick != null)
                ButtonClick(this, new EventArgs());
        } 
        #endregion

        #region Public Properties
        public string Text
        {
            get { return buttonText.Text; }
            set { buttonText.Text = value; }
        }

        public bool Enabled
        {
            get { return m_enabled; }
            set 
            {
                m_enabled = value;

                buttonText.Foreground = m_enabled ? new SolidColorBrush(Colors.White) : new SolidColorBrush(Colors.Gray);
                this.Cursor = m_enabled ? Cursors.Hand : Cursors.Arrow;
            }
        }

        public string Action { get; set; }
        #endregion
    }
}
