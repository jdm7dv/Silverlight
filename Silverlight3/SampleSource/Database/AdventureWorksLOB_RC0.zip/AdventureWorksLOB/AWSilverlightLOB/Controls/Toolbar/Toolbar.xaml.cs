﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace SilverlightLOBFramework.Controls.Toolbar
{
    public partial class Toolbar : UserControl
    {
        #region Constructor
        public Toolbar()
        {
            InitializeComponent();
        } 
        #endregion

        #region Public Properties
        public UIElementCollection Children
        {
            get
            {
                return ButtonStack.Children;
            }
        }

        public int VerticalButtonPadding
        {
            get { return (int)ButtonStack.Margin.Top; }
            set
            {
                ButtonStack.Margin = new Thickness(ButtonStack.Margin.Left, (double)value, ButtonStack.Margin.Right, (double)value);
            }
        }

        public Orientation Orientation
        {
            get { return ButtonStack.Orientation; }
            set 
            { 
                ButtonStack.Orientation = value;

                if (ButtonStack.Orientation == Orientation.Vertical)
                {
                    toolbarRect.Visibility = Visibility.Collapsed;
                }
            }
        }
        #endregion
    }
}
