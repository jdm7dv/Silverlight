﻿using System.Windows.Controls;
using System.Windows.Input;
using SilverlightLOBFramework.Delegates;

namespace SilverlightLOBFramework.Controls.Layout
{
    public partial class ListSearchBar : UserControl
    {
        public event ListSearchEventHandler SearchList;

        public ListSearchBar()
        {
            InitializeComponent();
        }

        private void SearchButton_Click(object sender, System.Windows.RoutedEventArgs e)
        {
            StartSearch();
        }

        private void PreviousPageButton_Click(object sender, System.Windows.RoutedEventArgs e)
        {

        }

        private void NextPageButton_Click(object sender, System.Windows.RoutedEventArgs e)
        {

        }

        private void ListSearchBar_KeyDown(object sender, System.Windows.Input.KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
                StartSearch();
        }

        private void StartSearch()
        {
            if (SearchList != null)
                SearchList(this, new ListSearchArgs(SearchTextBox.Text));
        }
    }
}
