﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using SilverlightLOBFramework.Delegates;

namespace SilverlightLOBFramework.Controls.Layout
{
    public partial class Footer : UserControl
    {
        #region Constructor
        public Footer()
        {
            InitializeComponent();

            StatusLabel.Text = "";
        } 
        #endregion

        #region Public Functions
        public void ContentPageStateChanged(PageStatusChangeArgs.eStatuses status)
        {
            switch (status)
            {
                case PageStatusChangeArgs.eStatuses.Loading:
                    StatusLabel.Text = "";
                    break;
                case PageStatusChangeArgs.eStatuses.Active:
                    StatusLabel.Text = "";
                    break;
                case PageStatusChangeArgs.eStatuses.RetrievingData:
                    StatusLabel.Text = "Please wait - communicating with server...";
                    break;
                case PageStatusChangeArgs.eStatuses.Closed:
                    StatusLabel.Text = "";
                    break;
                default:
                    StatusLabel.Text = "Unknown Status";
                    break;
            }
        } 
        #endregion
    }
}
