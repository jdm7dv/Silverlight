﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace SilverlightLOBFramework
{
    public static class Globals
    {
        #region Public Fields
        public static string UserName = "";
        public static string Password = "";
        public static string[] UserRoles = null;
        public static bool IsLoggedIn = false;
        #endregion

        #region Public Properties
        public static string WebServiceUrlPath
        {
            get
            {
                return Application.Current.Host.Source.OriginalString.Substring(0, Application.Current.Host.Source.OriginalString.Length - Application.Current.Host.Source.LocalPath.Length + 1) + "AWDataService.svc";
            }
        } 
        #endregion

        #region Page Definition Constants
        public const string PAGE_DASHBOARD = "GotoDashboard";
        public const string PAGE_INVENTORY_LIST = "GotoInventoryList";
        public const string PAGE_PRODUCT_DETAILS = "GotoProductDetails";
        public const string PAGE_PURCHASING_LIST = "GotoPurchasingList";
        public const string PAGE_SALES_LIST = "GotoSalesList";
        public const string PAGE_REPORTS_MENU = "GotoReportsMenu";
        public const string PAGE_ADMIN_MENU = "GotoAdminMenu";
        public const string PAGE_LOGIN = "GotoLoginPage"; 
        #endregion

        #region Public Constants
        public const int LIST_ITEMS_PER_PAGE = 100; 
        #endregion
    }
}
