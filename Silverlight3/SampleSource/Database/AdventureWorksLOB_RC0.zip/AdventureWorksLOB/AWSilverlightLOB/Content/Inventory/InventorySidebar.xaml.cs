﻿using System;
using System.Windows.Controls;
using SilverlightLOBFramework;
using SilverlightLOBFramework.Delegates;

namespace AWSilverlightLOB.Content.Inventory
{
    public partial class InventorySidebar : UserControl
    {
        public event NavigateRequestHandler NavigateRequest;

        public InventorySidebar()
        {
            InitializeComponent();
        }

        private void AddProductButton_ButtonClick(object sender, EventArgs e)
        {
            if (NavigateRequest != null)
                NavigateRequest(sender, new NavigateRequestArgs(Globals.PAGE_PRODUCT_DETAILS, 0));
        }

        private void InventoryListButton_ButtonClick(object sender, EventArgs e)
        {
            if (NavigateRequest != null)
                NavigateRequest(sender, new NavigateRequestArgs(Globals.PAGE_INVENTORY_LIST, null));
        }
    }
}
