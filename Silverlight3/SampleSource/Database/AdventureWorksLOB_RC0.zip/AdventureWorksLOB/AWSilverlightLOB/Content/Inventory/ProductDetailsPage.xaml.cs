﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using SilverlightLOBFramework.Delegates;
using SilverlightLOBFramework.Content;
//using Peers.PeerConnect.Web.Silverlight.ClientDataService;

namespace AWSilverlightLOB.Content.Inventory
{
    public partial class ProductDetailsPage : UserControl, IContentPage
    {
        #region Member Variables
        private int m_productID = 0; 
        #endregion

        #region Constructors
        public ProductDetailsPage()
        {
            InitializeComponent();
        }

        public ProductDetailsPage(int productID)
        {
            InitializeComponent();

            m_productID = productID;
        } 
        #endregion

        #region IContentPage Members
        public event NavigateRequestHandler NavigateRequest;
        public event PageStatusChangeHandler PageStatusChange;

        public UserControl Control
        {
            get { return this; }
        }
        #endregion

        #region Control Event Handlers
        private void ProductDetailsPage_Loaded(object sender, RoutedEventArgs e)
        {
            GetClientDetails(m_productID);
        }

        private void InventorySidebar_NavigateRequest(object sender, NavigateRequestArgs e)
        {
            if (NavigateRequest != null)
                NavigateRequest(sender, e);
        } 
        #endregion

        #region Private Functions
        private void GetClientDetails(int productID)
        {
            //if (PageStatusChange != null)
            //    PageStatusChange(this, new PageStatusChangeArgs(PageStatusChangeArgs.eStatuses.RetrievingData));

            //txtID.Text = productID.ToString();
            //ClientDataServiceClient service = new ClientDataServiceClient("*", Globals.WebServiceUrlPath + "ClientDataService.svc");

            //service.GetClientSummaryCollectionCompleted += new EventHandler<GetClientSummaryCollectionCompletedEventArgs>(ClientDataService_GetClientSummaryCollectionCompleted);
            //service.GetClientSummaryCollectionAsync();
        }

        //private void ClientDataService_GetClientSummaryCollectionCompleted(object sender, GetClientSummaryCollectionCompletedEventArgs e)
        //{
        //    if (PageStatusChange != null)
        //        PageStatusChange(this, new PageStatusChangeArgs(PageStatusChangeArgs.eStatuses.Active));

        //    if (e.Error == null)
        //    {
        //        ClientList.ItemsSource = e.Result;
        //        //foreach (ClientSummaryDTO dto in e.Result)
        //        //{
        //        //}
        //    }
        //}
        #endregion
    }
}
