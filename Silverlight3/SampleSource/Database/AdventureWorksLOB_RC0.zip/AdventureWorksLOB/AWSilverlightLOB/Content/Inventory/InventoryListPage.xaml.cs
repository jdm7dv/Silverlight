﻿using System;
using System.Windows;
using System.Windows.Controls;
using SilverlightLOBFramework;
using SilverlightLOBFramework.Delegates;
using SilverlightLOBFramework.Content;
using AWSilverlightLOB.AWWebServices;

namespace AWSilverlightLOB.Content.Inventory
{
    public partial class InventoryListPage : UserControl, IContentPage
    {
        #region Constructor
        public InventoryListPage()
        {
            InitializeComponent();
        } 
        #endregion

        #region IContentPage Members
        public event NavigateRequestHandler NavigateRequest;
        public event PageStatusChangeHandler PageStatusChange;

        public UserControl Control
        {
            get { return this; }
        }
        #endregion

        #region Control Event Handlers
        private void InventoryListPage_Loaded(object sender, RoutedEventArgs e)
        {
            GetInventoryList();
        }

        private void InventoryList_RowClick(object sender, EventArgs e)
        {
            string productID = ((HyperlinkButton)sender).TargetName;

            if (NavigateRequest != null)
                NavigateRequest(sender, new NavigateRequestArgs(Globals.PAGE_PRODUCT_DETAILS, productID));
        }

        private void InventorySidebar_NavigateRequest(object sender, NavigateRequestArgs e)
        {
            if (NavigateRequest != null)
                NavigateRequest(sender, e);
        }

        private void ListSearchBar_SearchList(object sender, ListSearchArgs e)
        {
            if (e.SearchText.Length == 0)
                GetInventoryList();  // Do full get list if no search text entered
            else
                GetFilteredInventoryList(e.SearchText);
        }
        #endregion

        #region Private Functions
        private void GetInventoryList()
        {
            if (PageStatusChange != null)
                PageStatusChange(this, new PageStatusChangeArgs(PageStatusChangeArgs.eStatuses.RetrievingData));

            AWDataServiceClient service = new AWDataServiceClient("*", Globals.WebServiceUrlPath);

            service.GetProductListCompleted += new EventHandler<GetProductListCompletedEventArgs>(AWDataService_GetProductListCompleted);
            
            // Hard coded to retrieve page 1 only - to complete
            service.GetProductListAsync(1, Globals.LIST_ITEMS_PER_PAGE);
        }

        private void AWDataService_GetProductListCompleted(object sender, GetProductListCompletedEventArgs e)
        {
            if (PageStatusChange != null)
                PageStatusChange(this, new PageStatusChangeArgs(PageStatusChangeArgs.eStatuses.Active));

            if (e.Error == null)
            {
                InventoryList.ItemsSource = e.Result;
            }
        }

        private void GetFilteredInventoryList(string filter)
        {
            if (PageStatusChange != null)
                PageStatusChange(this, new PageStatusChangeArgs(PageStatusChangeArgs.eStatuses.RetrievingData));

            AWDataServiceClient service = new AWDataServiceClient("*", Globals.WebServiceUrlPath);

            service.GetProductListFilteredCompleted += new EventHandler<GetProductListFilteredCompletedEventArgs>(AWDataService_GetProductListFilteredCompleted);

            // Hard coded to retrieve page 1 only - to complete
            service.GetProductListFilteredAsync(filter);
        }

        private void AWDataService_GetProductListFilteredCompleted(object sender, GetProductListFilteredCompletedEventArgs e)
        {
            if (PageStatusChange != null)
                PageStatusChange(this, new PageStatusChangeArgs(PageStatusChangeArgs.eStatuses.Active));

            if (e.Error == null)
            {
                InventoryList.ItemsSource = e.Result;
            }
        }
        #endregion
    }
}
