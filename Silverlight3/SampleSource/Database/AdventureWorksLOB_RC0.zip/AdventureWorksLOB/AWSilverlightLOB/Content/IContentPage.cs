﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using SilverlightLOBFramework.Delegates;

namespace SilverlightLOBFramework.Content
{
    public interface IContentPage
    {
        #region Events/Delegates
        event NavigateRequestHandler NavigateRequest;
        event PageStatusChangeHandler PageStatusChange;
        #endregion

        #region Properties
        UserControl Control { get; } 
        #endregion
    }
}
