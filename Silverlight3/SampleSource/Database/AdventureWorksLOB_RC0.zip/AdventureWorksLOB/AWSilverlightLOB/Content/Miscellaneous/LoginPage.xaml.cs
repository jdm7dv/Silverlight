﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using SilverlightLOBFramework.Delegates;
using AWSilverlightLOB.AWWebServices;

namespace SilverlightLOBFramework.Content.Miscellaneous
{
    public partial class LoginPage : UserControl, IContentPage
    {
        #region Member Variables
        private string m_destinationPage = Globals.PAGE_DASHBOARD; 
        #endregion

        #region Constructors
        public LoginPage()
        {
            InitializeComponent();
        }

        public LoginPage(string destinationPage)
        {
            InitializeComponent();
            m_destinationPage = destinationPage;
        } 
        #endregion

        #region Control Event Handlers
        private void LoginPage_Loaded(object sender, RoutedEventArgs e)
        {
            UserNameTextbox.Focus();
        }

        private void LoginPage_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
                StartLogin();
        }

        private void LoginButton_Click(object sender, RoutedEventArgs e)
        {
            StartLogin();
        }
        #endregion

        #region Server Data Event Handlers
        private void AWDataServiceClient_LoginCompleted(object sender, LoginCompletedEventArgs e)
        {
            UserDTO userDTO = e.Result;

            Globals.IsLoggedIn = (userDTO != null);

            if (PageStatusChange != null)
                PageStatusChange(this, new PageStatusChangeArgs(PageStatusChangeArgs.eStatuses.Active));

            if (e.Error == null)
            {
                if (Globals.IsLoggedIn)
                {
                    Globals.UserName = UserNameTextbox.Text;
                    Globals.Password = PasswordTextbox.Password;
                    Globals.UserRoles = userDTO.Roles.ToArray();

                    if (NavigateRequest != null)
                        NavigateRequest(this, new NavigateRequestArgs(m_destinationPage, null));
                }
                else
                {
                    MessageBox.Show("Invalid User Name or Password...", "Login", MessageBoxButton.OK);
                }
            }
            else
            {
                MessageBox.Show(e.Error.Message, "Error", MessageBoxButton.OK);
            }
        } 
        #endregion

        #region IContentPage Members
        public event NavigateRequestHandler NavigateRequest;
        public event PageStatusChangeHandler PageStatusChange;

        public UserControl Control
        {
            get { return this; }
        }
        #endregion

        #region Private Functions
        private void StartLogin()
        {
            if (PageStatusChange != null)
                PageStatusChange(this, new PageStatusChangeArgs(PageStatusChangeArgs.eStatuses.RetrievingData));

            AWDataServiceClient client = new AWDataServiceClient("*", Globals.WebServiceUrlPath);

            client.LoginCompleted += new EventHandler<LoginCompletedEventArgs>(AWDataServiceClient_LoginCompleted);
            client.LoginAsync(UserNameTextbox.Text, PasswordTextbox.Password);
        } 
        #endregion
    }
}
