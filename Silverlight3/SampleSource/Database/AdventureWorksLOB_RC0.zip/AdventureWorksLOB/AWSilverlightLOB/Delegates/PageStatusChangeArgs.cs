﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;

namespace SilverlightLOBFramework.Delegates
{
    public class PageStatusChangeArgs
    {
        public enum eStatuses
        {
            Loading,
            Active,
            RetrievingData,
            Closed
        }

        public eStatuses Status { get; set; }

        public PageStatusChangeArgs(eStatuses status)
        {
            Status = status;
        }
    }
}
