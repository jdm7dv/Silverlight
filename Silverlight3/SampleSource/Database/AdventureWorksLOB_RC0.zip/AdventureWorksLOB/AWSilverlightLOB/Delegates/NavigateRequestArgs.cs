﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;

namespace SilverlightLOBFramework.Delegates
{
    public class NavigateRequestArgs
    {
        public string Action { get; set; }
        public object Parameters { get; set; }

        public NavigateRequestArgs(string action, object parameters)
        {
            Action = action;
            Parameters = parameters;
        }
    }
}
