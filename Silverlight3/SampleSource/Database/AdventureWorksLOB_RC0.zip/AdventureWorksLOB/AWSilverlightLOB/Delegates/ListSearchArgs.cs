﻿namespace SilverlightLOBFramework.Delegates
{
    public class ListSearchArgs
    {
        public string SearchText { get; set; }

        public ListSearchArgs(string searchText)
        {
            SearchText = searchText;
        }
    }
}
