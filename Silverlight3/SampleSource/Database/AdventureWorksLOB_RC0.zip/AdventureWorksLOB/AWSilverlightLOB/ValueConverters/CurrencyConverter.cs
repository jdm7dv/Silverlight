﻿using System;
using System.Globalization;
using System.Windows.Data;

namespace SilverlightLOBFramework.ValueConverters
{
    public class CurrencyConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            decimal currency = (decimal)value;
            return currency.ToString("$0.00");
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            string formattedValue = value.ToString().TrimStart('$');
            decimal currency;

            if (decimal.TryParse(formattedValue, out currency))
            {
                return currency;
            }

            return value;
        }
    }
}
