﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using SilverlightLOBFramework;
using SilverlightLOBFramework.Content;
using SilverlightLOBFramework.Delegates;

namespace AWSilverlightLOB
{
    public partial class Page : UserControl
    {
        #region Member Variables
        private IContentPage m_currentPage = null;
        #endregion

        #region Constructor
        public Page()
        {
            InitializeComponent();
        }
        #endregion

        #region Event Handlers
        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            ShowPage(new SilverlightLOBFramework.Content.Miscellaneous.LoginPage());
        }

        private void NavigateRequest(object sender, NavigateRequestArgs e)
        {
            IContentPage navigateToPage = null;

            if (Globals.IsLoggedIn)
            {
                switch (e.Action)
                {
                    case Globals.PAGE_DASHBOARD:
                        navigateToPage = new SilverlightLOBFramework.Content.Dashboard.DashboardPage();
                        break;
                    case Globals.PAGE_INVENTORY_LIST:
                        navigateToPage = new AWSilverlightLOB.Content.Inventory.InventoryListPage();
                        break;
                    case Globals.PAGE_PRODUCT_DETAILS:
                        navigateToPage = new AWSilverlightLOB.Content.Inventory.ProductDetailsPage();
                        break;
                    case Globals.PAGE_PURCHASING_LIST:
                        break;
                    case Globals.PAGE_SALES_LIST:
                        break;
                    case Globals.PAGE_REPORTS_MENU:
                        break;
                    case Globals.PAGE_ADMIN_MENU:
                        break;
                    default:
                        navigateToPage = new SilverlightLOBFramework.Content.Dashboard.DashboardPage();
                        break;
                }
            }
            else
            {
                // Force user to log in first
                navigateToPage = new SilverlightLOBFramework.Content.Miscellaneous.LoginPage(e.Action);
            }

            //if (navigateToPage != null)
            ShowPage(navigateToPage);
        }

        private void CurrentPage_PageStatusChange(object sender, PageStatusChangeArgs e)
        {
            // Send the state change to the footer for display
            Footer.ContentPageStateChanged(e.Status);
        }
        #endregion

        #region Private Functions
        private void ShowPage(IContentPage page)
        {
            if (m_currentPage != null)
            {
                // Close the current page first
                LayoutRoot.Children.Remove(m_currentPage.Control);
            }

            m_currentPage = page;

            if (page != null)
            {
                m_currentPage.NavigateRequest += new NavigateRequestHandler(NavigateRequest);
                m_currentPage.PageStatusChange += new PageStatusChangeHandler(CurrentPage_PageStatusChange);

                // Set page size to fill the available area
                page.Control.Width = double.NaN;
                page.Control.Height = double.NaN;

                // Now display the specified page
                page.Control.SetValue(Grid.RowProperty, 1);
                LayoutRoot.Children.Add(page.Control);
                page.Control.Focus();
            }
        }
        #endregion
    }
}
