﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace AWWeb.DTOs.Security
{
    public class UserDTO
    {
        public string FullName { get; set; }
        public string Email { get; set; }
        public List<string> Roles { get; set; }
    }
}
