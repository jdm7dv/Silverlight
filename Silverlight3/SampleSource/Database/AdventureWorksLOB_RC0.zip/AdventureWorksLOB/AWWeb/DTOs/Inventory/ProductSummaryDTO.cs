﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace AWWeb.DTOs.Inventory
{
    public class ProductSummaryDTO
    {
        public int ProductID { get; set; }
        public string Name { get; set; }
        public string ProductNumber { get; set; }
        public string CategoryName { get; set; }
        public string SubcategoryName { get; set; }
        public decimal ListPrice { get; set; }
    }
}
