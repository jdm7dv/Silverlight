﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using System.Web.Security;
using AWWeb.DTOs.Security;
using AWWeb.DTOs.Inventory;

namespace AWWeb
{
    public class AWDataService : IAWDataService
    {
        #region Security Functions
        public UserDTO Login(string userName, string password)
        {
            UserDTO userDTO = null;

            bool isLoginValid = Membership.ValidateUser(userName, password);

            if (isLoginValid)
            {
                MembershipUser user = Membership.GetUser(userName);

                if (user != null)
                {
                    userDTO = new UserDTO();

                    userDTO.FullName = user.UserName; // To fix
                    userDTO.Email = user.Email;

                    userDTO.Roles = new List<string>(Roles.GetRolesForUser(user.UserName));
                }
            }

            return userDTO;
        }
        #endregion

        #region Inventory Functions
        public ProductSummaryDTO[] GetProductList(int pageNumber, int itemsPerPage, out int totalProductCount)
        {
            totalProductCount = 0; // Not currently implemented, for future paging implementation

            AdventureWorksEntities context = new AdventureWorksEntities();

            // Get LINQ to populate out DTO automatically with the results from
            // our query to the entity framework
            IQueryable<ProductSummaryDTO> qry = from p in context.Product
                                                orderby p.Name
                                  select new ProductSummaryDTO
                                  {
                                      ProductID = p.ProductID,
                                      Name = p.Name,
                                      ProductNumber = p.ProductNumber,
                                      ListPrice = p.ListPrice,
                                      CategoryName = "",
                                      SubcategoryName = ""
                                  };

            IQueryable<ProductSummaryDTO> results = qry.Skip((pageNumber - 1) * itemsPerPage).Take(itemsPerPage);
            return results.ToArray();
        }

        public ProductSummaryDTO[] GetProductListFiltered(string productName)
        {
            AdventureWorksEntities context = new AdventureWorksEntities();
            
            // Get LINQ to populate out DTO automatically with the results from
            // our query to the entity framework.  Note, due to default collation
            // the AdventureWorks database is case sensitive for searches
            // so need to handle search case insensitivity by matching lower case
            productName = productName.ToLower();

            IQueryable<ProductSummaryDTO> qry = from p in context.Product
                                                where p.Name.ToLower().Contains(productName)
                                                orderby p.Name
                                                select new ProductSummaryDTO
                                                {
                                                    ProductID = p.ProductID,
                                                    Name = p.Name,
                                                    ProductNumber = p.ProductNumber,
                                                    ListPrice = p.ListPrice,
                                                    CategoryName = "",
                                                    SubcategoryName = ""
                                                };

            return qry.ToArray();
        }

        public ProductDTO GetProduct(int productID)
        {
            return null;
        }

        public void UpdateProduct(ProductDTO product)
        {
            
        }

        public void DeleteProduct(int productID)
        {
            
        }
        #endregion
    }
}
