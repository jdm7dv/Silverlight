﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using AWWeb.DTOs.Security;
using AWWeb.DTOs.Inventory;

namespace AWWeb
{
    [ServiceContract]
    public interface IAWDataService
    {
        [OperationContract]
        UserDTO Login(string userName, string password);

        [OperationContract]
        ProductSummaryDTO[] GetProductList(int pageNumber, int itemsPerPage, out int totalProductCount);

        [OperationContract]
        ProductSummaryDTO[] GetProductListFiltered(string productName);

        [OperationContract]
        ProductDTO GetProduct(int productID);

        [OperationContract]
        void UpdateProduct(ProductDTO product);

        [OperationContract]
        void DeleteProduct(int productID);
    }
}
