﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace YetAnotherCarousel
{
	public partial class Page : UserControl
	{
		public Page()
		{
			// Required to initialize variables
			InitializeComponent();
            this.Loaded += new RoutedEventHandler(Page_Loaded);
		}

        void Page_Loaded(object sender, RoutedEventArgs e)
        {
            Carousel carousel = new Carousel();
            
            Image i = new Image();
            i.Source = new BitmapImage(new Uri("mtbaker.JPG", UriKind.Relative));
            i.Stretch = Stretch.Fill;
            i.Width = 400;
            i.Height = 300;


            Image i2 = new Image();
            i2.Source = new BitmapImage(new Uri("mtbaker2.JPG", UriKind.Relative));
            i2.Stretch = Stretch.Fill;
            i2.Width = 400;
            i2.Height = 300;


            Image i3 = new Image();
            i3.Source = new BitmapImage(new Uri("mtbaker3.JPG", UriKind.Relative));
            i3.Stretch = Stretch.Fill;
            i3.Width = 400;
            i3.Height = 300;

            
            MediaElement me = new MediaElement();
            me.Width = 400;
            me.Height = 300;
            me.Source = new Uri("frisbee.wmv", UriKind.Relative);
            me.Stretch = Stretch.Fill;
            me.HorizontalAlignment = HorizontalAlignment.Stretch;

            
            carousel.CreateItem(new Clock(), "clock3");
            carousel.CreateItem(i, "image");
            carousel.CreateItem(me, "media");
            carousel.CreateItem(i2, "image2");
            carousel.CreateItem(i3, "image3");
            
            this.LayoutRoot.Children.Add(carousel);

        }

	}
}