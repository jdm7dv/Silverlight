using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Media.Animation;
namespace YetAnotherCarousel
{

    public class CarouselItem  {

        private Carousel _carousel;
        private FrameworkElement _item;
        private string _name;

        public string Name
        {
            get { return _name; }
            set { _name = value; }
        }

        public CarouselItem(Carousel carousel, FrameworkElement item, string name)
        {
            _item = item;
            _carousel = carousel;
            _name = name;
        }

        public FrameworkElement Element {
            get {
                return _item;
            }
        }

        public void Update(double left, double top, int zIndex, double scale, double opacity) {
            Canvas.SetLeft(_item, left);
            Canvas.SetTop(_item, top);
            Canvas.SetZIndex(_item, zIndex);
            _item.Opacity = opacity;
            ((ScaleTransform)_item.RenderTransform).ScaleX = scale;
            ((ScaleTransform)_item.RenderTransform).ScaleY = scale;
        }
    }
}
