
using System;
using System.Collections;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
namespace YetAnotherCarousel
{

    public partial class Carousel : Canvas
    {
        //tweak these values to change look and feel
        private const double MinScale = 0.5;
        private const double MidScale = .75;
        private const double MaxScale = 1;
        private const double MinOpacity = .5;
        private const double MidOpacity = .9;
        private const double MaxOpacity = 1;
        private Color MenuTextColor = Colors.Black;
        private FontFamily MenuFontFamily = new FontFamily("Arial");
        private double MenuFontSize = 12;
        private Duration duration = new Duration(TimeSpan.FromSeconds(.33));

        //right now we hard code ItemWidth and ItemHeight
        //need to make this dynamic
        private const double ItemWidth = 400;
        private const double ItemHeight = 300;
        private const double yScaleFar = .2;
        private const double yScaleMiddle = .1;
        //this carousel only supports showing 5 items at a time and
        //virtualizes the other items
        private const int CarouselItemCount = 5;
        private FrameworkElement _containerCanvas;
        private List<CarouselItem> _items;
        private double _xCenter = 0;
        private double _yCenter = 0;
        //we use this array to keep track of where each item is in the carousel
        private int[] spotArray;

        public Carousel()
        {
            _items = new List<CarouselItem>();
            this.Loaded += new RoutedEventHandler(Carousel_Loaded);
        }


        public void Reset()
        {
            for (int i = 0; i < CarouselItemCount; i++)
            {


                ((CarouselItem)_items[i]).Update(MiddleFormulaX(), _yCenter, CalculateZIndex(i), 1, 1);

                StartStoryboard("MoveTo" + i, i);



            }
            for (int i = CarouselItemCount; i < _items.Count; i++)
            {
                //this gets the hidden ones positioned correctly
                if (i == CarouselItemCount)

                    ((CarouselItem)_items[i]).Update(FarRightFormulaX(), _yCenter + (ItemHeight * yScaleFar), CalculateZIndex(i), 0, 0);
                else if (i == _items.Count - 1)
                    ((CarouselItem)_items[i]).Update(FarLeftFormulaX(), _yCenter + (ItemHeight * yScaleFar), CalculateZIndex(i), 0, 0);
                else
                    ((CarouselItem)_items[i]).Update(MiddleFormulaX(), _yCenter + (ItemHeight * yScaleFar), CalculateZIndex(i), 0, 0);


            }
        }

        void Carousel_Loaded(object sender, RoutedEventArgs e)
        {
            _containerCanvas = (FrameworkElement)this.Parent;

            //fill the parent - a better way to do this?
            this.Width = _containerCanvas.Width;
            this.Height = _containerCanvas.Height;
            //everything is a canvas so we do our own layout
            //need to know the center
            _xCenter = (this.Width - ItemHeight);
            _yCenter = (this.Height - ItemHeight) / 2;

             BuildMenu();
            //build array
            spotArray = new int[_items.Count];
            for (int i = 0; i < _items.Count; i++)
            {
                spotArray[i] = i;
            }
            //here we build our  storyboards for each item when it moves
            BuildStoryboard("MoveTo0", FarLeftFormulaX(), _yCenter + (ItemHeight * yScaleFar), MinOpacity, MinScale, duration);
            BuildStoryboard("MoveTo1", MiddleLeftFormulaX(), _yCenter + (ItemHeight * yScaleMiddle), MidOpacity, MidScale, duration);
            BuildStoryboard("MoveTo2", MiddleFormulaX(), _yCenter, MaxOpacity, MaxScale, duration);
            BuildStoryboard("MoveTo3", MiddleRightFormulaX(), _yCenter + (ItemHeight * yScaleMiddle), MidOpacity, MidScale, duration);
            BuildStoryboard("MoveTo4", FarRightFormulaX(), _yCenter + (ItemHeight * yScaleFar), MinOpacity, MinScale, duration);
            BuildStoryboard("Start", MiddleFormulaX(), _yCenter, MaxOpacity, MaxScale, duration);

            BuildStoryboard("HideLeft", FarLeftFormulaX(), _yCenter + (ItemHeight * yScaleFar), 0, 0, duration);
            BuildStoryboard("HideRight", FarRightFormulaX(), _yCenter + (ItemHeight * yScaleFar), 0, 0, duration);
            BuildStoryboard("HideMiddle", MiddleFormulaX(), _yCenter + (ItemHeight * yScaleFar), 0, 0, duration);

            
            ArrangeItems();

        }

        private Storyboard BuildStoryboard(string name, double tox, double toy, double too, double tos, Duration d)
        {
            Storyboard s = new Storyboard();
            this.Resources.Add(name, s);
            //x animation
            DoubleAnimation dax = new DoubleAnimation();
            s.Children.Add(dax);
            dax.To = tox;
            dax.Duration = d;
            Storyboard.SetTargetProperty(dax, new PropertyPath("(Canvas.Left)"));
            //y animation
            DoubleAnimation day = new DoubleAnimation();
            s.Children.Add(day);
            day.To = toy;
            day.Duration = d;
            Storyboard.SetTargetProperty(day, new PropertyPath("(Canvas.Top)"));
            //opacity animation
            DoubleAnimation dao = new DoubleAnimation();
            s.Children.Add(dao);
            dao.To = too;
            dao.Duration = d;
            Storyboard.SetTargetProperty(dao, new PropertyPath("Opacity"));
            //scale animation
            DoubleAnimation dasx = new DoubleAnimation();
            s.Children.Add(dasx);
            dasx.To = tos;
            dasx.Duration = d;
            Storyboard.SetTargetProperty(dasx, new PropertyPath("(FrameworkElement.RenderTransform).(ScaleTransform.ScaleX)"));
            DoubleAnimation dasy = new DoubleAnimation();
            s.Children.Add(dasy);
            dasy.To = tos;
            dasy.Duration = d;
            Storyboard.SetTargetProperty(dasy, new PropertyPath("(FrameworkElement.RenderTransform).(ScaleTransform.ScaleY)"));

            return s;
        }
  
        private void ArrangeItems()
        {
            //iterate our items
            for (int i = 0; i < CarouselItemCount; i++)
            {


                ((CarouselItem)_items[i]).Update(MiddleFormulaX(), _yCenter, CalculateZIndex(i), 1, 1);
                this.Children.Add(_items[i].Element);
               
                StartStoryboard("MoveTo" + i, i);
               
         

            }
            for (int i = CarouselItemCount; i < _items.Count; i++)
            {
                //this gets the hidden ones positioned correctly
                if (i == CarouselItemCount)

                    ((CarouselItem)_items[i]).Update(FarRightFormulaX(), _yCenter + (ItemHeight * yScaleFar), CalculateZIndex(i), 0, 0);
                else if (i == _items.Count -1)
                    ((CarouselItem)_items[i]).Update(FarLeftFormulaX(), _yCenter + (ItemHeight * yScaleFar), CalculateZIndex(i), 0, 0);
                else
                    ((CarouselItem)_items[i]).Update(MiddleFormulaX(), _yCenter + (ItemHeight * yScaleFar), CalculateZIndex(i), 0, 0);

                this.Children.Add(_items[i].Element);
                
            }
        }
        public void CreateItem(FrameworkElement fe, string name)
        {
            fe.RenderTransform = new ScaleTransform();
            fe.Tag = _items.Count.ToString();
            fe.MouseLeftButtonDown += new MouseButtonEventHandler(OnCarouselClick);
            CarouselItem ci = new CarouselItem(this, fe, name);
            _items.Add(ci);
        }
        private void CreateDummyItems(int number)
        {
            for (int i = 0; i < number; i++)
            {
                Canvas c = new Canvas();
                c.Width = ItemWidth;
                c.Height = ItemHeight;
                c.RenderTransform = new ScaleTransform();
                c.Background = new SolidColorBrush(Colors.LightGray);
                c.MouseLeftButtonDown += new MouseButtonEventHandler(OnCarouselClick);
                c.Tag = _items.Count.ToString();
                TextBlock tb = new TextBlock();
                tb.Text = "item " + _items.Count.ToString() + "  ";
                Canvas.SetLeft(tb, 0);
                Canvas.SetTop(tb, 0);
                c.Children.Add(tb);
                CarouselItem ci = new CarouselItem(this, c, tb.Text);
                _items.Add(ci);
            }
        }

        private void BuildMenu()
        {
            StackPanel sp = new StackPanel();
            sp.Orientation = Orientation.Horizontal;
                TextBlock tb1 = new TextBlock();
                tb1.Text = "<< Spin Left   |";
                tb1.Foreground = new SolidColorBrush(MenuTextColor);
                tb1.FontFamily = MenuFontFamily;
                tb1.FontSize = MenuFontSize;
                tb1.MouseLeftButtonDown += new MouseButtonEventHandler(OnSpinLeft);
                sp.Children.Add(tb1);

                TextBlock tb2 = new TextBlock();
                tb2.Text = "  Spin Right >>";
                tb2.Foreground = new SolidColorBrush(MenuTextColor);
                tb2.FontFamily = MenuFontFamily;
                tb2.FontSize = MenuFontSize;
                tb2.MouseLeftButtonDown += new MouseButtonEventHandler(OnSpinRight);
                sp.Children.Add(tb2);

            //why is StackPanel returning Nan for Width and 0 for ActualWidth, even after calling updateLayout
            //argh -- now my positioning of the stack panel is not dynamic
            Canvas.SetLeft(sp, _xCenter - 200);
            Canvas.SetTop(sp, this.Height - 50);
            Canvas.SetZIndex(sp, 100);
            this.Children.Add(sp);
        
        }
        //the formulas for positioning X
        //could tweak these to change spacing
        private double FarLeftFormulaX()
        {
            return (_xCenter * .1) * 2.5;
        }
        private double MiddleLeftFormulaX()
        {
            return (_xCenter * .1) * 3;
        }
        private double MiddleFormulaX()
        {
            return (_xCenter * .1) * 4; ;
        }
        private double MiddleRightFormulaX()
        {
            return (_xCenter * .1) * 7;
        }
        private double FarRightFormulaX()
        {
            return (_xCenter * .1) * 10;
        }

        void OnCarouselClick(object sender, MouseButtonEventArgs e)
        {
            int canvasToCenter = Convert.ToInt32(((FrameworkElement)sender).Tag);
            //in this one, we iterate through the spots
            //different logic when the menu item is clicked
            for (int i = 0; i < 5; i++)
            {
                if (spotArray[i] == canvasToCenter)
                {
                    //already in center
                    if (i == 2)
                        return;

                    if (i == 1)
                    {
                        MoveRight(1);
                        break;
                    }
                    if (i == 0)
                    {
                        MoveRight(2);
                        break;
                    }
                    if (i == 3)
                    {
                        MoveLeft(1);
                        break;
                    }
                    if (i == 4)
                    {
                        MoveLeft(2);
                        break;
                    }
                }
            }


        }
        void OnSpinLeft(object sender, MouseButtonEventArgs e)
        {
            MoveLeft(1);
        }
        void OnSpinRight(object sender, MouseButtonEventArgs e)
        {
            MoveRight(1);
        }
        void MoveRight(int numOfSpots)
        {
            Move(Direction.Right, numOfSpots);

        }
        void MoveLeft(int numOfSpots)
        {
            Move(Direction.Left, numOfSpots);
        }

        void Move(Direction d, int numOfSpots)
        {
            //note: we don't do anything with number of spots
                for (int i = 0; i < _items.Count; i++)
                {
                    if (d == Direction.Left)
                    {
                        spotArray[i] = spotArray[i] + 1;
                        if (spotArray[i] == _items.Count)
                            spotArray[i] = 0;
                    }
                    else
                    {
                        spotArray[i] = spotArray[i] - 1;
                        if (spotArray[i] == -1)
                            spotArray[i] = _items.Count - 1;

                    }
                }

                if (d == Direction.Left)
                {

                    StartStoryboard("MoveTo0", spotArray[0]);

                    StartStoryboard("MoveTo1", spotArray[1]);

                    StartStoryboard("MoveTo2", spotArray[2]);

                    StartStoryboard("MoveTo3", spotArray[3]);

                    StartStoryboard("MoveTo4", spotArray[4]);

                }

                else
                {

                    StartStoryboard("MoveTo4", spotArray[4]);

                    StartStoryboard("MoveTo3", spotArray[3]);

                    StartStoryboard("MoveTo2", spotArray[2]);

                    StartStoryboard("MoveTo1", spotArray[1]);

                    StartStoryboard("MoveTo0", spotArray[0]);

                }


            
            if (_items.Count  > 5)
                {
                    //get the hidden ones in the middle
                    for (int i = 5; i < _items.Count - 2; i++)
                    {
                        StartStoryboard("HideMiddle", spotArray[i]);
                       // _items[spotArray[i]].Element.Opacity = 0;
                    }

                    StartStoryboard("HideRight", spotArray[5]);
                    StartStoryboard("HideLeft", spotArray[_items.Count - 1]);

                }
                

                //update zorder
                for (int i = 0; i < CarouselItemCount; i++)
                {
                    Canvas.SetZIndex((FrameworkElement)_items[spotArray[i]].Element, CalculateZIndex(i));
                }
          

        }

        enum Direction
        {
            Right, Left
        }
        //actually fire the storyboards
        void StartStoryboard(string name, int spot)
        {
            Storyboard s = this.Resources[name] as Storyboard;
            s.Stop();
            Storyboard.SetTarget(s, _items[spot].Element);
            s.Begin();
        }


         

        int CalculateZIndex(int spot)
        {
            
            if (spot == 3)
            {
                return 1;
            }
            else if (spot >= 4)
                return 0;

            else
                return spot;
        }


    }
}
