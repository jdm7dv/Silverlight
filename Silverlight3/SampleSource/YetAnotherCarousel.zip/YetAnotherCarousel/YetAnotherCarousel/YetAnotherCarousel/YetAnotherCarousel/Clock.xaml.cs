﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace YetAnotherCarousel
{
    public partial class Clock : UserControl
    {
        public Clock()
        {
            InitializeComponent();
            DateTime currentTime = DateTime.Now;
            int hourAngle = ((currentTime.Hour / 12) * 360 + currentTime.Minute / 2) + 180;
            int minAngle = ((currentTime.Minute / 60) * 360) + 180;
            int secAngle = ((currentTime.Second / 60) * 360) + 180;

            HourAnimation.From = hourAngle;
            HourAnimation.To = hourAngle + 360;
            MinuteAnimation.From = minAngle;
            MinuteAnimation.To = minAngle + 360;
            SecondAnimation.From = secAngle;
            SecondAnimation.To = secAngle + 360;
        }
    }
}
